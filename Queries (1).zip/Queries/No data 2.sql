alter session set current_schema=DM;

select unique o.order_type, o.tc_order_id, o.order_id, o.do_status, l.tc_lpn_id, l.chute_id
from picking_short_item psi, orders o, lpn l, order_line_item oli
where psi.line_item_id = oli.line_item_id and o.order_id = oli.order_id and psi.tc_lpn_id = l.tc_lpn_id
and o.order_type in ('PR','EC') and l.lpn_Facility_status = 15 and psi.stat_code = 90 and do_dtl_status >=120
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.item_id = psi.item_id and td.stat_code < 90)
and not exists (select 1 from picking_short_item psi2 where psi2.line_item_id = psi.line_item_id and psi2.stat_code = 0)
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.tc_order_id = o.tc_order_id and td.stat_code < 90)
and not exists (select 1 from alloc_invn_dtl aid where aid.carton_nbr = psi.tc_lpn_id and aid.tc_order_id = o.tc_order_id and aid.stat_code < 90)
and not exists (select 1 from order_line_item oli2 where oli2.order_id = oli.order_id and oli2.do_dtl_status < 150); 

--------------------------------------
select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source,TOTAL_LPN_QTY,ITEM_ID,ORDER_ID from lpn where TC_LPN_ID in ('00000197181344091239');--00000197181596118272----first check what's s the status(15) goes to 20
select * from lpn where tc_reference_lpn_id in ('00000197181344091239');-----96 status---00007160417615729798
---00000197181635037427---35---150
---00000197181635037458---35---150
---00000197181634985491---35---150
select * from lpn_detail where lpn_id in ('77563288') and lpn_detail_status<'90';
select do_status,order_id from  orders where tc_order_id in ('55206079');
select * from picking_short_item where tc_lpn_id in ('00000197181344091239') and stat_code<90;
select * from lpn_lock where tc_lpn_id in ('00000197181344091239');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181344091239') and stat_code < '90';
select * from DM.TASK_DTL where CARTON_NBR in ('00000197181344091239') and stat_code <90;

select tc_order_id,tc_lpn_id from lpn where tc_order_id in ('55206079');
select do_status,order_type from orders where tc_order_id in ('55206079');-------it ll b 140 goes to 150
select lpn_facility_status,tc_lpn_id,INBOUND_OUTBOUND_INDICATOR from lpn where tc_order_id in ('55206079');----multi lpns 15 shldn't pack---cant pack order..can pack olpn

select  distinct line_item_id,do_dtl_status from order_line_item where order_id='51229617' and item_id='2393349';
--do_dtl_status=200--then we can cancell(when qty and facility status is 0)

select allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id='49061826' and item_id='2376428';
select * from wm_inventory where tc_lpn_id in ('00000156741222356923') and item_id='2141782';--608657392


select do_status,order_id,order_type from orders where tc_order_id in ('CAR28553011_1');--ll b 140

select lpn_facility_status,tc_lpn_id,INBOUND_OUTBOUND_INDICATOR from lpn where tc_order_id in ('1222794633');----multi lpns 15 shldn't pack---cant pack order..can pack olpn

------------------------------------------














--------------------------------------------------------------------------------------------------------------------------------------------

select lpn_facility_status,lpn_id,tc_lpn_id,INBOUND_OUTBOUND_INDICATOR, tc_order_id,last_updated_source from lpn where tc_lpn_id in ('00000197181542585998');
select * from lpn_detail where lpn_id in ('64657680');
select do_status,order_type,order_id from orders where tc_order_id in ('1220019722');
select *from order_line_item where order_id='43642305';--do_dtl_status=200--then we can cancell
select * from picking_short_item where tc_lpn_id in ('00000197181540755195') and stat_code<90;----637871733
select * from lpn_lock where tc_lpn_id in ('00000197181540755195');
select * from DM.ALLOC_INVN_DTL where Carton_NBR in ('00000197181540755195') and stat_code < '90';
select * from DM.TASK_DTL where carton_nbr in ('00000197181540755195') and stat_code < '90';
select distinct tc_order_id,tc_lpn_id,lpn_facility_status from lpn where tc_order_id in ('1219947888');
select allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id in ('40559301') and item_id='2299357';
select TC_LPN_ID,ON_HAND_QTY,WM_ALLOCATED_QTY,TO_BE_FILLED_QTY from wm_inventory where tc_lpn_id in ('00000197181523644713') and item_id='2287974';
------------------
Select unique o.order_type, o.tc_order_id, o.order_id, o.do_status, l.tc_lpn_id, l.chute_id
from picking_short_item psi, orders o, lpn l, order_line_item oli
where psi.line_item_id = oli.line_item_id and o.order_id = oli.order_id and psi.tc_lpn_id = l.tc_lpn_id
and o.order_type in ('PR','EC') and l.lpn_Facility_status = 15 and psi.stat_code = 90 and do_dtl_status >=120
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.item_id = psi.item_id and td.stat_code < 90)
and not exists (select 1 from picking_short_item psi2 where psi2.line_item_id = psi.line_item_id and psi2.stat_code = 0)
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.tc_order_id = o.tc_order_id and td.stat_code < 90)
and not exists (select 1 from alloc_invn_dtl aid where aid.carton_nbr = psi.tc_lpn_id and aid.tc_order_id = o.tc_order_id and aid.stat_code < 90)
and not exists (select 1 from order_line_item oli2 where oli2.order_id = oli.order_id and oli2.do_dtl_status < 150);

--------------------------------------
select orders set do_status = 150 where order_type in ('EC') and do_status < 150
and not exists (select 1 from order_line_item oli where orders.order_id = oli.order_id and oli.do_dtl_status < 150);
------------------------------------------------------------------------------------------------------------------------------------------------
select*from lpn where tc_lpn_id='00000197181529880825';
select * from DM.LPN_DETAIL where lpn_id = '64657680';
------------------------------------------------------------------------------------------------------------------------------------------------

select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);
------------------------------------------------------------------------------------------------------------------------------------------------------
select tc_lpn_id,lpn_facility_status,tc_order_id from lpn where tc_lpn_id in ('00000197181519152321');
select BILL_ACCT_NBR from orders where tc_order_id='1218708623';
select distinct(tc_order_id), bill_acct_nbr from orders where bill_acct_nbr ='185-4X0';

select * from alloc_invn_dtl where cntr_nbr in ('970059456184','970059467904','970059468090','970059467905','970059468093') and stat_code<'90';
select * from task_dtl where cntr_nbr in ('970059456184','970059467904','970059468090','970059467905','970059468093') and stat_code<'90';
-----------------------------------------------------------------------------------------------------------------------------------------------
select shipment_status,SHIPMENT_CLOSED_INDICATOR,LPN_ASSIGNMENT_STOPPED,WMS_STATUS_CODE,last_updated_source,LAST_UPDATED_DTTM from shipment where tc_shipment_id='CS20714649';







select emp.*,d.DESCRIPTION dept, s.DESCRIPTION shift,jf.NAME job_func,emp2.login_user_id supv
from dm.VIEW_EMP emp
left join dm.E_DEPT d on emp.dept_id = d.dept_id
left join dm.E_SHIFT s on emp.shift_id = s.shift_id
left join dm.E_JOB_FUNCTION jf on emp.JOB_FUNC_ID = jf.JOB_FUNC_ID
left join dm.VIEW_UCL_USER emp2 on emp2.emp_id = emp.SPVSR_EMP_ID
where emp.whse = '12';

select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);


