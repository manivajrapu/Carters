alter session set current_schema = DM;



select tc_order_id,do_status,tc_shipment_id from orders where ext_purchase_order = '35445';

select lpn_facility_status,tc_shipment_id,shipment_id,ship_via,tc_lpn_id,last_updated_source from lpn where tc_order_id = '1218484039';



Select o.ext_purchase_order, o.order_id, o.tc_order_id, o.order_status, o.do_status, l.tc_lpn_id, l.order_split_id, os.order_split_id, ship_via, to_char(l.shipment_id) shipment_Id, l.tc_shipment_Id, s.assigned_ship_via S_SHIP_VIA, s.shipment_id S_SHIP_ID, s.tc_shipment_id s_TC_SHIP_ID, 
  'update lpn set order_split_id = '||chr(39)||os.order_split_id||chr(39)||', ship_via = '||chr(39)||s.assigned_ship_via||chr(39)||', shipment_id =  '||chr(39)||s.shipment_id||chr(39)||', tc_shipment_Id = '||chr(39)||s.tc_shipment_id||chr(39)||' where tc_lpn_id = '||chr(39)||l.tc_lpn_id||chr(39)||';' CCF
from orders o, lpn l, order_split os, shipment s where o.order_id = l.order_id and o.order_id = os.order_id (+) and os.shipment_Id = s.shipment_Id (+)
and o.ext_purchase_order in (
'35445'
)
and l.lpn_facility_status < 40 and s.shipment_status = 60 and os.is_cancelled = 0
order by ext_purchase_order, tc_order_id;



select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status <= 180 and lpn_facility_status < 40 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status > 60)  


select 
