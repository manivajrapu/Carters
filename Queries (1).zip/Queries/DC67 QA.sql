alter session SET Current_schema=WM;

select unique a.tc_asn_id, count(l.tc_lpn_id) from asn a, lpn l
where a.tc_asn_id = l.tc_asn_id
and a.asn_status < 30
and l.lpn_facility_status > 0
group by a.tc_asn_id;