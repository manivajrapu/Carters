select error_seq_nbr,proc_stat_code from inpt_store_master;

select distinct error_seq_nbr,proc_stat_code from inpt_store_master;

select msg from msg_log where msg_log_id in ('186788067','186789916','186796365','186797267','186798018');

---update inpt_store_master set proc_stat_code= 0 ,error_seq_nbr=0;

--commit;
---------------------------------------
select distinct error_seq_nbr,proc_stat_code from inpt_asn_hdr;



---dc33 gender updates--
select unique style from item_master where sale_grp is null and sku_id in(select sku_id from case_dtl cd where actl_qty > 0);

select *  from store_distro where distro_nbr='330155873576';