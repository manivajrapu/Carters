select stat_code from outbd_load where load_nbr in ('3300104369'); -- =>40 status

select phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,
ph.plan_bol, ph.plan_master_bol,count(*)
from pkt_hdr ph,
pkt_hdr_intrnl phi
where ph.pkt_ctrl_nbr in (select distinct ch.pkt_ctrl_nbr
from carton_hdr ch
where load_nbr in ('3300104161')
and ((stat_code < '90') or
(stat_code = '99')))
and ph.plan_load_nbr in ('3300104161')
and phi.pkt_ctrl_nbr = ph.pkt_ctrl_nbr
group by phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,ph.plan_bol, ph.plan_master_bol;


Select load_nbr,stat_code,carton_nbr,shpmt_nbr,bol,master_bol,user_id,mod_date_time,pkt_ctrl_nbr from  carton_hdr ch
where load_nbr in ('3300104161') and stat_code < '90';--here take the cartons and take the pkt_ctrl_nbr to put in CCF <20

select * from carton_hdr where carton_nbr in('00000197183472995618');
select pkt_ctrl_nbr from carton_hdr where carton_nbr in('00000197183472722139');
select * from carton_hdr where pkt_ctrl_nbr='3400000131';

select load_nbr from carton_hdr where carton_nbr in('00000197183472722139');

-----main query---

select * from carton_hdr where pkt_ctrl_nbr='3406744593'; 
--if this pkt_ctrl_nbr has multiple cartons then update only carton_hdr and do not update ph2.pkt_ctrl_nbr.
--If this is having only carton said by customer then update ph2.pkt_ctrl_nbr also.

-------query-----

select load_nbr, shpmt_nbr, bol, master_bol, carton_nbr,stat_code ,pkt_ctrl_nbr from carton_hdr where carton_nbr = '00000197183472895420';

--pkt_hdr----
select plan_load_nbr, plan_bol, plan_master_bol, plan_shpmt_nbr from pkt_hdr where pkt_ctrl_nbr = '3400000131';

----carton_hdr---
select load_nbr, shpmt_nbr, bol, master_bol, carton_nbr from carton_hdr where carton_nbr in ('00000197183471912579');

---quer for checking how many cartons associated with pkt_hdr---
select *from carton_hdr where pkt_ctrl_nbr = '3400000131' and load_nbr = '3300104161';


select ph2.plan_load_nbr,ph2.plan_shpmt_nbr from pkt_hdr ph2 where ph2.pkt_ctrl_nbr in ('3406744593');
   



select TC_ORDER_ID,TC_LPN_ID,LPN_FACILITY_STATUS,MANIFEST_NBR,TC_SHIPMENT_ID,SHIP_VIA from lpn where TC_LPN_ID='00000197181335743031';