alter session set current_schema = DM;

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source from lpn where tc_lpn_id in ('00000197181344630605');--00000197181335229702,
----00000197181337221230,00000197181337195616,00000197181337174543
---00000197181337117731,00000197181337240545,00000197181337170408
select * from lpn where tc_reference_lpn_id in ('00000197181344138651');
select * from lpn_detail where lpn_id in ('77917444') and lpn_detail_status<'90';
select do_status,order_type from orders where tc_order_id in ('CAR28761571_1');
select * from picking_short_item where tc_lpn_id in ('00000197181344630605') and stat_code < '90';--778736209
select * from lpn_lock where tc_lpn_id in ('00000197181344630605');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181344630605') and stat_code < '90';
select * from DM.TASK_DTL where CARTON_NBR in ('00000197181344630605') and stat_code < '90';

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and d_facility_alias_id is not null and tc_lpn_id='00000197181344630605';----PTS(put to store)

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and misc_instr_code_3 > 0 and d_facility_alias_id is  null;----STS(BOSS)

select * from lpn where tc_order_id='1221704147';
------------------------------------------------------------ISSUE iLPN-----------------
Select * from lpn where tc_lpn_id in ('00007160410829514631');
select non_inventory_lpn_flag, lpn_facility_status,ship_via, lpn_id,tc_lpn_id from lpn where tc_lpn_id in ('00007160410829514631');


select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00007160410829514631') and stat_code < '90';

------------------------------------------------------------------------------------------------------------------------------------
select tc_order_id,tc_lpn_id from lpn where tc_order_id in ('CAR24314253_1');
select allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id='40494710' and item_id='2141782';
select * from wm_inventory where tc_lpn_id in ('00000197181329226274','00000197181329227110') and item_id='2141782';--608657392