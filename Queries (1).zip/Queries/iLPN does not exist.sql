alter session set current_schema = DM;

select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;

----when cntr nbr is null-----------
select ic.item_id,ic.item_name,ic.item_bar_code,pt.cntr_nbr,pt.task_id,pt.MOD_DATE_TIME
from prod_trkg_tran pt 
join item_cbo ic on ic.item_id=pt.item_id
where task_id in ('18035924') order by MOD_DATE_TIME desc; 

-------------------------------------------------------------------------micheal keavney orphaned STS----------------------
select tc_lpn_id, inbound_outbound_indicator, lpn_facility_status,
'update lpn set lpn_facility_status = ''99'' where tc_lpn_id = '||chr(39)||tc_lpn_id||chr(39)||' and inbound_outbound_indicator = '''||inbound_outbound_indicator||''';' "SQL Statement"
from dm.lpn l, dm.orders o where l.order_id = o.order_id and o.ref_field_3 = 'EC' and l.lpn_facility_status = 20 and l.d_facility_alias_id is null and l.inbound_outbound_indicator = 'O'
and l.last_updated_dttm < sysdate - 1/24
and not exists (select 1 from dm.lpn l2 where l2.tc_reference_lpn_id = l.tc_lpn_id and l2.lpn_facility_status < 90 and l2.inbound_outbound_indicator = 'O')
and not exists (select 1 from dm.lpn_detail ld where ld.lpn_id = l.lpn_id);

--------------------------------------------------------------------------Kal orphaned STS
select tc_lpn_id, inbound_outbound_indicator, lpn_facility_status from dm.lpn l, dm.orders o where l.order_id = o.order_id and o.ref_field_3 = 'EC' and l.lpn_facility_status = 20 and l.d_facility_alias_id is null and l.inbound_outbound_indicator = 'O'
and l.last_updated_dttm < sysdate - 1/24
and not exists (select 1 from dm.lpn l2 where l2.tc_reference_lpn_id = l.tc_lpn_id and l2.lpn_facility_status < 90 and l2.inbound_outbound_indicator = 'O')
and not exists (select 1 from dm.lpn_detail ld where ld.lpn_id = l.lpn_id);

---------------------------------------------------------------------------------------------------------"PENDING WMS CANCEL"(from OMS)
-------------------------------------------------------------------------------------------------------------
select o.tc_order_id, ds.description STATUS
from dm.orders o, dm.do_status ds where o.do_status = ds.order_status and do_status = 200 and tc_order_id in 
('BCAR33830060_1','BCAR33844129_1','BCAR33852327_1') order by 1; 


---------------------------Check for null cntr_nbr-----------------------------------------------------------------------------------
select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;



select * from alloc_invn_dtl where stat_code = 50 and create_date_time < sysdate - 1/24;

---------------------------insert item barcode from above query---------------------------------------------------------------
Select l.tc_lpn_id
from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code = '190795847796' and ld.batch_nbr = 'EC002'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';

select * from item_cbo where item_bar_code in ('190795824810');

select item_id,cntr_nbr,task_id,old_stat_code,new_stat_code,create_date_time,mod_date_time from prod_trkg_tran where item_id in ('2401144')
and task_id = '72824612' order by MOD_DATE_TIME desc; --2416129

select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl where task_id ='18035924' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc; 

select * from DM.TASK_DTL where TASK_ID='72286820' and ITEM_ID='2405464' order by MOD_DATE_TIME desc;---if it has diff lpn id
---------------------------execute the CCF with updated cntr_nbr----------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------

select * from item_cbo where item_bar_code in ('190795538397');

select item_id,cntr_nbr,task_id,old_stat_code,new_stat_code,create_date_time,mod_date_time from prod_trkg_tran where item_id in ('2370683')
and task_id = '68968181';

select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;

select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;

select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;






select task_id, cntr_nbr,create_date_time, MOD_DATE_TIME from task_dtl where task_id ='18035924' and stat_code='40';---9

select * from task_dtl where task_id ='18035924' and stat_code='40' and cntr_nbr is not null order by MOD_DATE_TIME desc;

--9700+task id
------------------------------
----------------

select distinct(cntr_nbr) from task_dtl where task_id ='64120452' and stat_code='40' and cntr_nbr is not null;


select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;


select * from dm.lpn where manifest_nbr='UPS000016034';

Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000016034';




