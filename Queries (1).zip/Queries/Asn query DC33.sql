alter session set current_schema=wmprod44;

select ERROR_SEQ_NBR,PROC_STAT_CODE,INPT_STORE_MASTER_ID from WMPROD44.INPT_STORE_MASTER;

select * from inpt_asn_hdr where SHPMT_NBR='330001852';---SHPMT_NBR u will get it from UI

select * from ASN_HDR where SHPMT_NBR='330001852' ;

select distinct PROC_STAT_CODE, ERROR_SEQ_NBR from inpt_asn_hdr;

select * from msg_log where REF_VALUE_1='177607405';--take from UI if it is not in db
--Invalid Vendor 11567_CODE bridged for Case 00006644549816006771 send it to JESTa team.

select * from CASE_HDR where CASE_NBR='00006644549816006771';

select * from VENDOR_MASTER where VENDOR_ID='11567';--it will be blank beacuse vendor code is missing in vendor master table.
--message to gregory regarding invalid vendor code of vendor in vendor tables to download.

select * from asn_hdr;

----------immediate needs-------

select * from inpt_immd_needs;

select style,style_sfx,sec_dim,size_desc from inpt_immd_needs;

---inpt item master---

select * from inpt_item_master where style in ('CF170022','CF170032');

select * from inpt_item_master;

select distinct PROC_STAT_CODE, ERROR_SEQ_NBR from inpt_item_master;

select * from msg_log where REF_VALUE_1='178151864';
--Item Profile ID SHO does not exist