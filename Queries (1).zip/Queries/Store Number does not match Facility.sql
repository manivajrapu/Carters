----------------------------------------------------------------------------------------------------------
alter session set current_schema = DM;

select tc_order_id, store_nbr, d_facility_alias_id, major_order_grp_attr, dc_ctr_nbr, created_dttm, last_updated_dttm, do_status
from orders where do_status < 190 and store_nbr != substr(d_facility_alias_id, -4) and order_type = 'SD';
--status should be in 110 or 105
-------------------------------------------------------------------------------------------------------------------------
--Go To > Distribution Orders UI 
--In the �Miscellaneous� section under the General tab we need to change the �Federated store number� to match the �DC center number� 
--and save the changes.