alter session SET Current_schema=DM;

select o.tc_order_id, o.do_status, oli.item_name, oli.order_qty, count(*)
from orders o join order_line_item oli on o.order_id = oli.order_id and o.do_status < 130 
and o.order_type = 'EC' and do_dtl_status <> 200
group by o.tc_order_id, o.do_status, oli.item_name, oli.order_qty
having count(*) > 1;

select do_status,order_id,order_type from orders where tc_order_id = 'Y101825741_1';

select item_id, item_name,line_item_id,order_qty, orig_order_qty,ref_field3, last_updated_source from order_line_item where order_id='40915387' 
and item_name='243G856 N 3T';

select item_id, item_name,line_item_id,order_qty, orig_order_qty,ref_field3, last_updated_source from order_line_item where order_id='40909218' 
and item_name='243G864 S 3T';

select item_id, item_name,line_item_id,order_qty, orig_order_qty,ref_field3, last_updated_source from order_line_item where order_id='40909218' 
and item_name='248G257 GY 2T';

select do_status,order_id,order_type from orders where tc_order_id = 'Y101807760_1';

select item_id, item_name,line_item_id,order_qty, orig_order_qty, ref_field1, ref_field2, ref_field3, last_updated_source from order_line_item where order_id='39310224';

--BCAR23565099_1

select do_status,order_id,order_type from orders where tc_order_id = 'BCAR23565099_1';

select item_id, item_name,line_item_id,order_qty, orig_order_qty, ref_field1, ref_field2, ref_field3, last_updated_source from order_line_item where order_id='39312817';

select o.tc_order_id, o.do_status, oli.item_name, oli.order_qty, count(*)
from orders o join order_line_item oli on o.order_id = oli.order_id and o.do_status < 130 
and o.order_type = 'EC' and do_dtl_status <> 200
group by o.tc_order_id, o.do_status, oli.item_name, oli.order_qty
having count(*) > 1;

select * from lpn where tc_order_id='RCAR10001065_1';
select * from ship_wave_parm where SHIP_WAVE_NBR='201702160013';
select * from orders where EXT_PURCHASE_ORDER='00257595';
select * from lpn where tc_lpn_id in ('00008887370196542705', '00008887370196542415', '00008887370196542378', '00008887370196542514', '00008887370196542590', '00008887370196542736', '00008887370196542729', '00008887370196542620', '00008887370196542644', '00008887370196542361', '00008887370196542453', '00008887370196541821', '00008887370196542446', '00008887370196542408', '00008887370196542491', '00008887370196542347', '00008887370196542521');

select module, msg_id, msg, ref_value_1, ref_value_2, 
 method, class, msg_english, create_date_time, user_id
from msg_log where module = 'WAVE' and msg_id = '3003' 
 and create_date_time > sysdate - 1/24 and upper(msg) like '%ABORT%';
 
 select * from shipment where tc_shipment_id='CS20452675';
 
 select tc_order_id, store_nbr, d_facility_alias_id, major_order_grp_attr, dc_ctr_nbr, created_dttm, last_updated_dttm, do_status
from orders where do_status < 190 and store_nbr != substr(d_facility_alias_id, -4) and order_type = 'SD';

select SHIPMENT_STATUS, SHIPMENT_CLOSED_INDICATOR, LPN_ASSIGNMENT_STOPPED, WMS_STATUS_CODE from shipment where tc_shipment_id = 'CS20352807';