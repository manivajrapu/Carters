alter session set current_schema = DM;
----------------------------Carton Number IN PLACE OF tc_lpn_id ------------------------------------------------
select lpn_facility_status,tc_order_id,lpn_id,tc_lpn_id, last_updated_source from lpn where tc_lpn_id in ('00000197181329961267');

     Select non_inventory_lpn_flag, lpn_facility_status from dm.lpn ------ non_inventory_lpn_flag="null" has to be updated to "1"
     where tc_lpn_id = '00000197181329961267';
     
     Select * from dm.lpn_detail where lpn_id = '64681048';---------lpn detail = 90

-----------------------------------------------------------------------------------------------------------------
select do_status,order_type from orders where tc_order_id in ('39318946');
-----------------------------------------------------------------------------------------------------------------
select * from lpn_detail where lpn_id in ('63360180') and stat_code < 90;
-----------------------------------------------------------------------------------------------------------------
select * from lpn_lock where tc_lpn_id in ('00000197181329961267');
-----------------------------------------------------------------------------------------------------------------
select * from picking_short_item where tc_lpn_id in ('00000197181329961267');
-----------------------------------------------------------------------------------------------------------------
select * from alloc_invn_dtl where cntr_nbr ='00000197181329961267' and stat_code <90;
-----------------------------------------------------------------------------------------------------------------
select * from task_dtl where cntr_nbr ='00000197181329961267' and stat_code <90;
-----------------------------------------------------------------------------------------------------------------


select outbound_tracking_nbr from epc_track where manifest_nbr = 'UPS000014702';

Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000014701';

select 'ECOM' CHANNEL, manif_nbr MANIFEST, shpr_id ACCT, max(create_date_time) UPLOAD_DATE
from ups_emt_upload_rpt_hist where rpt_type = '1' 
and create_date_time > sysdate - 1
and shpr_id in ('869V6R', '015104')
group by manif_nbr, shpr_id
having count(*) = 1 
UNION ALL
select DECODE(SHIPPER_AC_NUM,'882W15','RETAIL','WHOLESALE') CHANNEL, mh.tc_manifest_id MANIFEST, shipper_ac_num ACCT, close_date UPLOAD_DATE
from manifest_hdr mh where close_date > sysdate - 1 and shipper_ac_num in ('882W15','A596Y8') and ups_pld_upload_indic is null and manifest_status_id = 90
and exists (select 1 from lpn l where l.manifest_nbr = mh.tc_manifest_id and l.lpn_facility_status = 90) 
order by MANIFEST;
