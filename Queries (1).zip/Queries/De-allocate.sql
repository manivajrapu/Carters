alter session SET Current_schema=DM;

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source,order_id from lpn where tc_lpn_id in ('99036865', '99037280', '99016094', '99037415', '99004868', '99041716', '99001072', '99048863', '99046090', '99015325', '99003813', '99001712', '99027015', '99035543');

select * from lpn where tc_lpn_id in ('99046555');

select * from lpn where tc_lpn_id='99046555' and inbound_outbound_indicator='O';

select * from picking_short_item where tc_lpn_id in ('970100014557', '970100018623', '970100014375');--tote number and lpn

select * from lpn_lock where tc_lpn_id in ('99046555');

select * from DM.ALLOC_INVN_DTL where cntr_nbr in ('99003813') and stat_code < '90';

select * from DM.TASK_DTL where Cntr_NBR in ('99003813') and stat_code < '90';

select * from ALLOC_INVN_DTL WHERE alloc_invn_dtl_id = '675131772';

----------Open Cartons--------------
select aid.STAT_CODE, aid.CNTR_NBR, aid.CARTON_NBR, aid.INVN_NEED_TYPE, aid.ALLOC_INVN_DTL_ID, lpn.tc_lpn_id, lpn.lpn_facility_status
from DM.ALLOC_INVN_DTL aid, DM.LPN 
where aid.CNTR_NBR in ('00006644549555884043', '00007160417197303652') and aid.CARTON_NBR = lpn.tc_lpn_id and aid.stat_code < '90'and lpn.lpn_facility_status < '20'; 

select distinct aid.STAT_CODE, aid.CNTR_NBR, aid.CARTON_NBR, aid.INVN_NEED_TYPE,lpn.tc_lpn_id, lpn.lpn_facility_status
from DM.ALLOC_INVN_DTL aid, DM.LPN 
where aid.CNTR_NBR in ('99015581', '99017787', '99033225') and aid.CARTON_NBR = lpn.tc_lpn_id and aid.stat_code < '90'and lpn.lpn_facility_status < '20'; 


Note:
Case_nbr is for iLPN.
Carton_nbr is for oLPN.
Cntr_nbr is for de-allocate iLPN.

select * from DM.ALLOC_INVN_DTL where carton_nbr in ('99005547') and stat_code < '90';

select * from DM.TASK_DTL where CARTON_NBR in ('00000197181583126556') and stat_code < '90';

--------------------------------CTRL-G------------------------
select ic.item_id,ic.item_name,ic.item_bar_code,pt.cntr_nbr,pt.task_id,pt.MOD_DATE_TIME
from prod_trkg_tran pt 
join item_cbo ic on ic.item_id=pt.item_id
where cntr_nbr in ('970902170868') order  by MOD_DATE_TIME desc; 

select td.task_id "Task ID",td.task_seq_nbr "Task Sequence", td.task_genrtn_ref_nbr "Wave Number",td.cntr_nbr,
             td.invn_need_type "Need Type", lh.dsp_locn "Need Location", im.item_name "Need Item", td.qty_alloc "Qty Alloc", 
             lh.locn_brcd, im.item_bar_code, td.batch_nbr
from task_dtl td, wm_inventory wi, item_cbo im, locn_hdr lh
where td.pull_locn_id = wi.location_id(+)
and td.item_id = wi.item_id(+)
and td.pull_locn_id = lh.locn_id(+)
and td.item_id = im.item_id(+)
--and (wi.location_id is null or wi.item_id is null)
--and td.stat_code =0 and td.invn_need_type in (3,51,50,57,40,53)
and td.task_id in ('18400999')
and td.create_date_time > sysdate - 10; 

select * from ALLOC_INVN_DTL WHERE alloc_invn_dtl_id = '573390100' and stat_code = '0';

select tc_lpn_id, lpn_facility_status, lpn_id, inbound_outbound_indicator from lpn where tc_lpn_Id = '00000156740089156431';


------------------Long running query----------------

select * from GV$SESSION where status='ACTIVE' and module='SQL Developer'; 

select sid,SERIAL#,username,status,SCHEMA#,SCHEMANAME,process,machine,PROCESS,program,type,sql_hash_value,sql_id,PREV_SQL_ID,module,BLOCKING_SESSION,BLOCKING_SESSION_STATUS
from V$SESSION where status = 'ACTIVE' and program='SQL Developer' and username='wms12q'; 
