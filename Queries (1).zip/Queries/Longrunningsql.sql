select * from V$SQL where SQL_TEXT like '%select
 sum(wi.on_hand_qty)
from%';
select * from GV$SESSION where module='SQL Developer'; 

select * from v$sql where SQL_ID='dch3858dv03ra';