select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status < 190 and lpn_facility_status = 90 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status < 80 );

select * from shipment where tc_shipment_id='CS22264396';--WILL BE IN 60 ACCEPTED STATUS

select tc_lpn_id, tc_order_id, tc_shipment_id, lpn_facility_status from lpn where tc_lpn_id='00000197181540560188';--WILL BE IN 90 STATUS 

THEN GO TO UI AND SHIPMENT AND CLOSE BUT UNCHECK THE INVOICE TRAILER BOX.
