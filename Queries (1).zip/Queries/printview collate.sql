alter session set current_schema=DM;

select tc_order_id,lpn_facility_status from lpn where tc_lpn_id='00000197181538210842'; --CAR25443626_1

select * from orders where tc_order_id='CAR25443626_1'; --Goleta,CA

select * from postal_code where city='GOLETA';--93111

Actually before it was return 93111-1436
so that postal code to that city is not matching.
