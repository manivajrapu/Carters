alter session set current_schema=DM;
 
select tc_order_id,tc_lpn_id,tc_reference_lpn_id,lpn_facility_status,tc_shipment_id,ship_via from lpn where tc_order_id in ('BCAR30927784_1');--BCAR29264497,BCAR28782813_1
--scenario 1
--master carton or tc_reference_lpn_id
--if that master olpn in 20 and lpn will be in 35 then manifest it should go to 40 status.
--we have to check master carton it is manifested or not and if not manifested then manifest through weigh and manifest UI and max it will be in manifested status.
--perform ship confirm and ship confirm will go to 90. --equals to master lpn and it should be lpn number equals that master lpn.
--close shipment but no invoice trigger alert after sometime.
--after sometime we will get carton in shipped status issue alert will trigger then close the shipment but do not invoice.
 
--2
--20 packed
--no master lpn only lpn_id
--they will have lock so remove lock for that go to olpn and click lock/unclock go there and select lock and give unlock and save.
--after that manifest the carton it will go from 20 or 35 to 40
--we should put actual weight and estimated weight should be equal and ship_via compare with db and put in UI when manifesting the ilpn.
--ship confirm will go to 90 and it should be lpn number equals that lpn number.
--after that do_status will go to 190 status.
--not needed to close shipment
 
select do_status from orders where tc_order_id = 'CAR30403493_1'; --it will go to 190(shipped).
select * from lpn where tc_lpn_id='00000197181615587737'; --it will be in 90.
select * from shipment WHERE TC_SHIPMENT_ID = 'CS29416413';  --it will be in 60.
select tc_lpn_id, tc_order_id, tc_shipment_id, lpn_facility_status from lpn where tc_lpn_id='00000197181615587737';--WILL BE IN 90 STATUS

select * from picking_short_item where tc_lpn_id in ('00000197181615587737')and stat_code < '90';
select * from lpn_lock where tc_lpn_id in ('00000197181615587737 ');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181615587737') and stat_code < '90';
select * from DM.TASK_DTL where CARTON_NBR in ('00000197181615587737') and stat_code < '90';
---------------------------------------------------------------------------------------------------------------UPS manifest
select 'ECOM' CHANNEL, manif_nbr MANIFEST, shpr_id ACCT, max(create_date_time) UPLOAD_DATE
from ups_emt_upload_rpt_hist where rpt_type = '1' 
and create_date_time > sysdate - 1
and shpr_id in ('869V6R', '015104')
group by manif_nbr, shpr_id
having count(*) = 1 
UNION ALL
select DECODE(SHIPPER_AC_NUM,'882W15','RETAIL','WHOLESALE') CHANNEL, mh.tc_manifest_id MANIFEST, shipper_ac_num ACCT, close_date UPLOAD_DATE
from manifest_hdr mh where close_date > sysdate - 1 and shipper_ac_num in ('882W15','A596Y8') and ups_pld_upload_indic is null and manifest_status_id = 90
and exists (select 1 from lpn l where l.manifest_nbr = mh.tc_manifest_id and l.lpn_facility_status = 90) 
order by MANIFEST;


 
BCAR26611886
00000197181568195911
 
select tc_order_id,tc_lpn_id,tc_reference_lpn_id,lpn_facility_status,tc_shipment_id,ship_via from lpn where tc_order_id in ('BCAR27426270_1');
 
select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status < 190 and lpn_facility_status = 90 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status < 80 );
 
select SHIPMENT_STATUS,SHIPMENT_CLOSED_INDICATOR,LPN_ASSIGNMENT_STOPPED,WMS_STATUS_CODE from shipment WHERE TC_SHIPMENT_ID = 'CS23565238';
 
select * from shipment WHERE TC_SHIPMENT_ID = 'CS23729738';
 
CS23553874
 
select SHIPMENT_STATUS,SHIPMENT_CLOSED_INDICATOR,LPN_ASSIGNMENT_STOPPED,WMS_STATUS_CODE from shipment WHERE TC_SHIPMENT_ID = 'CS23553874';
 
select * from lpn where tc_lpn_id='00000197181556956166';
 
select tc_lpn_id, tc_reference_lpn_id, lpn_facility_status, ship_via, tracking_nbr from lpn where tc_order_id like 'BCAR%' and lpn_facility_status = 20 and exists (select 1 from lpn_lock ll where  ll.lpn_id = lpn.lpn_id) and last_updated_dttm < sysdate - 3;
 
select * from UCL_USER where user_name='195541';