alter session set current_schema = DM;

select on_hand_qty, wm_allocated_qty from wm_inventory where tc_lpn_id = 'EXC_171120_001194145';---1,0

select * from task_dtl where cntr_nbr = 'EXC_171120_001194145'  and stat_code < 90;
--(This should come back with 0 records)

select * from alloc_invn_dtl where cntr_nbr = 'EXC_171120_001194145' and stat_code < 90;
--(This should come back with 0 records)

select * from lpn where TC_LPN_ID in('00000156740102086899');

select LPN_FACILITY_STATUS,LPN_STATUS,LPN_ID,total_lpn_qty from lpn where TC_LPN_ID in ('00000156740102086899');

-------------------------------
Select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS, total_lpn_qty from lpn where TC_LPN_ID in('EXC_171120_001194145');--99

Select on_hand_qty,lpn_detail_id, wm_allocated_qty, location_id from wm_inventory where tc_lpn_id = 'EXC_171120_001194145';

Select lpn_id, size_value,LPN_DETAIL_STATUS, lpn_detail_id, size_value from lpn_detail where lpn_id = '159622923';

-------------------------------

--Check for the LPN details in lpn_detail table using below query:

Select lpn_id, size_value,LPN_DETAIL_STATUS, lpn_detail_id, size_value from lpn_detail where lpn_id = '149862298';--30, 0

--Check for the lpn detail id and location id in wm_inventory table using below query:

Select lpn_id, LPN_DETAIL_ID, location_id from wm_inventory where TC_LPN_ID  = '00000156740102086899';-----null,303654416

Select lpn_id, LPN_DETAIL_ID,on_hand_qty, wm_allocated_qty from wm_inventory where lpn_detail_id = '303654416';----1,0

Select lpn_id, LPN_DETAIL_ID,on_hand_qty, wm_allocated_qty from wm_inventory where lpn_detail_id = '303659899';----0, null

Select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS from lpn where TC_LPN_ID = '00000156740071103627';---null

Select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id from lpn_detail where lpn_id = '119085086';

Select lpn_id, LPN_DETAIL_ID, location_id from wm_inventory where TC_LPN_ID = '00000156740071103627';

