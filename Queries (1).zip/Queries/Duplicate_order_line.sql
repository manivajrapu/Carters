alter session set current_schema = DM;

Select do_status from orders where tc_order_id = 'Y101794739_1';

Select order_id from orders where tc_order_id = 'Y101794739_1';

Select item_name, item_id, line_item_id, order_qty, orig_order_qty, ref_field3 from order_line_item where order_id = �39192215�;

--run ccf--