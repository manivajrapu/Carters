alter session SET Current_schema=DM;

select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);
------------------------------------------------------------

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source,order_id,
INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('00000197181331851877'); 
select do_dtl_status from order_line_item where order_id = '43984426' and item_id = '2365045';--item_id from lpn table 



-----------------------------------------------------------------------------------------------------------
--for the case it is case in task_dtl and alloc_invn_dtl
--for the carton it is task_dtl is carton_nbr and for alloc_invn_dtl is cntr_nbr
----------------------------------
--carton_nbr for dc33----------
select * from lpn where tc_lpn_id='00000197181543268395' and inbound_outbound_indicator='I';--orphand aid 52
select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source,manifest_nbr,order_id,item_id from lpn where tc_lpn_id in ('00000197181331181820');
select * from lpn_detail where lpn_id in ('67319370') and lpn_detail_status<'90';
select do_status,order_id,order_type from orders where tc_order_id in ('39318955');
----if having vas lock ----------------
---stat_code is 10 then vas is not completed.then ask user to complete.
---when it is in 90 or 95 or 99 then we can remove vas lock through ccf.
---here reqd_qty and cmpl_qtd should be same. 
select * from vas_carton where carton_nbr='';
---------------------------------------
select * from picking_short_item where tc_lpn_id in ('00000197181331851877') and stat_code<90;
select * from lpn_lock where tc_lpn_id in ('00000197181331851877');
select * from DM.ALLOC_INVN_DTL where cntr_nbr in ('00000197181331851877') and stat_code < '90';--carton_nbr for dc33
select * from DM.ALLOC_INVN_DTL where alloc_invn_dtl_id = '65535431';
select stat_code from task_hdr where task_id = '62490104';
select * from task_hdr;
select * from DM.TASK_DTL where CARTON_NBR in ('00000197181331851877') and stat_code < '90';--970062490104
select stat_code from dm.task_hdr where task_id = '62490104';
select stat_code from DM.TASK_DTL where task_id='62490104' and stat_code < '90';
select count(*) from task_dtl where cntr_nbr = '970062490104' and stat_code < 90;
select count(*) from dm.task_dtl where task_id = '62490104' and stat_code < '90';
----- order status in 200 then cancel it in ui also--
select tc_lpn_id,lpn_facility_status from lpn where tc_order_id='BCAR25813801 ';---if having any 10 or any data less than 20 then pack only lpn not order status
select tc_order_id,tc_lpn_id,lpn_facility_status from lpn where tc_order_id in ('BCAR26003871_1','BCAR25984724_1','BCAR25986536_1','BCAR25974196_1');
select * from order_line_item where order_id='43828979';
select do_dtl_status from order_line_item where order_id='44004390';--do_dtl_status=200--then we can cancell
select distinct do_dtl_status from order_line_item where order_id='43861817';
select * from order_line_item;
---------------------------------------------------
select allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id='40494710' and item_id='2141782';
select * from wm_inventory where tc_lpn_id in ('970062490104') and item_id='2141782';--608657392

-----------shannon query--

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source,order_id,INBOUND_OUTBOUND_INDICATOR,item_id from lpn where tc_lpn_id in ('00000197181544246675');

select do_status,order_id,order_type from orders where tc_order_id in ('CAR25893725_1');

select lpn_facility_status,tc_lpn_id from lpn where tc_order_id = 'CAR25893725_1';
select * from lpn where tc_order_id = 'CAR25893725_1';
--if this lpn table has only one lpn then we can pack orders.
--check if order hs multiple cartons and when the all the olpns is packed we update the order also....if some are in 10 status we dont
select lpn_facility_status from lpn where tc_order_id = '39319916';

select * from lpn where tc_order_id = '44021630';

select tc_lpn_id,lpn_facility_status from lpn where tc_order_id='1220193938';

select  distinct line_item_id,do_dtl_status from order_line_item where order_id='43984428' and item_id='2365045';--do_dtl_status=200--then we can cancell
select do_dtl_status from order_line_item where order_id = '43984426' and item_id = '2365045';


select * from UCL_USER where user_name='enrvish';







select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);
