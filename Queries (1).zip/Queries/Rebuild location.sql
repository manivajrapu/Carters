alter session set current_schema=DM;

select * from locn_hdr where dsp_locn in ('USM0101004');--POSR16686,POSR10656,POSR01481,POSR07848,POSR04417
select actl_invn_cases, to_be_filld_cases from pick_locn_dtl where locn_id ='0020186';

select TO_BE_FILLED_QTY,LAST_UPDATED_SOURCE from DM.WM_INVENTORY where LOCATION_ID='100352497' order by LAST_UPDATED_DTTM desc;--0008825

select * from task_dtl where pull_locn_id = '0004232' and stat_code<90;

select * from alloc_invn_dtl where pull_locn_id = '0004232' and stat_code<90;

select lh.dsp_locn, ic.item_name, aid.cntr_nbr, aid.stat_code, aid.*
from alloc_invn_dtl aid, locn_hdr lh, item_cbo ic
where aid.dest_locn_id = lh.locn_id and aid.item_id = ic.item_id
and aid.stat_code < '90'
and lh.dsp_locn like 'USM0101001%';

-----------------------------------------------------------------------------------------------------------------
select distinct locn_class from locn_hdr;


select distinct actl_invn_cases, to_be_filld_cases from pick_locn_dtl where locn_id in ('0004231');    
---here for all rebuild location to_be_filled_qty and actual_cases should be same and if it is different also rebuild but confirm it once.
--It both should be 0.

select * from pick_locn_dtl where locn_id = '0004240';

 
































