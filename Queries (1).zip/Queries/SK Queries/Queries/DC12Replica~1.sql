Select manifest_nbr, substr(tc_shipment_id,10,1) "SHIPMENT_ENDING", lpn_facility_status, count(*) from lpn where manifest_nbr = 'FXGD000009270' 
and lpn_facility_status < 99 group by manifest_nbr, substr(tc_shipment_id,10,1), lpn_facility_status;

Select tc_lpn_id from lpn where manifest_nbr = 'FXGD000009270' and    lpn_facility_status < 90;

