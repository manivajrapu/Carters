alter session set current_schema = DM;

---------------------------Check for null cntr_nbr-----------------------------------------------------------------------------------
select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;
---------------------------insert item barcode from above query---------------------------------------------------------------
Select l.tc_lpn_id
from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code = '190796054339' and ld.batch_nbr = 'ECOM'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';
---------------------------execute the CCF with updated cntr_nbr----------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------

select * from item_cbo where item_bar_code in ('889338637900','889338637894','190795093742','190795018561','889338642485','190796054018','190795104059','190796054339','190795017960','889338604285','190795003079');

select item_id,cntr_nbr,task_id,old_stat_code,new_stat_code,create_date_time,mod_date_time from prod_trkg_tran where item_id in ('2265929','2294837','2308395','2286399','2288764','2291907')
and task_id = '60520310';

Select l.tc_lpn_id
from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code = '889338627475' and ld.batch_nbr = 'EC002'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';

select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl where task_id in('68595094') 
and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc;
--970068595081    68595081
--970068595085    68595085
--970068595094    68595094



select task_id, cntr_nbr,create_date_time, MOD_DATE_TIME from task_dtl where task_id ='61791468' and stat_code='40' and cntr_nbr is null;---9

select * from task_dtl where task_id ='60520310' and stat_code='40' and cntr_nbr is not null order by MOD_DATE_TIME desc;

----------------------------------------------

select distinct(cntr_nbr) from task_dtl where task_id ='60673897' and stat_code='40' and cntr_nbr is not null;


select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;




