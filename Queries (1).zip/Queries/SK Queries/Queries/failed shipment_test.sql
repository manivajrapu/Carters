alter session SET Current_schema=DM;

-----------------------------------------------------Alert_Query-------------------------------

select invc_batch_nbr, count(*) ORDERS from dm.outpt_orders where proc_stat_code < 90 and created_dttm < sysdate - 1/24 group by invc_batch_nbr;
-------------------------------------------------------------------------------------------------------

select tc_order_id,invc_batch_nbr from outpt_orders oo where invc_batch_nbr = '121192534' and not exists 
(select 1 from outpt_order_line_item oli where oo.invc_batch_nbr = oli.invc_batch_nbr and oo.tc_order_id = oli.tc_order_id);

select * from outpt_orders where batch_ctrl_nbr in ('121192534') and tc_order_id='BCAR32877787_1';

Select * from DM.OUTPT_ORDER_LINE_ITEM where batch_ctrl_nbr in ('121058184') and tc_order_id='BCAR32877787_1';
-----------------------------------------------------------------------------------------------------------------------------------
select * from OUTPT_LPN where INVC_BATCH_NBR in ('121058184') and tc_order_id='BCAR32877787_1';

Select * from OUTPT_LPN_DETAIL where INVC_BATCH_NBR='121058184' and MINOR_PO_NBR='BCAR32877787_1';

Select * from OUTPT_LPN_DETAIL where INVC_BATCH_NBR='121058184' and MINOR_ORDER_NBR='BCAR32877787_1';

select * from DM.OUTPT_ORDERS;

----------------------------------21 August 2018
Select * from dm.outpt_orders where batch_ctrl_nbr = '121192534';--null

Select * from dm.outpt_order_line_item where batch_ctrl_nbr = '121192534';--null

Select * from OUTPT_LPN where INVC_BATCH_NBR='121192534';--1 proc stat code 0

Select * from OUTPT_LPN_DETAIL where INVC_BATCH_NBR='121192534';--null



select shipment_status, shipment_closed_indicator, lpn_assignment_stopped, wms_status_code from shipment where tc_shipment_id in ('CS37423318');

select DISTINCT tc_order_id,tc_shipment_id from lpn where tc_shipment_id in ('CS37423318','CS37423314');

select tc_order_id, do_status from orders where tc_order_id in ('1229708707','1229765494','1229691198','1229698178');

select tc_order_id,tc_lpn_id,lpn_facility_status,tc_shipment_id from lpn where tc_shipment_id in ('CS37423318','CS37423314');

