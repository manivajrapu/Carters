alter session set current_schema = DM;

---alert query All In-packing -- IF SHOWING , THEN DO THRU RF, OTHERWISE DO THRU SYS_CODE 'LPN_TO_20'
select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status,LAST_UPDATED_SOURCE,INBOUND_OUTBOUND_INDICATOR,LAST_UPDATED_SOURCE 
from lpn where lpn_facility_status <20 and inbound_outbound_indicator = 'O' and d_facility_alias_id is not null
and tc_lpn_id in ('00000197181350181078', '00000197181350287022', '00000197181350223556', '00000197181350369643', '00000197181350370359', '00000197181349696286', '00000197181350372520', '00000197181350291630');
------------
select DO_STATUS, tc_order_id, order_id from orders where tc_order_id In ('1230601813');--CAR36919838_1--170
select * from shipment where tc_shipment_id in('CS38571164');
SELECT do_dtl_status,order_id FROM order_line_item where order_id in ('66023810','66036323') and do_dtl_status<'150';--CAR36863436_1
-------------
select tc_lpn_id,lpn_facility_status,INBOUND_OUTBOUND_INDICATOR,TOTAL_LPN_QTY, tc_reference_lpn_id from lpn where tc_lpn_id in ('00000197181350369643');
select * from picking_short_item where tc_lpn_id in ('00000197181350181078', '00000197181350287022', '00000197181350223556', '00000197181350369643', '00000197181350370359', '00000197181349696286', '00000197181350372520', '00000197181350291630') and stat_code<'90';
select * from lpn_lock where tc_lpn_id in ('00000197181350181078', '00000197181350287022', '00000197181350223556', '00000197181350369643', '00000197181350370359', '00000197181349696286', '00000197181350372520', '00000197181350291630');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181350181078', '00000197181350287022', '00000197181350223556', '00000197181350369643', '00000197181350370359', '00000197181349696286', '00000197181350372520', '00000197181350291630') and stat_code < '90';
select * from DM.task_dtl where carton_nbr in ('00000197181350181078', '00000197181350287022', '00000197181350223556', '00000197181350369643', '00000197181350370359', '00000197181349696286', '00000197181350372520', '00000197181350291630') and stat_code < '90';
select qty_alloc, qty_pulld, task_id, curr_work_area, curr_work_grp, invn_need_type from DM.TASK_DTL where cntr_nbr in ('EXC_090918_000508841') and stat_code < '90';
select qty_alloc, qty_pulld, task_id, curr_work_area, curr_work_grp, invn_need_type from task_dtl where task_id in ('88333854') and stat_code<90;
select qty_alloc, qty_pulld, task_id, curr_work_area, curr_work_grp, invn_need_type from DM.ALLOC_INVN_DTL where cntr_nbr in ('970089204977') and stat_code<90;
select alloc_invn_dtl_id, cntr_nbr, invn_need_type, carton_nbr  from alloc_invn_dtl where cntr_nbr in ('970089204977') and stat_code < '90';
select * from task_grp_elgblty where invn_need_type='51';
----
-- These are retail cartons for PTS (Put to Store)
select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and d_facility_alias_id is not null 
and TC_LPN_ID in ('00000197181715374879');

--These are STS cartons (BOSS)
select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and misc_instr_code_3 > 0 and d_facility_alias_id is  null
and TC_LPN_ID in ('00000197181715374886','00000197181715374879'); 
----Sortrack PANDA Carton Query below to check QTY DISCREPENCY in oLPNS UI and in DB--- 
select eq.msg_id, eq.status ST, error_count EC, m.event_id E_ID, eq.endpoint_id EP_ID, m.source_id, regexp_substr(to_char(m.data), '[^/^]+', 1, 10) "QTY", eq.when_queued, eq.when_status_changed, m.data
from cl_endpoint_queue eq, cl_message m  where m.msg_id = eq.msg_id 
and eq.when_queued > sysdate -1
and m.source_id = 'SORTRAK_CARTONCLOSE'
and m.data like '%00000197181345896130%'
order by eq.when_status_changed desc;
---
select tc_lpn_id,lpn_facility_status from  lpn where tc_lpn_id in ('00000197181345896130','00000197181344911179');
---
select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source,order_id,TOTAL_LPN_QTY,
INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('00000197181561082201'); 


select * from lpn where tc_lpn_id in ('00000197181679451883');
select * from lpn where tc_lpn_id in ('00000197181679451791');

select * from DM.ORDERS where TC_ORDER_ID in ('1228524724');
select * from DM.ORDERS where TC_ORDER_ID in ('1228524716');

select * from DM.SHIPMENT;





select distinct stat_code from alloc_invn_dtl where carton_nbr in ('00000197181561082201');

select distinct stat_code from task_dtl where carton_nbr in ('00000197181561013939');

select * from picking_short_item where tc_lpn_id in ('00000197181328785994','00000197181328725969','00000197181328726072','00000197181328808587','00000197181328585723','00000197181328654733');

select * from lpn_lock where tc_lpn_id in ('00000197181329332470');

select lpn_facility_status,tc_lpn_id from lpn where tc_order_id in ('CAR26873738_1');    --if multiple LPNs don't pack

-- stat code=10'not started' inform user complete task process
--stat code=90/99 remove vas lock through ccf

select * from vas_carton where carton_nbr ='';    --to check vas lock
   alter session set current_schema = DM;

00000197181329332470
00000197181329271489
00000197181329324789
00000197181329358340
00000197181329379222


63328572
63326242
63330190
63321798
63326271


select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source from lpn where tc_lpn_id in ('00000197181329332470','00000197181329271489','00000197181329324789','00000197181329358340','00000197181329379222');
select * from lpn_detail where lpn_id in ('63328572','63326242','63330190','63321798','63326271') and lpn_detail_status<'90';
select do_status,order_type from orders where tc_order_id in ('39318829',
'39318884',
'39318765',
'39318726',
'39318872');
select * from picking_short_item where tc_lpn_id in ('00000197181345483965', '00000197181345454767', '00000197181345462267', '00000197181345455061', '00000197181345310179', '00000197181345484535', '00000197181345409101', '00000197181345454781', '00000197181345464186', '00000197181345408951', '00000197181345310117');
select * from lpn_lock where tc_lpn_id in ('00000197181345483965', '00000197181345454767', '00000197181345462267', '00000197181345455061', '00000197181345310179', '00000197181345484535', '00000197181345409101', '00000197181345454781', '00000197181345464186', '00000197181345408951', '00000197181345310117');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181345483965', '00000197181345454767', '00000197181345462267', '00000197181345455061', '00000197181345310179', '00000197181345484535', '00000197181345409101', '00000197181345454781', '00000197181345464186', '00000197181345408951', '00000197181345310117') and stat_code < '90';
select * from DM.TASK_DTL where CARTON_NBR in ('00000197181345483965', '00000197181345454767', '00000197181345462267', '00000197181345455061', '00000197181345310179', '00000197181345484535', '00000197181345409101', '00000197181345454781', '00000197181345464186', '00000197181345408951', '00000197181345310117') and stat_code < '90';
------------------------------------------------------------------------------------------------------------------------------------
select tc_order_id,tc_lpn_id from lpn where tc_order_id in ('CAR24314253_1');
select allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id='40494710' and item_id='2141782';
select * from wm_inventory where tc_lpn_id in ('00000197181329226274','00000197181329227110') and item_id='2141782';--608657392

select * from sys_code where code_type in ('CCF');



select tc_order_id from lpn where tc_lpn_id in ('00000197181348188799');

select do_status from orders where tc_order_id in ('55205971');

SELECT 