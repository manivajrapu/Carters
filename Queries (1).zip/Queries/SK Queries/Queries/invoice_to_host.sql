--There is a single shipment:
select * from OUTBD_SHPMT os where os.shpmt_nbr in (select oos.shpmt_nbr from outpt_outbd_stop oos where oos.INVC_BATCH_NBR = '330438904');  --1

--There is a single load:
select * from outpt_outbd_load where INVC_BATCH_NBR = '330438904';   --1

--There is a single stop:
select * from OUTPT_OUTBD_STOP where INVC_BATCH_NBR = '330438904';   --1

--There is a single pick ticket:
select * from outpt_pkt_hdr where INVC_BATCH_NBR = '330438904';     --1

--There are 16 pick ticket details:
select * from outpt_pkt_dtl where INVC_BATCH_NBR = '330438904';    --12

--There are 2,200 cartons:
select * from outpt_carton_hdr where INVC_BATCH_NBR = '330438904';  --2340

--There are 35,200 carton details (the carton header and carton detail lines combine to create the issue for the size of the XML being created).
select * from outpt_carton_dtl where INVC_BATCH_NBR = '330438904';  --28080


select distinct(pkt_ctrl_nbr) from outpt_carton_hdr where INVC_BATCH_NBR = '330438904'; 
---if this is having only one single pickticket then brian will do.
---if this is having multiple pickticket then we will do.
