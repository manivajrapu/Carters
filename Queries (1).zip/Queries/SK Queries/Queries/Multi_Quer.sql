alter session SET Current_schema=DM;
-------------------------------------------------UPS Manifest Upload-------------------------------------------------------------------------------

select 'ECOM' CHANNEL, manif_nbr MANIFEST, shpr_id ACCT, max(create_date_time) UPLOAD_DATE
from ups_emt_upload_rpt_hist where rpt_type = '1' 
and create_date_time > sysdate - 1
and shpr_id in ('869V6R', '015104')
group by manif_nbr, shpr_id
having count(*) = 1 
UNION ALL
select DECODE(SHIPPER_AC_NUM,'882W15','RETAIL','WHOLESALE') CHANNEL, mh.tc_manifest_id MANIFEST, shipper_ac_num ACCT, close_date UPLOAD_DATE
from manifest_hdr mh where close_date > sysdate - 1 and shipper_ac_num in ('882W15','A596Y8') and ups_pld_upload_indic is null and manifest_status_id = 90
and exists (select 1 from lpn l where l.manifest_nbr = mh.tc_manifest_id and l.lpn_facility_status = 90) 
order by MANIFEST;

-------------------------------------------------------------------------------------------------------------------------------------------------------------

select TC_SHIPMENT_ID,TC_LPN_ID,TC_ASN_ID from LPN where TC_LPN_ID in('00000197181572894411');  --wrong query

select ASN_ID,TC_SHIPMENT_ID from ASN where TC_SHIPMENT_ID='CS24886859';

SELECT * FROM DM.ASN where TC_SHIPMENT_ID in('CS26289236');

select TC_LPN_ID,TC_SHIPMENT_ID,LPN_FACILITY_STATUS,LAST_UPDATED_SOURCE from LPN where tc_lpn_id in ('00000197181587102488');

select LPN_LOCK_ID,INVENTORY_LOCK_CODE from lpn_lock;
----------------------------------------------------------------------------------------------

select TASK_ID, cntr_nbr, INVN_TYPE,ITEM_ID,TC_ORDER_ID from DM.TASK_DTL where TASK_ID in ('69461817','69461818');

select * from orders where TC_ORDER_ID in ('RCAR10071540_1');

select * from orders where TC_ORDER_ID in ('RCAR10071551_1');
--------------------------------------------------------------------------------------------------------------------


select TRACKING_NBR,TC_LPN_ID,TC_ORDER_ID,TC_SHIPMENT_ID, from dm.lpn where tracking_nbr in ('942570777320757','942570777372077'); 
Select * from DM.LPN_LOCK where TC_LPN_ID in('00000197181573486998','00000197181574010130');

select * from DM.PROD_TRKG_TRAN where cntr_nbr = '00000197181573486998' order by CREATE_DATE_TIME desc;
select * from DM.PROD_TRKG_TRAN where cntr_nbr = '00000197181574010130' order by CREATE_DATE_TIME desc; 
----------------------------------------------------------------------------------------------------------------------------------------------------

-------if case not found do these checks---------
select * from item_master where style='CF170451' and SIZE_DESC='10';
select CASE_NBR,total_alloc_qty from CASE_DTL where SKU_ID in ('117045202','117052739') and total_alloc_qty <>0;
------------------------------------------------- Invoicing Errored Out---------------------------------------------------------------------------

select distinct(pkt_ctrl_nbr), invc_batch_nbr,CARTON_NBR,sta from outpt_carton_hdr where load_nbr = '3300109672'; 

select LOAD_NBR,STAT_CODE,SHIP_VIA,CAR  from OUTBD_LOAD where load_nbr in ('3300109672','3300109671','3300109670'); 

select*  from CARTON_HDR where LOAD_NBR = '3300109672' and CARTON_NBR in('00000197183481977469') --,'00000197183481991588','00000197183481754381'
UNION
select*  from CARTON_HDR where LOAD_NBR = '3300109670' and CARTON_NBR in('00000197183481754381') 
UNION
select*  from CARTON_HDR where LOAD_NBR = '3300109671' and CARTON_NBR in('00000197183481991588'); 

select plan_load_nbr, plan_bol, plan_master_bol, plan_shpmt_nbr from pkt_hdr where PKT_CTRL_NBR in (select distinct PKT_CTRL_NBR from carton_hdr where load_nbr in ('3300109670') AND carton_nbr in ('00000197183481754381'))
UNION
select plan_load_nbr, plan_bol, plan_master_bol, plan_shpmt_nbr from pkt_hdr where PKT_CTRL_NBR in (select distinct PKT_CTRL_NBR from carton_hdr where load_nbr in ('3300109671') AND carton_nbr in ('00000197183481991588'))
UNION
select plan_load_nbr, plan_bol, plan_master_bol, plan_shpmt_nbr from pkt_hdr where PKT_CTRL_NBR in (select distinct PKT_CTRL_NBR from carton_hdr where load_nbr in ('3300109672') AND carton_nbr in ('00000197183481977469'));

--------------------------------------------------Print Collate---------------------------------------------------------------------------

Select TC_SHIPMENT_ID,TC_LPN_ID,LPN_FACILITY_STATUS from lpn where TC_LPN_ID ='00000197181578084014';

SELECT TC_SHIPMENT_ID,SHIPMENT_STATUS,O_ADDRESS,O_CITY,O_STATE_PROV,O_POSTAL_CODE,D_ADDRESS,D_CITY,D_STATE_PROV,D_POSTAL_CODE FROM DM.SHIPMENT where TC_SHIPMENT_ID ='CS26538037';

select SHIPMENT_STATUS, SHIPMENT_CLOSED_INDICATOR, LPN_ASSIGNMENT_STOPPED, WMS_STATUS_CODE from shipment where tc_shipment_id = 'CS25146491';

------------------------------------------------------------------------------------------------------------------------------------------------

select * from DM.TASK_DTL where TASK_ID='69550969' and  stat_code < '90';

select * from POSTAL_CODE where postal_code in ('00953');
select TC_LPN_ID,TC_SHIPMENT_ID,ship_via,LAST_UPDATED_SOURCE from lpn where TC_LPN_ID in('00000197181579839187');
select * from shipment where TC_SHIPMENT_ID in('CS25631019')


desc orders;
------------------------------------------------------Release MHE Messages Alert---------------------------------------------------------------
with a as (select unique td.task_genrtn_ref_nbr, th.task_id, th.stat_code, th.mhe_flag,
                    decode(swp.wave_desc, 'eCOM Unit Sorter Wave', '7019','Wholesale Unit Sorter Wave','7019','Put Wall from EPM','7019','Chase Wave','7022','7017') EVENT_ID
     from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
     and th.invn_need_type in(3,51) and th.stat_code = 10 and th.mhe_flag = 'N' and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)
and
not exists (select 1 from event_message_history em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90);

---------------------------------------------------Query Builder---------------------------------------------------------------------

SELECT CNTR_NBR, (select dsp_locn from locn_hdr, case_hdr where locn_hdr.locn_id = case_hdr.locn_id and case_nbr = cntr_nbr) as location, 
dsp_sku, INVN_NEED_TYPE, SUM(QTY_ALLOC), alloc_invn_dtl.STAT_CODE 
FROM ALLOC_INVN_DTL, PKT_DTL, item_master, case_hdr ch WHERE INVN_NEED_TYPE = 60 AND alloc_invn_dtl.STAT_CODE < 90 
and alloc_invn_dtl.sku_id = item_master.sku_id
AND alloc_invn_dtl.pkt_ctrl_nbr = pkt_dtl.pkt_ctrl_nbr and alloc_invn_dtl.CNTR_NBR = ch.case_nbr
and alloc_invn_dtl.pkt_seq_nbr = pkt_dtl.pkt_seq_nbr and pkt_dtl.wave_nbr = '201709010050'
GROUP BY CNTR_NBR, ch.locn_id, dsp_sku, INVN_NEED_TYPE, ALLOC_INVN_DTL.STAT_CODE;


--------------------------------------Manifest Errored Out------------------------------------------------------------

select CARTON_NBR,PKT_CTRL_NBR,STAT_CODE,MANIF_NBR,SHIP_VIA from CARTON_HDR where MANIF_NBR in('0041490');

select CARTON_NBR,PKT_CTRL_NBR,STAT_CODE,MANIF_NBR,SHIP_VIA from CARTON_HDR where MANIF_NBR in('0041705');

select CARTON_NBR,PKT_CTRL_NBR,STAT_CODE,MANIF_NBR,SHIP_VIA from CARTON_HDR where MANIF_NBR in('0041706');

SELECT CASE_NBR,INVN_LOCK_CODE,LOCK_CNT FROM CASE_LOCK where CASE_NBR in('00000197183480956366');

select * from MANIF_PARCL_HDR where STAT_CODE=15;
---------------------------------------------------------------------------------------------------------------
select count(*) from MANIF_PARCL_HDR where STAT_CODE ='15';
select SHIP_WAVE_NBR,SHIP_WAVE_PARM_ID,STAT_CODE,PICK_WAVE_NBR from SHIP_WAVE_PARM where PICK_WAVE_NBR in ('201708280017');--'201709270087','201709280016',);

select ALLOC_INVN_DTL_ID,ALLOC_INVN_DTL_ID,INVN_NEED_TYPE,INVN_TYPE,TASK_GENRTN_REF_NBR,TASK_CMPL_REF_NBR,STAT_CODE from ALLOC_INVN_DTL where TASK_GENRTN_REF_NBR in ('201709270087','201709280016');

select * from alloc_invn_dtl where TASK_GENRTN_REF_NBR in ('201709280016') and stat_code < 90;

select * from task_dtl where TASK_GENRTN_REF_NBR in('201708280017') and stat_code < 90;
---------------------------------------------------------------------------------------------------------------------

select * from pix_tran where tran_nbr in (
'137997339','137999076','138085271','138083024','138136150','137997238','138166658','138084726','137923979','138085198','138217321','138016659','138084648','137941713'
);
--------------------------------------------------task Issue