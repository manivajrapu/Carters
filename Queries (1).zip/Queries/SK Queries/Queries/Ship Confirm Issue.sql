alter session SET Current_schema=DM;

select tc_order_id, tc_lpn_id, tc_reference_lpn_id from lpn where tc_order_id in ('BCAR37353908_1');