select style, style_sfx , SEC_DIM, SIZE_DESC from inpt_IMMD_NEEDS;
select * from item_master where style in ('CF170482','v'); 

select * from item_master where style in ('OF170740') and size_desc in ('12') and style_sfx in ('AST'); 