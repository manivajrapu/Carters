alter session SET Current_schema=DM;

---Alert query for Task Error : iLPN does not exist
select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;
--89588689--970100017860
---------------------------------
select * from item_cbo where item_bar_code in ('889338809420');--970100002837

select item_id,cntr_nbr,task_id,old_stat_code,new_stat_code,create_date_time,mod_date_time from prod_trkg_tran where 
item_id in ('2572541') and task_id = '86392211'; 
-------------------
TASK ERROR ILPN DOES NOT EXIST : INT 3 SPECIAL CASES

select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl where task_id ='86518182' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc; 
select task_id,cntr_nbr,stat_code from DM.TASK_DTL where task_id in ('86518182');
select TASK_ID,INVN_NEED_TYPE from DM.TASK_HDR where task_id in ('84776226');
--------------------------------------------------------------------------------------------------------------------------------------
Select l.tc_lpn_id
from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code in ('190795483390') and ld.batch_nbr = 'EC002'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';

select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl 
where task_id ='74276341' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc;

select TASK_ID,TASK_SEQ_NBR,CNTR_NBR from DM.TASK_DTL where TASK_ID in('74276341') and CNTR_NBR is null and STAT_CODE ='40';

select * from item_cbo where ITEM_BAR_CODE='190795483390';

select item_id,cntr_nbr,task_id,old_stat_code,new_stat_code,create_date_time,mod_date_time from prod_trkg_tran where item_id in ('2365644')
and task_id = '70437758';

------------------------------------------------------iLPN Doesn't exist end here--------------------------------------------------------------------
with a as (select unique td.task_genrtn_ref_nbr, th.task_id, th.stat_code, th.mhe_flag,
                    decode(swp.wave_desc, 'eCOM Unit Sorter Wave', '7019','Wholesale Unit Sorter Wave','7019','Put Wall from EPM','7019','Chase Wave','7022','7017') EVENT_ID
     from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
     and th.invn_need_type in(3,51) and th.stat_code = 10 and th.mhe_flag = 'N' and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)
and
not exists (select 1 from event_message_history em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90);

with a as (select s.tc_shipment_id, s.assigned_carrier_code, ss.description SHIPMENT_STATUS, min(ship_via) LPN_SHIP_VIA , 
        sum(case when ship_via is not null then 1 else 0 end) CARTONS_SHIP_VIA, sum(case when ship_via is null then 1 else 0 end) NULL_SHIP_VIA
from lpn l, shipment s, shipment_status ss where l.tc_shipment_id = s.tc_shipment_id 
            and s.shipment_status = ss.shipment_status and s.shipment_status = 60 and l.lpn_facility_status < 90 and assigned_mot_id = 3
group by s.tc_shipment_id, assigned_carrier_code, ss.description, assigned_mot_id)
select * from a where NULL_SHIP_VIA > 0;



select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null




Select SHIP_VIA,TC_SHIPMENT_ID,INBOUND_OUTBOUND_INDICATOR from LPN where tc_shipment_id = 'CS24297086';

select * from sys_code where code_type in ('CCF');

select item_id,cntr_nbr,task_id,old_stat_code,new_stat_code,create_date_time,mod_date_time from prod_trkg_tran where item_id in ('2487940')
and task_id = '83946515';
--970100002360 

------------------------------------------
select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;



select * from sys_code where code_type in ('CCF');
