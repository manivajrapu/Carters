alter session SET Current_schema=DM;

------------------------------------Orphaned High Volume STS Cartons - CCF to canceled status "99"-------------------------------------------------------
select tc_lpn_id, inbound_outbound_indicator, lpn_facility_status from dm.lpn l, dm.orders o where l.order_id = o.order_id and o.ref_field_3 = 'EC' and l.lpn_facility_status = 20 and l.d_facility_alias_id is null and l.inbound_outbound_indicator = 'O'
and l.last_updated_dttm < sysdate - 1/24
and not exists (select 1 from dm.lpn l2 where l2.tc_reference_lpn_id = l.tc_lpn_id and l2.lpn_facility_status < 90 and l2.inbound_outbound_indicator = 'O')
and not exists (select 1 from dm.lpn_detail ld where ld.lpn_id = l.lpn_id);
 
--STS Master Carton tied to Shipped or Cancelled Child Order, or Master Carton Cancelled or Shipped with consolidated Child Cartons
select l.tc_lpn_id "Master Carton", l.lpn_facility_status "Master Status", l2.tc_lpn_id "Child Carton", l2.last_updated_dttm, l2.lpn_facility_status "Child Status" from dm.lpn l, dm.lpn l2, dm.orders o where l.tc_lpn_id = l2.tc_reference_lpn_id and l2.order_id = o.order_id
and o.ref_Field_3 = 'EC'  and l.non_inventory_lpn_flag = '1' 
 and l.inbound_outbound_indicator = 'O' and l2.inbound_outbound_indicator = 'O' and l.order_id = l2.order_id
and ( l.lpn_facility_status <= 20)  and (l2.lpn_facility_status = 90) order by 4 desc;
--BCAR30420393_1
 
