alter session set current_schema = DM;

select unique o.order_type, o.tc_order_id, o.order_id, o.do_status, l.tc_lpn_id, l.chute_id
from picking_short_item psi, orders o, lpn l, order_line_item oli
where psi.line_item_id = oli.line_item_id and o.order_id = oli.order_id and psi.tc_lpn_id = l.tc_lpn_id
and o.order_type in ('PR','EC') and l.lpn_Facility_status = 15 and psi.stat_code = 90 and do_dtl_status >=120
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.item_id = psi.item_id and td.stat_code < 90)
and not exists (select 1 from picking_short_item psi2 where psi2.line_item_id = psi.line_item_id and psi2.stat_code = 0)
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.tc_order_id = o.tc_order_id and td.stat_code < 90)
and not exists (select 1 from alloc_invn_dtl aid where aid.carton_nbr = psi.tc_lpn_id and aid.tc_order_id = o.tc_order_id and aid.stat_code < 90)
and not exists (select 1 from order_line_item oli2 where oli2.order_id = oli.order_id and oli2.do_dtl_status < 150);

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,order_id,last_updated_source from lpn where tc_lpn_id in ('00000197181556377558') ; --should be in 15 status

