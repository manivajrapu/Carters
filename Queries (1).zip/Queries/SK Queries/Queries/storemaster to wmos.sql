alter SESSION set current_schema=wmprod44;

select error_seq_nbr,proc_stat_code,INPT_STORE_MASTER_ID from inpt_store_master;

select distinct error_seq_nbr,proc_stat_code from inpt_store_master;

select * from inpt_store_master where error_seq_nbr in ('191014924','191038587');

select * from msg_log where ref_value_1 in ('185314707');--,'185313647','185313648','185313649');

--update inpt_store_master set proc_stat_code= 0 ,error_seq_nbr=0;

--commit;

--rollback;
select distinct error_seq_nbr,proc_stat_code from inpt_store_master;

select * from inpt_store_master where error_seq_nbr in ('191014924','191038587') and proc_stat_code = 10; 

--181850203   --181850204   --181850205 --181850206
------------------------------------------------------------------------ASN_to_WMOS--------------------------------------------------------------
select SHPMT_NBR,error_seq_nbr,proc_stat_code from inpt_asn_hdr;

select * from msg_log where ref_value_1 in ('11360308','11360309');

select * from asn_hdr where SHPMT_NBR='224287001';
--506:cas_shpd	12144:units_shpd	506:cases	12144:units_rcvd
select * from inpt_CASE_HDR where ORIG_SHPMT_NBR='233722004';--506
select * from CASE_DTL where CASE_NBR in (select CASE_NBR from CASE_HDR where ORIG_SHPMT_NBR='224287001');
select * from inpt_asn_hdr where SHPMT_NBR in('233722004');
select * from WMPROD33.CASE_HDR where CASE_NBR in('00007160417183938554');

select * from inpt_case_hdr where shp;
--inpt_case_dtl,inpt_case_hdr,inpt_asn_hdr

select * from EISPROD33.CL_ENDPOINT;--227415807
select * from EISPROD33.CL_ENDPOINT_QUEUE where endpoint_id = '16' and status = 6;
select * from EISPROD33.CL_ENDPOINT_QUEUE where endpoint_id = '16' and ENDPOINT_QUEUE_ID='';


