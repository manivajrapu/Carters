----------------------------------------------------------------------------------------------------------
alter session set current_schema = DM;

select tc_order_id, store_nbr, d_facility_alias_id, major_order_grp_attr, dc_ctr_nbr, created_dttm, last_updated_dttm, do_status
from orders where do_status < 190 and store_nbr != substr(d_facility_alias_id, -4) and order_type = 'SD';
--status should be in 110 or 105
-------------------------------------------------------------------------------------------------------------------------
--Go To > Distribution Orders UI 
--In the �Miscellaneous� section under the General tab we need to change the �Federated store number� to match the �DC center number� 
--and save the changes.
----------------------------------------------Purge timing---------------------------------------------------




select aid.ALLOC_INVN_DTL_ID,aid.SKU_ATTR_1,aid.cntr_nbr, im.item_bar_code, im.item_name,im.description,aid.qty_alloc, im.item_id, aid.orig_reqmt, aid.invn_need_type,
aid.dest_locn_id, aid.batch_nbr, aid.qty_pulld, aid.carton_nbr, aid.stat_code, aid.pull_locn_id,
aid.user_id, aid.create_date_time, aid.mod_date_time, tc_order_id from alloc_invn_dtl aid, item_cbo im 
where aid.item_id = im.item_id and aid.cntr_nbr in ('970086433333') and stat_code  < 90;

select * from sys_code where code_type in ('CCF');

select * from task_dtl where pull_locn_id in(
select lh.locn_id from locn_hdr lh, pick_locn_hdr plh
where lh.locn_id = plh.locn_id and dsp_locn = 'POSR32597') and stat_code < 90;



----------------------
select task_id,cntr_nbr,INVN_NEED_TYPE,stat_code,item_id,pull_locn_id from task_dtl 
where cntr_nbr in ('970086968703') and stat_code<90;
select * from locn_hdr where locn_id in ('100367673');
select * from item_cbo where item_id in ('2504957');
select * from task_dtl where cntr_nbr in ('970086968703') and stat_code<90; 
select * from alloc_invn_dtl 
where cntr_nbr in ('970086968703') and stat_code<90; 