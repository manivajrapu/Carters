alter session SET Current_schema=DM;

select ext_purchase_order "PURCHASE_ORDER", bill_to_name "CUSTOMER", 
        addr_code "DIV", rte_to "ROUTE_TO", lane_name "LANE", tc_shipment_id "ORDERS_SHIPMENT_ID", count(*) "TOTAL_ORDERS"
from orders o where order_type not in ('EC','SD') and order_status = 10 and do_status < 190
and exists (select 1 from lpn l where l.order_id = o.order_id and l.lpn_Facility_status < 90 and tc_shipment_Id is null and inbound_outbound_Indicator = 'O')
group by  ext_purchase_order, bill_to_name, addr_code, rte_to, lane_name, tc_shipment_id; --Alert

Select o.ext_purchase_order, o.order_id, o.tc_order_id, o.order_status, o.do_status, l.tc_lpn_id, l.order_split_id, os.order_split_id, ship_via, to_char(l.shipment_id) shipment_Id, l.tc_shipment_Id, s.assigned_ship_via S_SHIP_VIA, s.shipment_id S_SHIP_ID, s.tc_shipment_id s_TC_SHIP_ID,
  'update lpn set order_split_id = '||chr(39)||os.order_split_id||chr(39)||', ship_via = '||chr(39)||s.assigned_ship_via||chr(39)||', shipment_id =  '||chr(39)||s.shipment_id||chr(39)||', tc_shipment_Id = '||chr(39)||s.tc_shipment_id||chr(39)||' where tc_lpn_id = '||chr(39)||l.tc_lpn_id||chr(39)||';' CCF
from orders o, lpn l, order_split os, shipment s where o.order_id = l.order_id and o.order_id = os.order_id (+) and os.shipment_Id = s.shipment_Id (+)
and o.ext_purchase_order in ('BS6G3CB','BS4E3TV')and l.lpn_facility_status < 40 and s.shipment_status = 60 and os.is_cancelled = 0
order by ext_purchase_order, tc_order_id; --put purchase order

select DISTINCT(TC_ORDER_ID) from orders where EXT_PURCHASE_ORDER='BS6G3CB';    --if no o/p from query run this and get tc_order_id

select lpn_facility_status,TC_LPN_ID from lpn where TC_ORDER_ID in (select DISTINCT(TC_ORDER_ID) from orders where EXT_PURCHASE_ORDER='BQ9W3BH');   --check status if any less than 40 reply carton under manifest

--L525785BABY manifest remn.
select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source,order_id,
INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('00000197181564268114','00000197181564293062','00000197181564242763','00000197181564293116');    --if no result from above query

SELECT LPN_FACILITY_STATUS,TC_SHIPMENT_ID,SHIP_VIA,TC_ORDER_ID,TC_LPN_ID from lpn where TC_SHIPMENT_ID='CS24414952';
