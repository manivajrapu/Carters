alter session SET Current_schema=DM;

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,TC_SHIPMENT_ID, TOTAL_LPN_QTY,tc_order_id,manifest_nbr,order_id,SHIP_VIA,TC_REFERENCE_LPN_ID,
INBOUND_OUTBOUND_INDICATOR,last_updated_source,LAST_UPDATED_DTTM,SHIP_BY_DATE
from lpn where tc_lpn_id in ('');  --1st Execute status 15.

select TC_LPN_ID,LPN_FACILITY_STATUS,TC_ORDER_ID from lpn where TC_ORDER_ID in ('');

select DO_STATUS,ORDER_TYPE,TC_ORDER_ID,ORDER_ID,LAST_UPDATED_SOURCE from orders where TC_ORDER_ID in ('');

select ORDER_ID,LINE_ITEM_ID, DO_DTL_STATUS from order_line_item where ORDER_ID in('') and DO_DTL_STATUS <'190'; --and item_id in('');

--De-allocate iLPN
select aid.STAT_CODE, aid.CNTR_NBR, aid.CARTON_NBR, aid.INVN_NEED_TYPE, aid.ALLOC_INVN_DTL_ID, lpn.tc_lpn_id, lpn.lpn_facility_status
from DM.ALLOC_INVN_DTL aid, DM.LPN 
where aid.CNTR_NBR in ('') and aid.CARTON_NBR = lpn.tc_lpn_id and aid.stat_code < '90'and lpn.lpn_facility_status < '20'; 

select STAT_CODE,TASK_ID from DM.TASK_HDR where TASK_ID in ('');

select TASK_ID,STAT_CODE,INVN_NEED_TYPE,ALLOC_INVN_DTL_ID,TASK_SEQ_NBR 
from DM.TASK_DTL where TASK_ID in ('') and  stat_code < '90';--970062490104     --2nd No open task

select CARTON_NBR,CNTR_NBR,ALLOC_INVN_DTL_ID, STAT_CODE from DM.ALLOC_INVN_DTL where CARTON_NBR in ('') and stat_code < '90';    -- 3rd No open Allocations  99011639  99036853

select aid.CARTON_NBR,aid.CNTR_NBR,aid.INVN_NEED_TYPE,ic.ITEM_NAME from DM.ALLOC_INVN_DTL aid, item_cbo ic where aid.CNTR_NBR in ('') and aid.stat_code < 90 and aid.item_id=ic.item_id;

select * from picking_short_item where tc_lpn_id in ('') and stat_code < '90';     --4th No picking short items.

Select * from DM.WM_INVENTORY where TC_LPN_ID='';

select eq.msg_id, eq.status ST, error_count EC, m.event_id E_ID, eq.endpoint_id EP_ID, m.source_id, regexp_substr(to_char(m.data), '[^/^]+', 1, 10) "QTY", eq.when_queued, eq.when_status_changed, m.data
from cl_endpoint_queue eq, cl_message m  where m.msg_id = eq.msg_id 
and eq.when_queued > sysdate -1
and m.source_id = 'SORTRAK_CARTONCLOSE'
and m.data like '%%'
order by eq.when_status_changed desc;
