alter session SET Current_schema=DM;

select aid.cntr_nbr, im.item_name, im.item_bar_code, aid.batch_nbr, aid.carton_nbr, aid.qty_alloc, aid.mod_date_time
  from alloc_invn_dtl aid, lpn l, orders o, item_cbo im where l.tc_lpn_id = aid.cntr_nbr and aid.tc_order_id = o.tc_order_id and aid.item_id = im.item_id 
  and aid.invn_need_type = 52 and aid.stat_code = 0 
  and l.lpn_facility_status <> 64 and o.order_type = 'EC';

select TC_LPN_ID,TC_SHIPMENT_ID,LPN_FACILITY_STATUS,LPN_ID,LPN_STATUS,LAST_UPDATED_SOURCE from lpn where tc_lpn_id='970089588352' and inbound_outbound_indicator='I'; --95 If it is in 95 status recreate the ilpn in RF

select LPN_ID,TC_LPN_ID,LPN_STATUS,LPN_FACILITY_STATUS,SHIP_VIA from lpn where tc_lpn_id in ('00000197181704202756') and inbound_outbound_indicator='O'; --15  --00000197181573146458,00000197181573776945

select lpn_detail_status,batch_nbr, initial_qty, item_name from lpn_detail where lpn_id='80807474';

select * from DM.ALLOC_INVN_DTL where CNTR_NBR in ('970089588352') and STAT_CODE < '90';

select aid.cntr_nbr,aid.carton_nbr, im.item_bar_code, im.item_name, im.item_id, aid.orig_reqmt, aid.invn_need_type,
aid.dest_locn_id, aid.batch_nbr, aid.qty_alloc, aid.qty_pulld, aid.carton_nbr, aid.stat_code, aid.pull_locn_id, 
aid.user_id, aid.create_date_time, aid.mod_date_time, tc_order_id from alloc_invn_dtl aid, item_cbo im  
where aid.item_id = im.item_id and aid.cntr_nbr in ('00007160417185538400') and stat_code  < 90; 

select * from locn_hdr where locn_id='0051094';--RPT1036A03? PRT0304B02
select * from alloc_invn_dtl where carton_nbr in ('00000197181702460349','00000197181702460325','00000197181702459138','00000197181702460011','00000197181702459589') and stat_code<90;
select * from picking_short_item where tc_lpn_id in ('00007160417185538400');
select * from task_dtl where cntr_nbr in ('00007160417185538400') and stat_code<90;

select * from picking_short_item where tc_lpn_id in ('00000197181702460349','00000197181702460325','00000197181702459138','00000197181702460011','00000197181702459589') and stat_code<90;

select * from lpn where tc_lpn_id in ('970000485198');
--970000485198
--970099999999


select * from task_dtl where cntr_nbr in ('EXC_282818_000485198');