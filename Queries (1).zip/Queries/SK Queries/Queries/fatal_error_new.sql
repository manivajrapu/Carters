alter session SET Current_schema=DM;

select td.task_id "Task ID",td.task_seq_nbr "Task Sequence", td.task_genrtn_ref_nbr "Wave Number", 
               td.invn_need_type "Need Type", lh.dsp_locn "Need Location", im.item_name "Need Item", td.qty_alloc "Qty Alloc", lh.locn_brcd, im.item_bar_code, td.batch_nbr
  from task_dtl td, wm_inventory wi, item_cbo im, locn_hdr lh
  where td.pull_locn_id = wi.location_id(+)
  and td.item_id = wi.item_id(+)
  and td.pull_locn_id = lh.locn_id(+)
  and td.item_id = im.item_id(+)
  and (wi.location_id is null or wi.item_id is null)
  and td.stat_code =0 and td.invn_need_type in (3,51)
  and td.create_date_time > sysdate - 10;

select ITEM_BAR_CODE from item_cbo where item_name in ('121H648 B 12M');--190795804904   347G372 PRT 2T

select * from task_dtl where cntr_nbr in ('970100016798') and stat_code<'90';--89825629