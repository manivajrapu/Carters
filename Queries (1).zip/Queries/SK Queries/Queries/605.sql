alter session set current_schema = DM;

------------------------------------605-----------------------------------------------------------------------------------------------------
select im.item_name, im.item_bar_code, nvl(start_invn,0) "605_YEST", nvl(pix_invn,0) 
PIX_INVN, nvl(crtn_invn,0) CRTN_INVN, nvl(end_invn,0) "605_TODAY",
nvl(start_invn,0)+nvl(pix_invn,0)-nvl(crtn_invn,0)-nvl(end_invn,0) VAR, RUN_DATE,ADJ_CHECK_VAR
from MA_tmp_gen605_compare m, item_cbo im where m.item_id = im.item_id and trunc(run_date) = trunc(sysdate);
------------------------------------PIX TRAN-----------------------------------------------------------------------------------------------
select pt.tran_type,pt.item_id, pt.tran_code,pt.ACTN_CODE,pt.rsn_code,pt.REF_FIELD_1, im.item_name,
pt.batch_nbr, pt.case_nbr, pt.invn_adjmt_qty, pt.invn_adjmt_type, pt.create_date_time 
from pix_tran pt, item_cbo im where im.item_id = pt.item_id and im.item_name = '121H657 TQ 12M'
and pt.create_date_time > sysdate - 2 and pt.tran_type not in (620) 
order by pt.create_date_time desc;
------------------------------------Activity Tracking-----------------------------------------------------------------------------------------------
Select tran_type,tran_code,tran_nbr,CNTR_NBR,NBR_UNITS,REF_FIELD_1,OLD_STAT_CODE,NEW_STAT_CODE,MODULE_NAME,MENU_OPTN_NAME,CREATE_DATE_TIME,MOD_DATE_TIME from DM.PROD_TRKG_TRAN 
where item_id = '2204985' and CNTR_NBR = '00000156740031585227' order by create_date_time desc ;

--00000440227201701109
--1 inventory is decreased without pix generation.

select * from task_dtl where task_id='60568318'and stat_code < 90;
select*from task_hdr where task_id='60568318'and stat_code < 90;

with a as (select unique td.task_genrtn_ref_nbr, th.task_id, th.stat_code, th.mhe_flag,
                    decode(swp.wave_desc, 'eCOM Unit Sorter Wave', '7019','Wholesale Unit Sorter Wave','7019','Put Wall from EPM','7019','Chase Wave','7022','7017') EVENT_ID
     from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
     and th.invn_need_type in(3,51) and th.stat_code = 10 and th.mhe_flag = 'N' and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)
and
not exists (select 1 from event_message_history em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)


select manifest_nbr from lpn where tc_lpn_id = '00000197181533739553';
