alter session SET Current_schema=DM;


select l.tc_Lpn_id, l.last_updated_dttm, l.lpn_facility_status, im.item_name, ld.size_value
from lpn l, lpn_detail ld, wm_inventory wm, item_cbo im 
  where im.item_id = wm.item_id and ld.lpn_detail_id = wm.lpn_detail_id and l.lpn_id = ld.lpn_id
     and l.lpn_facility_status = 99 and l.inbound_outbound_indicator = 'I' and ld.size_value > 0 and l.last_updated_dttm > sysdate - 30
     and not exists (select 1 from asn a where a.tc_asn_id = l.tc_asn_id and a.asn_status = '60' );
     
     
select on_hand_qty, wm_allocated_qty,INBOUND_OUTBOUND_INDICATOR,LOCATION_ID from wm_inventory where tc_lpn_id in ('00000197181562927327');

select * from task_dtl where cntr_nbr in ('00000197181562927327')  and stat_code < 90;

select * from alloc_invn_dtl where cntr_nbr in ('00000197181562927327') and stat_code < 90;
----------------------------------------------------------CHECKS COMPLETED.------------------------------------------------------------------------
select TC_LPN_ID,LPN_FACILITY_STATUS,LPN_STATUS,lpn_id,TOTAL_LPN_QTY, CURR_SUB_LOCN_ID from lpn where TC_LPN_ID in ('00000197181562927327');

select on_hand_qty, wm_allocated_qty, LOCATION_ID from wm_inventory where tc_lpn_id in ('00000197181562927327');

select lpn_id,LPN_DETAIL_STATUS,LPN_DETAIL_ID,SIZE_VALUE from DM.LPN_DETAIL where lpn_id in ('72143999');

select TC_LPN_ID,INVENTORY_LOCK_CODE from DM.LPN_LOCK where TC_LPN_ID in ('00000197181562927327');

select locn_id,locn_class,work_area from LOCN_HDR where locn_id in ('0000207');

select lpn_id,LPN_DETAIL_STATUS,LPN_DETAIL_ID,SIZE_VALUE from DM.LPN_DETAIL where lpn_id in ('72143999');
----------------------------------------------------------Nabee's Queries---------------------------------------------------------------------------
select lpn_id, CURR_SUB_LOCN_ID,TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS,TOTAL_LPN_QTY from lpn where TC_LPN_ID in ('00000197181562927327');

Select lpn_id, LPN_DETAIL_STATUS,LPN_DETAIL_ID,SIZE_VALUE from lpn_detail where lpn_id in ('72143999');

select locn_id,locn_class,work_area from LOCN_HDR where locn_id='0000207';

select TC_LPN_ID,INVENTORY_LOCK_CODE,LPN_ID from DM.LPN_LOCK where TC_LPN_ID in ('00000197181562927327'); --delete locks

Select lpn_id,LPN_DETAIL_ID, location_id from wm_inventory where TC_LPN_ID in ('00000197181562927327'); --update to null

select on_hand_qty, wm_allocated_qty, LOCATION_ID from wm_inventory where tc_lpn_id in ('00000197181562927327');

select * from dm.LPN_DETAIL where LPN_ID in 
('72143999');
select lpn_id,LPN_DETAIL_STATUS,LPN_DETAIL_ID,SIZE_VALUE from DM.LPN_DETAIL where lpn_id in
('72143999');
