select TC_ORDER_ID,ORDER_ID,DO_STATUS,EXT_PURCHASE_ORDER,CREATED_DTTM,LAST_UPDATED_SOURCE 
from orders where tc_order_id in ('1225195138');

select TC_LPN_ID,LPN_FACILITY_STATUS,TC_ORDER_ID from lpn where TC_ORDER_ID in ('1225195138');  --201804120001

select USER_ID,STAT_CODE from DM.SHIP_WAVE_PARM where SHIP_WAVE_NBR in('201804120002');  

select * from orders where tc_order_id in ('1225195138');

select o.order_id,o.tc_order_id, o.do_status, oli.do_dtl_status, o.created_dttm, oli.item_id, oli.item_name ,oli.sku_gtin, oli.order_qty, oli.unit_wt, oli.unit_vol, o.lane_name, oli.pick_locn_assign_type,
(select sum(wm.on_hand_qty-wm_allocated_qty+to_be_filled_qty) from wm_inventory wm where wm.item_id = oli.item_id and wm.batch_nbr = oli.batch_nbr and 
       wm.allocatable = 'Y' and wm.locn_class in ('A')) "AvailInv", oli.item_id, oli.order_id, oli.batch_nbr
from orders o, order_line_item oli, ITEM_CBO icb
where o.order_id = oli.order_id 
--and o.do_status = '110'
--and oli.do_dtl_status = '110'
--and order_type = 'EC'
and o.tc_order_id = any ('1225195138')
order by 1;

--Locations for waving (Retail & Wholesale) Remote packing
select * 
from locn_hdr 
where locn_class = 'C' 
and pick_detrm_zone = 'OSR' 
and not exists (select 1 from pick_locn_dtl pld where pld.locn_id = locn_hdr.locn_id);

--Locations for waving (ECOM) Remote Packing
select * 
from locn_hdr 
where locn_class = 'C' 
and sku_dedctn_type = 'T' 
and not exists (select 1 from pick_locn_dtl pld where pld.locn_id = locn_hdr.locn_id);
