alter session SET Current_schema=DM;

------------------------------------------MHE Release----------------------------------------------------------------------------------
with a as (select unique td.task_genrtn_ref_nbr, th.task_id, th.stat_code, th.mhe_flag,
                    decode(swp.wave_desc, 'eCOM Unit Sorter Wave', '7019','Wholesale Unit Sorter Wave','7019','Put Wall from EPM','7019','Chase Wave','7022','7017') EVENT_ID
     from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
     and th.invn_need_type in(3,51) and th.stat_code = 10 and th.mhe_flag = 'N' and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)
and
not exists (select 1 from event_message_history em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90);

-------------------------------------------------------iLPN doesn't exist----------------------------------------------------------------------

Select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;



Select l.tc_lpn_id
from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code = '190795052091' and ld.batch_nbr = 'EC002'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';
----------------------------------------------------------------------------------------------------------------------------------------------
select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;


select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl where task_id ='67477028' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc; 


select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status <= 180 and lpn_facility_status < 40 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status > 60);

--select * from &1.pn;

--desc dm.lpn;
--------------------------------------------------------------------------------------------------------------------------------------------------
SELECT distinct(lpn.TC_LPN_ID),lpn.lpn_facility_status,lpn.tc_Order_ID,Orders.do_status,lpn.INBOUND_OUTBOUND_INDICATOR,
lpn.manifest_nbr,lpn.order_id,lpn.lpn_id,
(select count(*) from ALLOC_INVN_DTL 
where carton_nbr in ('00000156741221088603') and stat_code<90) as allocations,(select count(*) from TASK_DTL 
where carton_nbr in ('00000156741221088603') and stat_code<90) as tasks
FROM ((Orders
INNER JOIN lpn ON Orders.TC_ORDER_ID = lpn.TC_ORDER_ID) inner join ALLOC_INVN_DTL on 
lpn.TC_LPN_ID = ALLOC_INVN_DTL.CARTON_NBR) where lpn.TC_LPN_ID in ('
'); 


select * from shipment where tc_shipment_id='CS23887371';

select * from orders where tc_order_id='1221212161';

select * from postal_code where postal_code in('740-0025');

select TASK_ID, START_CURR_WORK_AREA,START_CURR_WORK_GRP from task_hdr where task_id in ('78640918');

select task_id, cntr_nbr, pull_locn_id from dm.task_dtl where task_id = '78640918' and stat_code < 90 order by task_seq_nbr asc;

select work_grp, work_area from locn_hdr where locn_id = '100129705';