alter session SET Current_schema=DM;

----------------------------------------------------Alert and Update statements----------------------
select tc_lpn_id, inbound_outbound_indicator, lpn_facility_status,
'update lpn set lpn_facility_status = ''99'' where tc_lpn_id = '||chr(39)||tc_lpn_id||chr(39)||' and inbound_outbound_indicator = '''||inbound_outbound_indicator||''';' "SQL Statement"
from dm.lpn l, dm.orders o where l.order_id = o.order_id and o.ref_field_3 = 'EC' and l.lpn_facility_status = 20 and l.d_facility_alias_id is null and l.inbound_outbound_indicator = 'O'
and l.last_updated_dttm < sysdate - 1/24
and not exists (select 1 from dm.lpn l2 where l2.tc_reference_lpn_id = l.tc_lpn_id and l2.lpn_facility_status < 90 and l2.inbound_outbound_indicator = 'O')
and not exists (select 1 from dm.lpn_detail ld where ld.lpn_id = l.lpn_id);

--------------------------------------------------------------------Validate------------------------

select l.tc_lpn_id MASTER_CARTON, l.lpn_facility_status MASTER_STATUS, l2.tc_lpn_id eCOM_CARTON, l2.lpn_facility_status eCOM_STATUS,
    (select ds.description from dm.orders o, dm.do_status ds where o.do_status = ds.order_status and o.order_id = l2.order_id) ORDER_STATUS
from dm.lpn l, dm.lpn l2 where l.tc_lpn_id = l2.tc_reference_lpn_id and l.tc_lpn_id in 
('00000197181338930742', '00000197181338930698', '00000197181338890541', '00000197181338733350', '00000197181338465107', '00000197181338465534', 
'00000197181338469310', '00000197181338735552', '00000197181338920705', '00000197181338920675', '00000197181338891739', '00000197181338732964', 
'00000197181338920378', '00000197181338920668', '00000197181338735545', '00000197181338929968', '00000197181338466142', '00000197181338732995', 
'00000197181338932654', '00000197181338918719', '00000197181338936904', '00000197181338930209', '00000197181338932616', '00000197181338711211', 
'00000197181338733589', '00000197181338887534', '00000197181338466074') 
order by 1;


select * from lpn where tc_lpn_id='99003839x';