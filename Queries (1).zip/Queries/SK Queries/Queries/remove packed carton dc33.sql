alter SESSION set current_schema=wmprod33;

select stat_code from outbd_load where load_nbr in ('330451063'); -- =>40 status
select * from carton_hdr where load_nbr = '3300112406';
select * from carton_dtl where carton_nbr in (select carton_nbr from carton_hdr where load_nbr = '3300112406');
select * from pkt_hdr_intrnl where pkt_ctrl_nbr in (select pkt_ctrl_nbr from carton_hdr where load_nbr = '3300112406');
select * from pkt_dtl where pkt_ctrl_nbr in (select pkt_ctrl_nbr from carton_hdr where load_nbr = '3300112406');
select * from outpt_carton_hdr where load_nbr = '3300112406';
select * from outpt_carton_dtl where invc_batch_nbr = '330450434';
select * from outpt_pkt_hdr where invc_batch_nbr = '330451063';
select * from outpt_pkt_dtl where invc_batch_nbr = '330450434';
select * from store_distro where distro_nbr in ('330171925271','330171925275','330172657354','330172657355');

select * from outpt_carton_hdr where ship_via = 'CARD';

select * from outpt_outbd_load where invc_batch_nbr = '330451063';  --330451063
select * from outpt_outbd_stop where invc_batch_nbr = '330451063';

select phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,
ph.plan_bol, ph.plan_master_bol,count(*)
from pkt_hdr ph,
pkt_hdr_intrnl phi
where ph.pkt_ctrl_nbr in (select distinct ch.pkt_ctrl_nbr
from carton_hdr ch
where load_nbr in ('3300103896')
and ((stat_code < '90') or
(stat_code = '99')))
and ph.plan_load_nbr in ('3300103896')
and phi.pkt_ctrl_nbr = ph.pkt_ctrl_nbr
group by phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,ph.plan_bol, ph.plan_master_bol;


Select load_nbr,stat_code,carton_nbr,shpmt_nbr,bol,master_bol,user_id,mod_date_time,pkt_ctrl_nbr from  carton_hdr ch
where load_nbr in ('3300103803') and stat_code < '90';--here take the cartons and take the pkt_ctrl_nbr to put in CCF <20

select * from carton_hdr where carton_nbr in('00000197183472722139');
select * from carton_hdr where pkt_ctrl_nbr='3400000131';

select load_nbr from carton_hdr where carton_nbr in('00000197183472722139');
-----------------------------------------------New -------------------------------------------------------
select stat_code, load_nbr from outbd_load where load_nbr in ('3300112745','3300112746','3300112747');

select stat_code, load_nbr from carton_hdr where load_nbr in ('3300112673');
select carton_nbr, pkt_ctrl_nbr, load_nbr, stat_code from carton_hdr where load_nbr in ('3300112745','3300112746','3300112747') and stat_code < 90;

select load_nbr, shpmt_nbr, bol, master_bol, carton_nbr,STAT_CODE from carton_hdr 
where carton_nbr in ('00000197183488966619');

select load_nbr, shpmt_nbr, bol, master_bol, carton_nbr,STAT_CODE,CARTON_NBR from carton_hdr where PKT_CTRL_NBR='3402373127';

select pkt_ctrl_nbr,PLAN_BOL,PLAN_LOAD_NBR,PLAN_MASTER_BOL,PLAN_SHPMT_NBR from pkt_hdr where pkt_ctrl_nbr in('3400000106','3400000063','3400000131');

select plan_load_nbr, plan_bol, plan_master_bol, plan_shpmt_nbr from pkt_hdr where PKT_CTRL_NBR in 
(select distinct PKT_CTRL_NBR from carton_hdr where load_nbr in ('3300112406') AND carton_nbr in ('00000197183482862634'));

select plan_load_nbr, plan_bol, plan_master_bol, plan_shpmt_nbr from pkt_hdr where pkt_ctrl_nbr = '3408404652';

select *from carton_hdr where pkt_ctrl_nbr = '3400000063' and load_nbr = '3300112747';

select *
from carton_hdr ch
where load_nbr in ('')
and
pkt_ctrl_nbr in (select pkt_ctrl_nbr from pkt_hdr where cust_po_nbr in (''));
