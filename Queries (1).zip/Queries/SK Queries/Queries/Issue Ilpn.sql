alter session SET Current_schema=DM;

Select TC_LPN_ID,LPN_FACILITY_STATUS,INBOUND_OUTBOUND_INDICATOR,LPN_STATUS,LAST_UPDATED_SOURCE from lpn where tc_lpn_id in ('99044589');  --45 or 50 status.