--DC33/Pulled Quantty
alter SESSION set current_schema =wmprod33;


select stat_code,case_nbr
from  CASE_HDR
  where case_nbr in 
  ('00006644540330805000');  -- should be 45 50 64 status for de-allocation.
  
select * from alloc_invn_dtl where CNTR_NBR in ('00006644540330805000') and stat_code < 90; --,''
--00006644543314708250
select * from task_dtl where cntr_nbr in('00006644540330805000') and stat_code < 90;

select actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in('00006644540330805000');

select stat_code,case_nbr
from  CASE_HDR
  where case_nbr in ('');

select count(*)
from alloc_invn_dtl 
where invn_need_type='60'
and stat_code='0' 
  and cntr_nbr in ('00006644543317225952');
  select * from carton_hdr where LOAD_NBR in ('3300109932');
  select * from WMPROD33.OUTBD_LOAD WHERE LOAD_NBR in('3300109932');

-------------------------------------------------------------------------------------------------------------------------------------------------
select *
from task_hdr
where task_id in (select td.task_id
from task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
and aid.stat_code = '00'
and aid.cntr_nbr in ('00007160411203812060','00007160420713136825') --no open task.
and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id)
and stat_code <'99';
-------------------------------------------------------------------------------------------------------------------------------------------------

SELECT * FROM OUTBD_LOAD where LOAD_NBR in('3300109065');
SELECT * FROM outpt_carton_hdr where LOAD_NBR in('3300109065');
SELECT * FROM OUTPT_CARTON_DTL where PKT_CTRL_NBR in('3300109065');
SELECT * FROM outpt_carton_hdr where LOAD_NBR in('3300109065');
------------------------------------------------------------------------------------------------
select DISTINCT(PO_NBR),STORE_DEPT,DISTRO_NBR from WMPROD33.STORE_DISTRO where PO_NBR in 
('10379455', '10379459', '10379463', '10379467', '10379469', '10379473', '10379482', '10379483', '10379485', '10379486', '10379487', '10379488', '10379489',
'10379490', '10379492', '10379493', '10379495', '10379496', '10379497', '10379514', '10379518', '10379523', '10379526', '10379538');

desc WMPROD33.STORE_DISTRO

------------------------

select * from CARTON_HDR  where manif_nbr in ('FXGD330062288','FXGD330062286','FXGD330062290','FXGD330062289','FXGD330062287','FXGD330062292','FXGD330062291','FXGD330062293','FXGD330062295');


select distinct CH.MANIF_NBR from carton_lock CL, CARTON_HDR CH where 
CH.manif_nbr in ('FXGD330062288','FXGD330062286','FXGD330062290','FXGD330062289','FXGD330062287','FXGD330062292','FXGD330062291') AND CL.CARTON_NBR IS NOT NULL AND CH.CARTON_NBR=CL.CARTON_NBR;
