alter SESSION set current_schema =wmprod33;

select * from SHIP_WAVE_PARM where PICK_WAVE_NBR='201801120026';

select distinct PKT_CTRL_NBR from PKT_DTL where WAVE_NBR='201801120026' and STAT_CODE<90;
  
select carton_nbr,stat_code from CARTON_HDR where PKT_CTRL_NBR in () and stat_code<90;  