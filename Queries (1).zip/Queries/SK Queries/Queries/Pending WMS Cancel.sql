alter session SET Current_schema=DM;

select o.tc_order_id, ds.description STATUS, 
        (select min(tc_lpn_id) from dm.lpn where lpn.order_id = o.order_id and not exists (select 1 from dm.lpn_lock where tc_lpn_id = dm.lpn.tc_lpn_id and lpn_lock.inventory_lock_code = 'OP' )
                and lpn_facility_status < 40) APPLY_OP_LOCK
from dm.orders o, dm.do_status ds where o.do_status = ds.order_status and tc_order_id in 
() order by do_status;    ---Not to be used

-------------------------------------------------New Query--------------------------------------
select o.tc_order_id, ds.description STATUS
from dm.orders o, dm.do_status ds where o.do_status = ds.order_status  and ds.order_status='200' and tc_order_id in 
('BCAR37413784_1', 'BCAR37417234_1', 'BCAR37417597_1', 'BCAR37418193_1', 'BCAR37425409_1', 'BCAR37437170_1', 'BCAR37438056_1', 'BCAR37441125_1', 'BCAR37441440_1', 'BCAR37442016_1', 'BCAR37446618_1', 'BCAR37450952_1', 'BCAR37451494_1', 'BCAR37461234_1', 'CAR37371818_1', 'CAR37435288_1', 'CAR37437502_1', 'CAR37438646_1', 'CAR37439601_1', 'CAR37440996_1', 'CAR37441985_1', 'CAR37444251_1', 'CAR37444447_1', 'CAR37444834_1', 'CAR37445352_1', 'CAR37445975_1', 'CAR37446541_1', 'CAR37447349_1', 'CAR37447356_1', 'CAR37447442_1', 'CAR37450581_1', 'CAR37452505_1', 'CAR37454951_1', 'CAR37458166_1', 'CAR37458182_1', 'CAR37458915_1', 'RCAR10660363_1', 'RCAR10661481_1', 'RCAR10661934_1', 'RCAR10663369_1')
order by 1;

select�tc_lpn_id,�tracking_nbr,�manifest_nbr��from�lpn�where�tracking_nbr=�'9261297641993051926238'; 


select tc_lpn_id, tracking_nbr, manifest_nbr  from dm.lpn where tracking_Nbr= '9261297641993052086061';--USPS0007686

select tc_lpn_id, tracking_nbr, manifest_nbr  from dm.lpn where tracking_Nbr= '9261297641993052011957';