alter session SET Current_schema=DM;
--
select item_id,lpn_facility_status,lpn_id,tc_lpn_id,TOTAL_LPN_QTY,tc_order_id,manifest_nbr,order_id,SHIP_VIA,TC_REFERENCE_LPN_ID,
INBOUND_OUTBOUND_INDICATOR,last_updated_source,LAST_UPDATED_DTTM,SHIP_BY_DATE
from lpn where tc_lpn_id in ('00000197181649741044');  --1st Execute status 15.

select TC_LPN_ID,LPN_FACILITY_STATUS,TC_ORDER_ID from lpn where TC_ORDER_ID in ('');

select DO_STATUS,ORDER_TYPE,TC_ORDER_ID,ORDER_ID,LAST_UPDATED_SOURCE from orders where TC_ORDER_ID in ('CAR32873764_1');

SELECT TC_ORDER_ID,D_CONTACT,do_status,D_ADDRESS_1,D_ADDRESS_2,D_ADDRESS_3,D_CITY,D_STATE_PROV,D_POSTAL_CODE ,LAST_UPDATED_SOURCE, BILL_TO_NAME,
DELIVERY_REQ, LANE_NAME
FROM orders where TC_ORDER_ID in('');

select ORDER_ID,LINE_ITEM_ID, DO_DTL_STATUS from order_line_item where ORDER_ID in('') and DO_DTL_STATUS <'190'; --and item_id in('');

select TASK_ID,TC_ORDER_ID,LINE_ITEM_ID,STAT_CODE,ORIG_REQMT,QTY_ALLOC,QTY_PULLD from DM.TASK_DTL where 
TC_ORDER_ID in ('') and LINE_ITEM_ID in ('');

select TASK_ID,TC_ORDER_ID,LINE_ITEM_ID,STAT_CODE,ORIG_REQMT,QTY_ALLOC,QTY_PULLD from DM.TASK_DTL where 
TC_ORDER_ID='' and LINE_ITEM_ID in (select LINE_ITEM_ID from order_line_item where ORDER_ID in(''));

select TC_SHIPMENT_ID,D_ADDRESS,D_CITY,D_COUNTRY_CODE,D_POSTAL_CODE,D_COUNTY from shipment where TC_SHIPMENT_ID='';
select * from lpn where tc_shipment in ('');  --a part
select  from lpn_detail where lpn_id in ('');

--De-allocate iLPN
select aid.STAT_CODE, aid.CNTR_NBR, aid.CARTON_NBR, aid.INVN_NEED_TYPE, aid.ALLOC_INVN_DTL_ID, lpn.tc_lpn_id, lpn.lpn_facility_status
from DM.ALLOC_INVN_DTL aid, DM.LPN 
where aid.CNTR_NBR in ('') and aid.CARTON_NBR = lpn.tc_lpn_id and aid.stat_code < '90'and lpn.lpn_facility_status < '20'; 

select * from DM.TASK_DTL where CARTON_NBR in ('') and  stat_code < '90';--970062490104     --2nd No open task

select STAT_CODE,TASK_ID from DM.TASK_HDR where TASK_ID in ('79351068');

select TASK_ID,STAT_CODE,INVN_NEED_TYPE,ALLOC_INVN_DTL_ID,TASK_SEQ_NBR 
from DM.TASK_DTL where TASK_ID in ('79351068') and  stat_code < '90';--970062490104     --2nd No open task

select CARTON_NBR,CNTR_NBR,ALLOC_INVN_DTL_ID, STAT_CODE from DM.ALLOC_INVN_DTL where CARTON_NBR in ('00000197181649741044') and stat_code < '90';    -- 3rd No open Allocations  99011639  99036853

--select aid.CARTON_NBR,aid.CNTR_NBR,aid.INVN_NEED_TYPE,ic.ITEM_NAME from DM.ALLOC_INVN_DTL aid, item_cbo ic where aid.CNTR_NBR in ('00000156740050480572') and aid.stat_code < 90 and aid.item_id=ic.item_id;

select * from picking_short_item where tc_lpn_id in ('') and stat_code < '90';     --4th No picking short items.

Select * from DM.WM_INVENTORY where TC_LPN_ID='';
select * from orders where TC_ORDER_ID in ('');
select * from lpn_lock where tc_lpn_id in (''); --5th ch lock
select * from postal_code where postal_code in ('');
select BILL_ACCT_NBR from orders where tc_order_id in ('')  --
select DO_STATUS,LAST_UPDATED_SOURCE,TC_ORDER_ID,ORDER_ID,ORDER_TYPE from DM.ORDERS where tc_order_id in ('');

select * from DM.SHIPMENT where TC_SHIPMENT_ID in ('');

select description,ship_via from SHIP_VIA where ship_via in ('FXGR');
--No Data Query2364950

select unique o.order_type, o.tc_order_id, o.order_id, o.do_status, l.tc_lpn_id, l.chute_id, l.LPN_FACILITY_STATUS
from picking_short_item psi, orders o, lpn l, order_line_item oli
where psi.line_item_id = oli.line_item_id and o.order_id = oli.order_id and psi.tc_lpn_id = l.tc_lpn_id
and o.order_type in ('PR','EC') and l.lpn_Facility_status = 15 and psi.stat_code = 90 and do_dtl_status >=120
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.item_id = psi.item_id and td.stat_code < 90)
and not exists (select 1 from picking_short_item psi2 where psi2.line_item_id = psi.line_item_id and psi2.stat_code = 0)
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.tc_order_id = o.tc_order_id and td.stat_code < 90)
and not exists (select 1 from alloc_invn_dtl aid where aid.carton_nbr = psi.tc_lpn_id and aid.tc_order_id = o.tc_order_id and aid.stat_code < 90)
and not exists (select 1 from order_line_item oli2 where oli2.order_id = oli.order_id and oli2.do_dtl_status < 150); 
 



select TC_LPN_ID,LPN_FACILITY_STATUS,TC_ORDER_ID,LAST_UPDATED_DTTM,lpn_id,order_id from lpn where TC_ORDER_ID in ('CAR32322584_1');

select DO_STATUS,ORDER_TYPE,TC_ORDER_ID,ORDER_ID,LAST_UPDATED_SOURCE from orders where TC_ORDER_ID in ('CAR32322584_1');

select * from lpn_detail where lpn_id in ('88254108','88254125') and lpn_detail_status<90;
select * from task_dtl where carton_nbr in ('00000197181642102354','00000197181642102361') and stat_code<90;
select * from alloc_invn_dtl where carton_nbr in ('00000197181642102354','00000197181642102361') and stat_code<90;
select * from DM.PICKING_SHORT_ITEM where tc_lpn_id in ('00000197181642102354','00000197181642102361') and stat_code < 90;
select do_dtl_status from DM.ORDER_LINE_ITEM where order_id in ('56775769') and do_dtl_status<190;