alter session SET Current_schema=DM;

--00000156740041491549

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,order_id,SHIP_VIA,
INBOUND_OUTBOUND_INDICATOR,TOTAL_LPN_QTY,last_updated_source,LAST_UPDATED_DTTM,SHIP_BY_DATE
from lpn where TC_LPN_ID in('00000156740051228869');

select * from task_dtl where cntr_nbr = '00000156740051228869'; --and STAT_CODE <'90';
select * from alloc_invn_dtl where cntr_nbr = '00000156740051228869'; --and STAT_CODE<'90';

select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS, total_lpn_qty from lpn where TC_LPN_ID = '00000156740051228869';

select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id, initial_qty, size_value, item_name from lpn_detail where lpn_id = '89060388';

select lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty from wm_inventory where TC_LPN_ID   = '00000156740051228869';

select * from lpn_detail where lpn_id = '88261160' and lpn_detail_id = '875521583'; 
