alter session SET Current_schema=DM;



--THIS QUERY WILL SEARCH FOR MISSING ITEM BATCHES GIVEN AN ASN NUMBER
SELECT UNIQUE tc_asn_id, item_name, batch_nbr, item_cbo.item_id, asn_detail.last_updated_source, is_generic_item
FROM dm.asn, dm.asn_detail, dm.item_cbo
WHERE asn_detail.asn_id = asn.asn_id 
AND asn_detail.sku_id = item_cbo.item_id
AND tc_asn_id IN ('234287001')
AND NOT EXISTS (SELECT 1 FROM dm.batch_master WHERE batch_master.batch_nbr = asn_detail.batch_nbr AND asn_detail.sku_id = batch_master.item_id);

-------------------------Dummy Version-------------------------------------------------
select xmlelement("BatchMaster", xmlelement("TCCompanyID", 1),
                                XMLELEMENT("BatchNbr", 'EC002'),
                                XMLELEMENT("StatusCode", '10'),
                                XMLELEMENT("Item", item_name)) AS "MISSING_ITEMS" 
FROM dm.asn, dm.asn_detail, dm.item_cbo
WHERE asn_detail.asn_id = asn.asn_id 
AND asn_detail.sku_id = item_cbo.item_id
AND tc_asn_id IN ('234287001')
AND NOT EXISTS (SELECT 1 FROM dm.batch_master WHERE batch_master.batch_nbr = asn_detail.batch_nbr AND asn_detail.sku_id = batch_master.item_id);

---------------------------------------------------Ultimate Version-------------------------------------------
select to_clob('<tXML><Header><Source>PIP</Source><Action_Type>Create</Action_Type><Batch_ID>999999999</Batch_ID><Reference_ID>'||
to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')
||'</Reference_ID><User_ID>WMADMIN</User_ID><Message_Type>BatchMaster</Message_Type><Company_ID>1</Company_ID></Header><Message>') 
missing_items from dual
union all
select to_clob(xmlelement("BatchMaster", xmlelement("TCCompanyID", 1), 
                                XMLELEMENT("BatchNbr", batch_nbr), 
                                XMLELEMENT("StatusCode", '10'), 
                                XMLELEMENT("Item", item_name))) AS "MISSING_ITEMS" 
FROM dm.asn, dm.asn_detail, dm.item_cbo
WHERE asn_detail.asn_id = asn.asn_id 
AND asn_detail.sku_id = item_cbo.item_id
AND tc_asn_id IN ('234287001')
AND NOT EXISTS (SELECT 1 FROM dm.batch_master WHERE batch_master.batch_nbr = asn_detail.batch_nbr AND asn_detail.sku_id = batch_master.item_id)
union all
SELECT to_clob('</Message></tXML>') missing_items FROM dual;
