alter session SET Current_schema=DM;

Select tc_lpn_id, lpn_facility_status, inbound_outbound_indicator from lpn where tc_lpn_id in ('00000197181343285042');--30

Select aid.CARTON_NBR, aid.CNTR_NBR, aid.INVN_NEED_TYPE, ic.ITEM_NAME, aid.stat_code, aid.QTY_ALLOC, aid.QTY_PULLD,
ic.ITEM_BAR_CODE, aid.MOD_DATE_TIME, aid.USER_ID
from DM.ALLOC_INVN_DTL aid, item_cbo ic where aid.CARTON_NBR in ('00000197181343285042') and aid.item_id=ic.item_id;--15

select tc_lpn_id from lpn where tc_lpn_id in ('99000133', '99031366', '00007160417183171807', '00007160410434855716', '00007160415956886361', '00007160415957800908', '00007160417183175393', '00007160410434855075', '00007160415959803181', '00007160415961682088', '00007160417183154299', '00007160417183183282', '00007160417183158464', '00007160417183192642', '00007160417183199467');--13


--Get the iLPNs for given oLPN that need to be created in RF:-
Select distinct aid.CNTR_NBR,ic.item_bar_code,ic.item_name,ic.item_id from DM.ALLOC_INVN_DTL aid, item_cbo ic where aid.CARTON_NBR in ('00000197181345462366') 
and aid.item_id=ic.item_id and aid.cntr_nbr not in (select tc_lpn_id from lpn where tc_lpn_id in aid.Cntr_NBR);  
 
