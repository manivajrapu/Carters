alter session set current_schema = DM;


select task_id,stat_code from task_hdr where task_id in ('89265278','89187444');---it can be in 10, 13 or 40-- after completing = 90

select count(*) from task_dtl where task_id in ('87273094') and stat_code<'90';---count will go to 0 after completing task thru SYS_CODE

select * from sys_code where code_type in ('CCF');



------------------------
select l.manifest_nbr "Manifest Number", l.tc_lpn_id "oLPN Number", l.lpn_facility_status "oLPN Status",
l.shipment_id "oLPN Shipment ID", ml.shipment_id "Manifested Shipment ID"
from lpn l, manifested_lpn ml
where l.lpn_id = ml.lpn_id
and l.lpn_facility_status =40
and l.shipment_id <> ml.shipment_id;