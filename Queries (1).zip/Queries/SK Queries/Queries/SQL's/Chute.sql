select unique l.tc_lpn_id, l.chute_assign_type
from lpn l, alloc_invn_dtl aid where l.tc_lpn_id = aid.carton_nbr and aid.cntr_nbr = '970900391897' and aid.stat_code < 90;

select chute_assign_type, tc_lpn_id from dm.lpn where tc_lpn_id in ('970900385962','970900442845','970900442657');

select tc_order_id from lpn where tc_lpn_id in ('00000197181472438616','00000197181472433727','00000197181472442750','00000197181472432966');

select tc_lpn_id, lpn_facility_status, tc_order_id,lpn_id from lpn where tc_lpn_id in ('00000156741218863985','00000156741218864395','00000156741218863503','00000156741218861622','00000156741218861516');

select do_status,order_type from orders where tc_order_id in ('1216069370','1216069374','1216069405','1216170585','1216170607');

select * from lpn_detail where lpn_id in ('53220145','53219844'),'','','');--53219844,53219854,53220048,53220102

select * from lpn_lock where tc_lpn_id in ('00000156741218863985','00000156741218864395','00000156741218863503','00000156741218861622','00000156741218861516');