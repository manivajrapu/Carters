--DC33 Retail SLA Tracker
SELECT dl_date,
  dl_date_adj,
  packdate,
  shipdate,
  DECODE(addr_code,'001','Carters','OshKosh') Division,
  order_qty,
  qty_pulld,
  in_sla_dl,
  in_sla_pack,
  in_sla_ship,
  DECODE(in_sla_dl,'Y',order_qty, 0) in_sla_dl_qty,
  DECODE(in_sla_pack,'Y',qty_pulld, 0) in_sla_pack_qty,
  DECODE(in_sla_ship,'Y',qty_pulld, 0) in_sla_ship_qty,
  DECODE(on_time_pack,'Y',qty_pulld, 0) on_time_pack_qty,
  DECODE(on_time_ship,'Y',qty_pulld, 0) on_time_ship_qty
FROM
  (SELECT DL_DATE,
    DL_DATE_ADJ,
    TO_CHAR(DL_DATE_ADJ, 'dy'),
    addr_code,
    packdate,
    SUM(order_qty) ORDER_QTY,
    SUM( qty_pulld) QTY_PULLD,
    DECODE(dl_date,dl_date_adj,'Y','N') IN_SLA_DL,
    CASE
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'wed'
      AND addr_code                   = '002'
      AND packdate - DL_DATE_ADJ     <=5
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'fri'
      AND packdate - DL_DATE_ADJ     <=3
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'sat'
      AND packdate - DL_DATE_ADJ     <=2
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy')                IN ('sun', 'mon', 'tue', 'wed', 'thu')
      AND packdate                     - DL_DATE_ADJ <=1
      THEN 'Y'
      ELSE 'N'
    END IN_SLA_PACK,
    SHIPDATE,
    CASE
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'wed'
      AND addr_code                   = '002'
      AND shipdate - DL_DATE_ADJ     <=5
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'fri'
      AND shipdate - DL_DATE_ADJ     <=3
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'sat'
      AND shipdate - DL_DATE_ADJ     <=2
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy')                IN ('sun', 'mon', 'tue', 'wed', 'thu')
      AND shipdate                     - DL_DATE_ADJ <=1
      THEN 'Y'
      ELSE 'N'
    END IN_SLA_SHIP,
    CASE
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'wed'
      AND addr_code                   = '002'
      AND packdate - DL_DATE         <=5
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'fri'
      AND packdate - DL_DATE         <=3
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'sat'
      AND packdate - DL_DATE         <=2
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy')            IN ('sun', 'mon', 'tue', 'wed', 'thu')
      AND packdate                     - DL_DATE <=1
      THEN 'Y'
      ELSE 'N'
    END ON_TIME_PACK,
    CASE
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'wed'
      AND addr_code                   = '002'
      AND shipdate - DL_DATE         <=5
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'fri'
      AND shipdate - DL_DATE         <=3
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'sat'
      AND shipdate - DL_DATE         <=2
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy')            IN ('sun', 'mon', 'tue', 'wed', 'thu')
      AND shipdate                     - DL_DATE <=1
      THEN 'Y'
      ELSE 'N'
    END ON_TIME_SHIP
  FROM
    (SELECT DL_DATE,
      DL_DATE_ADJ,
      addr_code,
      line_sku,
      SUM(order_qty) order_qty,
      PACKDATE,
      SUM(qty_pulld) qty_pulld,
      SHIPDATE
    FROM
      (SELECT sde.distro_nbr,
        sde.po_nbr,
        TRUNC(sde.create_date_time) DL_DATE,
        TRUNC(sde.create_date_time+11/24) DL_DATE_ADJ,
        im.spl_instr_2 addr_code ,
        im.dsp_sku,
        sde.sku_id line_sku,
        sde.REQD_qty order_qty,
        MAX(TRUNC(aid.mod_date_time)) PACKDATE,
        SUM(qty_pulld) qty_pulld,
        MAX(TRUNC(och.ship_date_time)) SHIPDATE
      FROM
        (SELECT sd.distro_nbr,
          sd.po_nbr,
          sku_id,
          MIN(sd.create_date_time) create_date_time,
          MIN(sd.create_date_time+11/24),
          SUM(sd.REQD_qty) REQD_qty
        FROM store_distro sd
        WHERE sd.whse     = '33'
        AND sd.stat_code <= '90'
        AND sd.STORE_NBR != '0991'
        AND sd.STORE_NBR != '0998'
          ---                     and sd.po_nbr = '10126081'
        AND sd.po_nbr NOT IN ('10124481', '10124482', '10124485', '10124487', '10124489', '10124490', '10124491', '10124501', '10124502', '10124503', '10124504', '10124505', '10124506', '10124507', '10124508', '10124509', '10124510', '10124511', '10124748', '10124768', '10124769', '10124770', '10124771', '10124772', '10124773', '10124774', '10124775', '10124780', '10124781', '10124785', '10124786', '10124791', '10124792', '10124793', '10124796', '10137039', '10137040', '10137041', '10137042', '10137043', '10137046', '10137047', '10137049', '10137050', '10137051', '10137052', '10137053', '10137054', '10137055', '10137056', '10137057', '10137058', '10137059', '10137060', '10137214', '10137218', '10137225', '10137226', '10137269', '10137270', '10137271', '10137709', '10137910', '10137911', '10137921', '10137924', '10137926', '10137931', '10137932', '10137933', '10137934', '10137935', '10137966', '10138171', '10138172', '10138173', '10138174', '10138175', '10138177', '10138191',
          '10138192', '10138201', '10138202', '10138205', '10138208', '10138209', '10138210', '10138211', '10138219', '10138220', '10138444', '10138469', '10138509', '10138510', '10138511', '10139018', '10139072', '10139073', '10140895', '10140896', '10140897', '10140898', '10141239', '10141263', '10141515', '10141516', '10142168', '10145367', '10145370', '10145371', '10145372', '10145375', '10145376', '10145404', '10145409', '10145433', '10145434', '10148631', '10148632', '10148643', '10148644', '10150358', '10150359', '10150387', '10150388', '10153493', '10153494', '10153496', '10153509', '10153510', '10153511', '10153521', '10153827', '10153846', '10153860')
          --     and sd.distro_nbr in ('330093253028', '330094570685')
        GROUP BY sd.distro_nbr,
          sd.po_nbr,
          sku_id
        ) sde,
        item_master im,
        pkt_dtl pd,
        alloc_invn_dtl aid,
        carton_dtl cd,
        outpt_carton_hdr och
      WHERE sde.sku_id         = im.sku_id
      AND im.sku_id            = sde.sku_id
      AND pd.distro_w_ctrl_nbr = sde.distro_nbr
      AND pd.sku_id            = sde.sku_id
      AND cd.pkt_ctrl_nbr      = pd.pkt_ctrl_nbr
      AND cd.pkt_seq_nbr       = pd.pkt_seq_nbr
      AND cd.sku_id            = pd.sku_id
      AND aid.carton_nbr       = cd.carton_nbr
      AND aid.carton_seq_nbr   = cd.carton_seq_nbr
      AND aid.sku_id           = cd.sku_id
        --      and aid.invn_need_type (+)= 60
      AND aid.stat_code (+) >= 90
      AND aid.stat_code (+) <= 99
      AND och.carton_nbr     = cd.carton_nbr
        --  ????? and bill_to_fax_number in ('B', 'E', 'R')
      GROUP BY sde.distro_nbr,
        sde.po_nbr,
        TRUNC(sde.create_date_time),
        TRUNC(sde.create_date_time+11/24),
        im.spl_instr_2 ,
        im.dsp_sku,
        sde.sku_id,
        sde.REQD_qty
      )
    GROUP BY DL_DATE,
      DL_DATE_ADJ,
      addr_code,
      line_sku,
      PACKDATE,
      SHIPDATE
    )
  WHERE DL_DATE > TRUNC(sysdate - 15)
  AND DL_DATE   < TRUNC(sysdate)
    -- and  order_qty > 1
  GROUP BY DL_DATE,
    DL_DATE_ADJ,
    addr_code,
    packdate,
    CASE
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'wed'
      AND addr_code                   = '002'
      AND packdate - DL_DATE_ADJ     <=5
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'fri'
      AND packdate - DL_DATE_ADJ     <=3
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy') = 'sat'
      AND packdate - DL_DATE_ADJ     <=2
      THEN 'Y'
      WHEN TO_CHAR(DL_DATE_ADJ, 'dy')                IN ('sun', 'mon', 'tue', 'wed', 'thu')
      AND packdate                     - DL_DATE_ADJ <=1
      THEN 'Y'
      ELSE 'N'
    END,
    SHIPDATE
  )