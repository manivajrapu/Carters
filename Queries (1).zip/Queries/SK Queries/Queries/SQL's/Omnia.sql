--Order Info
select order_type, parent_order_id, order_id  from orders where tc_order_id in ('1212749202');
select *  from orders where tc_order_id in ('8390187');


select line_item_id, parent_line_item_id orig_order_qty, order_qty, shipped_qty, ref_field3 from order_line_item where order_id = '25747792'; and item_name = '259G017 BP 4T';

select oli.is_cancelled, im.item_name, oli.received_qty, oli.shipped_qty, oli.user_canceled_qty, oli.orig_order_qty, oli.order_qty, oli.last_updated_dttm, oli.do_dtl_status, oli.ref_field3 from order_line_item oli, item_cbo im 
where im.item_name = oli.item_name and order_id = '25747792';
and im.item_style||'_'||im.item_color||'_'||im.item_size_desc = '259G017_670_4T';


--Order Line Item Info
select * from order_line_item where order_id = '25747792'; and item_name = '463G002 N 7';

select * from order_line_item where order_id = '25747792' and is_cancelled = '1';

select * from order_line_item where line_item_id = '22044845';

select * from order_line_item where order_id in ('25747792') and item_name = '119G018 W 6M';

select * from outpt_order_line_item where tc_order_id = '1211494484'; and batch_ctrl_nbr = '120472885';

select oli.do_dtl_status, oli.item_name, oo.batch_ctrl_nbr from order_line_item oli, outpt_order_line_item oo 
where oli.item_name = oo.item_name and oli.order_id in ('25747792') and oli.item_name = '119G018 W 6M' and do_dtl_status <> '190';

select item_id from item_cbo where item_name = '119G018 W 6M';

--Output Records
select sum(qty_alloc), sum(qty_pulld) from alloc_invn_dtl where tc_order_id = '1209871187' and item_id = '2089517';

select * from task_dtl where tc_order_id = '1209871187' and item_id = '1969975';

select line_item_id, order_qty, shipped_qty, user_canceled_qty, proc_stat_code, batch_ctrl_nbr, tc_order_id, item_name from outpt_order_line_item where tc_order_id = '1211494484'; and item_name = '119G018 W 6M';

select * from outpt_order_line_item;


--LPN Info

select sum(total_lpn_qty) from lpn where tc_order_id = '1211494484' and lpn_facility_status = 90 and item_id = '1969975';

select * from lpn where tc_order_id = '1211494484' and lpn_facility_status <> 90; and item_id = '1969975';

select sum(initial_qty), sum(shipped_qty) from lpn_detail where lpn_id in ('32708359'); and item_id = '1969975';

select l.tc_lpn_id, l.lpn_facility_status, ld.lpn_detail_status, l.tc_order_id, ld.shipped_qty, ld.initial_qty, l.tc_shipment_id, l.split_lpn_id  from lpn_detail ld, lpn l where l.lpn_id = ld.lpn_id and l.tc_order_id = '1211494484'; and l.lpn_facility_status <> 90;


select * from lpn_detail;


--Split records
select order_qty, shipped_qty, line_item_id, order_split_id from order_split_line_item where order_id = '25747792'; and line_item_id in ('197100947');


--Pix Records
select p.INVN_ADJMT_QTY, p.tran_type, p.tran_code, p.tran_nbr, p.item_name, p.ref_field_3, p.create_date_time from pix_tran p, item_cbo i where i.item_name = p.item_name and p.tran_type = '620' 
and (p.ref_field_3 in ('1214009545')) and i.item_name = '126G246 ASST 3M';

--query with ref field 1
select p.INVN_ADJMT_QTY, p.tran_type, p.tran_code, p.tran_nbr, p.item_name, p.ref_field_1, p.create_date_time from pix_tran p, item_cbo i where i.item_name = p.item_name and p.tran_type = '620' 
and (p.ref_field_3 in ('1214009545')) and i.item_name = '126G246 ASST 3M';

select INVN_ADJMT_QTY, tran_type, tran_code, tran_nbr, item_name, ref_field_3, create_date_time from pix_tran where tran_type = '620' 
and ref_field_3 in ('');

select * from pix_tran where tran_type = '620';

select proc_stat_code,tran_type, tran_code, tran_nbr, item_name, ref_field_1, create_date_time from pix_tran where tran_type = '620' 
and ref_field_1 in ('1211964835') and item_name = '11179211 OR 6M';

select * from pix_tran;


--Find Cancelled info
select item_name, order_qty, orig_order_qty, shipped_qty, received_qty, units_pakd, user_canceled_qty, do_dtl_status from order_line_item 
where order_id = '25747792'; and item_name = '119G018 W 6M';

select is_cancelled from orders where tc_order_id = '1211494484';

select * from order_line_item;



--Find Item Name
select item_name, item_id from item_cbo where item_style||'_'||item_color||'_'||item_size_desc in ('126G246_998_3M');

select item_id from item_cbo where item_name = '119G018 W 6M';



-- Ship Confirm status
select proc_stat_code, invc_batch_nbr, batch_ctrl_nbr, tc_order_id, shipment_id, outpt_orders_id from outpt_orders where tc_order_id in ('');
select * from outpt_orders;



