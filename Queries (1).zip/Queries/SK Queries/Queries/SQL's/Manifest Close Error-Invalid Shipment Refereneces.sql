alter session SET Current_schema=DM;

select l.manifest_nbr "Manifest Number", l.tc_lpn_id "oLPN Number", l.lpn_facility_status "oLPN Status",
            l.shipment_id "oLPN Shipment ID", ml.shipment_id "Manifested Shipment ID"
from lpn l, manifested_lpn ml
where l.lpn_id = ml.lpn_id
    and l.lpn_facility_status =40
        and l.shipment_id <> ml.shipment_id;
        
select lpn_facility_status, tc_lpn_id, tc_shipment_id, tc_order_id, ship_via, shipment_id, manifest_nbr from lpn where tc_lpn_id='00000197181450485922';
--14408198 shipment CS15372075 tc_shipment_id- Ship via is UPSC

select * from manifested_lpn where tc_lpn_id='00000197181450485922';--14408196-shipment before issue 
--After demanifest and manifest shipment id should get updated with LPN table shipment id.

select * from shipment where tc_shipment_id='CS15372075';

select do_status from orders where tc_order_id='1214745891';

select * from ship_via where ship_via='UPSC';
