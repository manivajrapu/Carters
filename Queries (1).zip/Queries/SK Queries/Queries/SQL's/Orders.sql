select * from dm.orders where tc_order_id in ('BCAR18755076_1','BCAR18755439_1');

select * from dm.shipment where tc_shipment_id in ('CS14154890','CS14154885');

select * from dm.item_cbo; where tc_order_id in ('BCAR18755076_1','BCAR18755439_1');