select * from inpt_xref where sku_brcd in ('000012516247','000012528189','000012529520','000012529469');

select msg from msg_log where ref_value_1 in ('10016283', '10016294', '10016311', '10016359');

select * from item_master where sku_brcd in ('000012516247','000012528189','000012529520','000012529469'); 

select * from pkt_hdr where pkt_ctrl_nbr in ('7000022254','7000023471','7000023362','7000024128');

select * from carton_hdr where PKT_CTRL_NBR='7000023471';

select * from inpt_pkt_hdr where pkt_ctrl_nbr in ('7000022254','7000024128');

select distinct pkt_ctrl_nbr from inpt_pkt_dtl where pkt_ctrl_nbr in ('7000022254','7000024128');

select * from INPT_PKT_INSTR where pkt_ctrl_nbr in ('7000022254','7000024128');