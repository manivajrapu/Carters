select * from inpt_asn_hdr where SHPMT_NBR='208447001';---SHPMT_NBR u will get it from UI
select * from ASN_HDR where SHPMT_NBR='208447001' ;
select PROC_STAT_CODE, ERROR_SEQ_NBR from inpt_asn_hdr;
select * from msg_log where REF_VALUE_1='176499957';--take from UI if it is not in db
--Invalid Vendor 11567_CODE bridged for Case 00006644549816006771�
select * from CASE_HDR where CASE_NBR='00006644549816006771';
--Invalid Vendor 11567_CODE bridged for Case 00006644549816006771 
select * from VENDOR_MASTER where VENDOR_ID='11567';--message Davis, Gregory <Gregory.Davis@carters.com> reguarding the invalid vendor code.
-------------------------------------------------------
--records were present in inpt table and wm table so we delete it from input table. 

------------------------------------------------------------------------
select * from inpt_asn_hdr where SHPMT_NBR='211794001';
select * from ASN_HDR where SHPMT_NBR='211794001';
select PROC_STAT_CODE,ERROR_SEQ_NBR from inpt_asn_hdr;
select * from msg_log where REF_VALUE_1='177622193';--take from UI if it is not in db
--invalid Item components bridged \\ refer IMP > Tue 5/16/2017 2:10 PM
select proc_stat_code,error_seq_nbr from inpt_IMMD_NEEDS;
select * from msg_log where ref_value_1 = '177622526';
--If "Item not found in Item Master" message then we need to drop mail to manish to download the missing styles into item_master from 
--inpt_immd_needs table.
select style, style_sfx , SEC_DIM, SIZE_DESC from inpt_IMMD_NEEDS;
select * from item_master where style in ('CF170482','v');