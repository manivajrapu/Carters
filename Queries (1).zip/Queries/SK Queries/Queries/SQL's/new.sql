alter session set current_schema = DM;

select o.ext_purchase_order "Order Number", o.tc_order_id "Ship Advise Number", ds.description "Order Status", 
        min(coalesce(oli2.tc_order_line_id,oli.tc_order_line_id)) "First Line", max(coalesce(oli2.tc_order_line_id,oli.tc_order_line_id)) "Last Line",
        oli.item_name, oli.ref_field3 "Orig Qty", 
        sum(case when oli.shipped_qty is null then 0 else oli.shipped_qty end) "Shipped Qty", 
        sum(case when oli.user_canceled_qty is null then 0 else oli.user_canceled_qty end) "Cancel Qty", 
        max(oli.last_updated_dttm) "Last Updated Date"
from orders o join  order_line_item oli on o.order_id = oli.order_id
left join order_line_item oli2 on oli.parent_line_item_id = oli2.line_item_id and oli.order_id = oli2.order_id
join do_status ds on o.do_status = ds.order_status
join do_status ds2 on oli.do_dtl_status = ds2.order_status
where
(o.ext_purchase_order='CAR23324676' AND o.do_status >=190 AND oli.sku_gtin = '889338166271') OR
(o.ext_purchase_order='BCAR23364810' AND o.do_status >=190 AND oli.sku_gtin = '700140871682') 
group by o.ext_purchase_order, o.tc_order_id, ds.description, oli.item_name, oli.ref_field3;


--Michele Query
with a as (select o.tc_order_id nbr, o.do_status, oli.item_name iTEM, oli.ref_field2 IORD, oli.batch_nbr DIM, oli.ref_field3 ord, sum(nvl(oli.shipped_qty,0)) ship
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id in (
'CAR23324676_1')
group by o.tc_order_id, do_status, item_name, oli.batch_nbr, ref_field2, ref_field3)
select nbr eCom_Order, do_status, item ITEM, IORD, DIM, ord UNITS_ORD, ship UNITS_SHIP, ord - ship UNITS_CANCELLED
from a where 
--ord = ship 
--or 
ord <> ship
order by 1,2;


select order_id,tc_order_id,do_status from orders where ext_purchase_order in ('CAR22237524', 'CAR22244095', 'CAR22247945', 'CAR22248851', 'BCAR22256924', 'CAR22256006', 'CAR22257554', 'CAR22257554');


select do_status, order_id, tc_order_id, ext_purchase_order from orders where ext_purchase_order in ('BCAR21198750', 'BCAR21381239', 'BCAR21383941', 'BCAR21403167', 'BCAR21406215', 'BCAR21407970', 'BCAR21407986', 'BCAR21408617', 'CAR21405922', 'BCAR21410577', 'BCAR21411062', 'BCAR21413815', 'BCAR21414106', 'BCAR21414208', 'BCAR21421194', 'BCAR21423064', 'BCAR21428084', 'BCAR21428097', 'BCAR21428898', 'CAR21419314') and do_status >=190;

select * from lpn where tc_order_id='BCAR21198750_1';

select * from wm_inventory where tc_lpn_id='00000197181474205230';

select shipped_qty, orig_order_qty from order_line_item where order_id='35356970';
select unique(tc_shipment_id),lpn_facility_status from lpn where tc_lpn_id in ('00000156741219023555', '00000156741219022459', '00000156741219020783', '00000156741219018667', '00000156741219022336', '00000156741219023029', '00000197181478582726', '00000197181478581644', '00000197181478581712', '00000197181478581651', '00000197181478582764', '00000197181478581590', '00000156741219022343', '00000156741219023548', '00000156741219023104', '00000156741219018032', '00000156741219016243', '00000156741219019299', '00000197181478581620', '00000156741219023586', '00000156741219019251', '00000156741219023425', '00000156741219022497', '00000156741219023111', '00000156741219023333', '00000197181478581927', '00000156741219020776', '00000156741219009641', '00000156741219022329', '00000156741219022794', '00000156741219022312', '00000156741219022534', '00000156741219022213');
select * from outpt_lpn where tc_lpn_id in ('00000156741219030164','00000156741219021483','00000156741219020783','00000156741219019299','00000197181478581927');
select * from outpt_lpn_detail where tc_lpn_id in ('00000156741219030164','00000156741219021483','00000156741219020783','00000156741219019299','00000197181478581927');

select * from task_hdr where task_id='53577722';
select * from task_dtl where task_id='53577722' and stat_code<'90';
select * from lpn where tc_lpn_id =' 970053577722';
select * from wm_inventory where tc_lpn_id='970053577722';

select * from orders where tc_order_id in ('CAR21975119_1','CAR22072485_1','CAR22012978_1','CAR21957602_1','CAR21993507_1');
select * from outpt_orders where tc_order_id in ('CAR21975119_1','CAR22072485_1','CAR22012978_1','CAR21957602_1','CAR21993507_1');
select * from lpn where tc_order_id in ('CAR21975119_1','CAR22072485_1','CAR22012978_1','CAR21957602_1','CAR21993507_1');
select * from outpt_lpn where tc_order_id in ('CAR21975119_1','CAR22072485_1','CAR22012978_1','CAR21957602_1','CAR21993507_1');
















