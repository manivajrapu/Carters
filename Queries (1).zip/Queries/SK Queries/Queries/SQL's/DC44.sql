select stat_code from inpt_asn_hdr where shpmt_nbr='187786001';

select * from inpt_asn_dtl where shpmt_nbr='187786001';

select stat_code from asn_hdr where shpmt_nbr='174603001';

select * from asn_dtl where shpmt_nbr='174603001';

select error_seq_nbr from inpt_item_master where inpt_item_master_id='58785067';

select * from inpt_item_master where style='121G583' and style_sfx='P' and sec_dim='CA075' and size_desc='MIX';

select * from item_master where style='121G583' and style_sfx='P' and sec_dim='CA075' and size_desc='MIX';

select * from inpt_asn_hdr where shpmt_nbr='189329001';

select * from inpt_asn_dtl where shpmt_nbr='189329001';

select * from asn_hdr where shpmt_nbr='189329001';

select * from asn_dtl where shpmt_nbr='189329001';

select * from inpt_case_hdr where case_nbr='00007160412807165453';

select * from inpt_case_dtl where case_nbr='00007160412807165453';

select * from inpt_bom_hdr;

select * from inpt_bom_dtl;

select * from msg_log where ref_value_1='10359030';

select * from item_master; where item_master_id='45462465';

-- Item cross
select * from inpt_xref where sku_brcd in ('000012516247','000012529599','000012525089','000012526772','000012529544');

select * from item_master where sku_brcd in ('000012516247','000012529599','000012525089','000012526772','000012529544');


select * from msg_log where ref_value_1='10304859';

select distinct(sku_brcd) from inpt_xref where error_seq_nbr>0;

--BOM Failures
select * from inpt_bom_hdr where bom_id in ('1286259','1289302','1289555','1291109','457094','530022','1293251','1376016','1376143','1460971','1494381');

select * from inpt_bom_dtl where bom_id in ('1286259','1289302','1289555','1291109','457094','530022','1293251','1376016','1376143','1460971','1494381');

select * from bom_hdr where bom_id in ('1286259','1289302','1289555','1291109','457094','530022','1293251','1376016','1376143','1460971','1494381');

select * from bom_dtl where bom_id in ('1286259','1289302','1289555','1291109','457094','530022','1293251','1376016','1376143','1460971','1494381');

select msg from msg_log where ref_value_1='10163886';

--1493827
select * from inpt_bom_hdr where bom_id='1494381';

select * from inpt_bom_dtl where bom_id='1494381';

select * from bom_hdr where bom_id='1494381';

select * from bom_dtl where bom_id='1494381';



--Pickticket Input Bridge

select * from msg_log where ref_value_1='10245361';

select distinct(error_seq_nbr) from inpt_pkt_dtl where pkt_ctrl_nbr = '7000025815';

select * from inpt_pkt_dtl where pkt_ctrl_nbr = '7000025815' and error_seq_nbr = '10245361';

select * from pkt_hdr where pkt_ctrl_nbr = '7000025815'

select * from pkt_dtl where pkt_ctrl_nbr = '7000025815' and error_seq_nbr = '10245361';

select * from item_master where style = '341G233' and style_sfx = 'S' and size_desc = '2T' and sec_dim = 'INT01';

select style,style_sfx,size_desc,sec_dim from inpt_pkt_dtl where error_seq_nbr > 0;

select * from inpt_asn_dtl where shpmt_nbr in ('174603001', '183193001', '183742001', '185966001', '185969001', '185970001', '185971001', '186563001', '186685001', '186686001', '186686002', '186686003', '186706001', '186936001', '186936002', '186963001', '187067001', '187242001', '187369001', '187412001', '187549001', '187610001', '187619001', '187849001', '182035001');

select shpmt_nbr, stat_code from asn_hdr where shpmt_nbr in ('174603001', '183193001', '183742001', '185966001', '185969001', '185970001', '185971001', '186563001', '186685001', '186686001', '186686002', '186686003', '186706001', '186936001', '186936002', '186963001', '187067001', '187242001', '187369001', '187412001', '187549001', '187610001', '187619001', '187849001', '182035001');

select * from asn_dtl where shpmt_nbr in ('174603001', '183193001', '183742001', '185966001', '185969001', '185970001', '185971001', '186563001', '186685001', '186686001', '186686002', '186686003', '186706001', '186936001', '186936002', '186963001', '187067001', '187242001', '187369001', '187412001', '187549001', '187610001', '187619001', '187849001', '182035001');

select * from case_hdr where case_nbr='00006644549973177888';

select shpmt_nbr, stat_code, error_seq_nbr from inpt_asn_hdr where shpmt_nbr in ('174603001', '183193001', '183742001', '185966001', '185969001', '185970001', '185971001', '186563001', '186685001', '186686001', '186686002', '186686003', '186706001', '186936001', '186936002', '186963001', '187067001', '187242001', '187369001', '187412001', '187549001', '187610001', '187619001', '187849001', '182035001');

--ASN input Bridge

select error_seq_nbr,stat_code from inpt_asn_hdr where shpmt_nbr='190568001';
select error_seq_nbr,stat_code from inpt_asn_hdr where shpmt_nbr='190571001';
select error_seq_nbr,stat_code from inpt_asn_hdr where shpmt_nbr='190573001';

select stat_code from asn_hdr where shpmt_nbr='190568001';
select stat_code from asn_hdr where shpmt_nbr='190571001';
select stat_code from asn_hdr where shpmt_nbr='190573001';






