select shpmt_nbr, error_seq_nbr, proc_stat_code from inpt_asn_hdr;

select * from case_hdr where case_nbr in ('00007160420713293108','00007160420712405359','00007160420712498399','00007160420712467944');

select * from inpt_asn_dtl where shpmt_nbr in ('201504010','201504011','201504012','201504013');
select * from asn_hdr where shpmt_nbr in ('201504010','201504011','201504012','201504013');
select * from asn_dtl where shpmt_nbr in ('201504010','201504011','201504012','201504013');


select stat_code from inpt_asn_hdr where shpmt_nbr in ('201504004','197465001');
select * from asn_dtl where shpmt_nbr in ('197157001','197210001');
select * from msg_log where ref_value_1 in ('164639249','164616752');

select * from carton_hdr where carton_nbr in ('00000156741219030164','00000156741219021483','00000156741219020783','00000156741219019299','00000197181478581927');

select style, style_sfx, sec_dim, size_desc, error_seq_nbr, proc_stat_code from inpt_item_master;



where error_seq_nbr>'0';
select * from inpt_bom_hdr where error_seq_nbr>'0';
select error_seq_nbr,proc_stat_code from inpt_store_master where error_seq_nbr>'0';
select * from msg_log where ref_value_1 in ('165808896'),'163266351');

--update inpt_store_master set proc_stat_code = 0, error_seq_nbr = 0;

select * from item_master where style in ('GB15831','CF161404','CF161286') and style_sfx in ('AST') and size_desc in ('1','4.5','4');
select error_seq_nbr, proc_stat_code from inpt_bom_hdr where error_seq_nbr>'0';
select * from inpt_bom_dtl where bom_id='1856231';
select error_seq_nbr, proc_stat_code from inpt_bom_hdr where bom_id='1856231';
select * from bom_hdr where bom_id='1856231';
select * from bom_dtl where bom_id='1856231';
select * from msg_log where ref_value_1 in ('166044733');--116471134,116293992
select * from item_master where style='268G337' and style_sfx='PRT' and size_desc='8';


'00000197183468404391','0000019783468404483','00000197183468404582'
select distinct()stat_code from carton_hdr where pkt_ctrl_nbr ='3412864618'; 
select distinct(rte_id),ship_via from carton_hdr where pkt_ctrl_nbr ='3412864618'; 
select * from ship_via where ship_via='DCB';
select rte_id,stat_code,ship_via,carton_nbr, load_nbr from carton_hdr where carton_nbr in ('00000197183468404391','00000197183468404483','00000197183468404582');
select stat_code,carton_nbr,rte_id,ship_via,load_nbr from carton_hdr where pkt_ctrl_nbr ='3412864618' and rte_id is not null and stat_code in (15,30);

select carton_nbr from carton_hdr where pkt_ctrl_nbr ='3414190050'; 
select pkt_ctrl_nbr from carton_hdr where carton_nbr='00000197183961281000';
select distinct(rte_id) from carton_hdr where pkt_ctrl_nbr ='3412864618'; 
select stat_code,carton_nbr,rte_id from carton_hdr where pkt_ctrl_nbr ='3412864618' and rte_id is null and stat_code in (15,30);
select * from carton_hdr where load_nbr='33000';




select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
           --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;
            
---- Brian Query        
            select /*+rule */
       ses.process,
       ses.sid as sid,
       ses.serial# as serial_num,
       ses.username as db_username,
       pro.spid     as host_pid,
       ses.machine  as machine,
       substr(ses.program,1,60) as program,
       substr(obj.object_name,1,20) as object_name,
       loc.lock_type as lock_type,
       loc.mode_held as mode_held,
       loc.mode_requested as mode_req,
       ( CASE WHEN LOc.LAST_CONVERT > (24 * 3600)
         THEN floor(LOc.LAST_CONVERT/(24 * 3600)) || ' Days '
         ELSE ''
         END
       ) || to_char(to_date('01-JAN-80') + LOC.LAST_CONVERT /(24*3600), 'HH24:MI:SS') LOCKED_TIME,
       loc.blocking_others as is_blocking
  from v$session ses,
       v$process pro,
       dba_lock loc,
       dba_objects obj
 where ses.sid      = loc.session_id
   and ses.paddr    = pro.addr
   and loc.lock_id1 = obj.object_id
   and ses.username is not null
order by ses.process, ses.sid, ses.serial#;

select * from inpt_bom_hdr where style='263H390' and style_sfx='HE' and size_desc='8';

select * from bom_dtl where style='263H390' and style_sfx='HE' and size_desc='8';
select * from msg_log where ref_value_1='163704525';
select * from item_master where style='A20G002' and style_sfx='ASST' and sec_dim='SJ001' and size_desc='3-6';
select * from item_master where style='263H390' and style_sfx='HE' and size_desc='8';

select distro_nbr, error_seq_nbr, proc_stat_code, stat_code from inpt_store_distro;
select distro_nbr,stat_code from store_distro where distro_nbr in ('330143874050', '330144757050', '330144757049', '330144757048', '330144757047', '330144757046', '330143834347', '330143821100', '330143834346', '330143834342', '330143834345', '330143834343', '330143834344', '330143834349', '330143834350', '330143834348', '330143862750', '330143862749', '330143862748', '330143862746', '330143862747', '330143863050', '330143863049', '330143863048');
select * from msg_log where ref_value_1='166044727';

select * from vendor_master where vendor_id='';