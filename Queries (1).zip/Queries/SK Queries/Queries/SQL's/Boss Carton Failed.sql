select non_inventory_lpn_flag, lpn_facility_status from dm.lpn where tc_lpn_id = '00000197181681425346';

select * from dm.lpn where tc_lpn_id = '00000197181681425346';

select * from DM.LPN_DETAIL where lpn_id = '00000197181681425346';


select tc_lpn_id,lpn_facility_status from lpn where tc_lpn_id in ('00000197181681425346');


