alter session SET Current_schema=DM;

--Michele query to check the cancelled qty's in orders table.

with a as (select o.tc_order_id nbr, o.do_status, oli.item_name iTEM, oli.ref_field2 IORD, oli.batch_nbr DIM, oli.ref_field3 ord, sum(nvl(oli.shipped_qty,0)) ship
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id in (
'BCAR22352963_1')
group by o.tc_order_id, do_status, item_name, oli.batch_nbr, ref_field2, ref_field3)
select nbr eCom_Order, do_status, item ITEM, IORD, DIM, ord UNITS_ORD, ship UNITS_SHIP, ord - ship UNITS_CANCELLED
from a where 
--ord = ship 
--or 
ord <> ship
order by 1,2;
