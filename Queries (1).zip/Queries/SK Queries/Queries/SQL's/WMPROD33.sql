select * from inpt_store_master where store_nbr='0732';

select * from inpt_pkt_hdr_dtl;