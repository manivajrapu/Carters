alter session SET Current_schema=DM;

select * from dm.orders where manifest_nbr='UPS000015901';

select * from dm.lpn where manifest_nbr='UPS000008662'; and lpn_facility_status='90';

select * from dm.lpn where manifest_nbr='UPS000008660';

select * from dm.lpn where manifest_nbr='UPS000008663';

select * from dm.manifest_hdr where tc_manifest_id='UPS000008662';

select * from dm.manifest_hdr where tc_manifest_id='UPS000008660';

select * from dm.manifest_hdr where tc_manifest_id='UPS000008663';

select 'ECOM' CHANNEL, manif_nbr MANIFEST, shpr_id ACCT, max(create_date_time) UPLOAD_DATE
from ups_emt_upload_rpt_hist where rpt_type = '1' 
and create_date_time > sysdate - 1
and shpr_id in ('869V6R', '015104')
group by manif_nbr, shpr_id
having count(*) = 1 
UNION ALL
select DECODE(SHIPPER_AC_NUM,'882W15','RETAIL','WHOLESALE') CHANNEL, mh.tc_manifest_id MANIFEST, shipper_ac_num ACCT, close_date UPLOAD_DATE
from manifest_hdr mh where close_date > sysdate - 1 and shipper_ac_num in ('882W15','A596Y8') and ups_pld_upload_indic is null and manifest_status_id = 90
and exists (select 1 from lpn l where l.manifest_nbr = mh.tc_manifest_id and l.lpn_facility_status = 90) 
order by MANIFEST;
