select * from inpt_xref where sku_brcd in ('000012516247','000012526819','000012527069','000012524624','000012525744');


select * from item_master where sku_brcd in ('000012516247','000012526819','000012527069','000012524624','000012525744');

select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
           --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;
 
 
select * from trans_invn where trans_invn_type='1'; 
 
select * from SYS_CODE WHERE  CODE_DESC='Recall Invn'; 

select * from sys_code where code_type='052' and code_id='1';
 

 
-- delete from trans_invn where trans_invn_type='1' and sku_id='115534027';
 
 select * from item_master where sku_id='115534027';


 select * from pix_tran;
 

 
 
 
 
 desc trans_invn_type;
 
 