select p.tran_nbr, p.proc_stat_code, sum(p.INVN_ADJMT_QTY), p.tran_type, p.tran_code, p.item_name, p.ref_field_1 
from pix_tran p, item_cbo i where i.item_id = p.item_id and p.tran_type = '620' and p.style||'_'||p.color||'_'||p.size_desc||'_'||p.ref_field_1 in 
('11108311_984_24M_1213988690') and p.proc_stat_code <> 91 group by p.tran_nbr, p.proc_stat_code, p.tran_type, p.tran_code, p.item_name, p.ref_field_1 order by p.tran_nbr;

--Please ship confirm
select manifest_nbr, substr(tc_shipment_id,10,1) "SHIPMENT_ENDING", lpn_facility_status, count(*) 
from lpn where manifest_nbr = 'UPS000009966' 
and lpn_facility_status < 99 group by manifest_nbr, substr(tc_shipment_id,10,1), lpn_facility_status;

select * from lpn where manifest_nbr='UPS000009966' and tc_lpn_id='00000197181440982738';

select * from prod_trkg_tran where cntr_nbr='00000197181440982738' order by create_date_time desc
