select pkt_ctrl_nbr,distro_nbr,invn_type,stat_code,sku_id,po_nbr,reqd_qty,alloc_qty,case_nbr,wave_nbr,ship_wave_nbr,wave_alloc_qty from store_distro where distro_nbr='330119550581';

select sku_id,pkt_ctrl_nbr,orig_ord_qty,orig_pkt_qty,pkt_qty,to_be_verf_as_pakd,verf_as_pakd,units_pakd,std_bundl_qty from pkt_dtl where pkt_ctrl_nbr='3412410501' and sku_id='115771764';

--update store_distro 
  set stat_code='90', 
      user_id='PILLAREM',
      mod_date_time=sysdate
      where stat_code='30';
      