Select * from manif_parcl_hdr where manif_nbr='FXGD330057988';

select stat_code,carton_nbr,manif_nbr from manif_parcl_carton  where manif_nbr='FXGD330057988';

select * from manif_parcl_carton  where  parcl_shpmt_nbr in('335601153','335601152','335601152');

3300092555

select * from Carton_hdr where parcl_shpmt_nbr in('335601153','335601152','335601152');

select * from outpt_carton_hdr where manif_nbr='FXGD330057988';

select * from outpt_carton_dtl;