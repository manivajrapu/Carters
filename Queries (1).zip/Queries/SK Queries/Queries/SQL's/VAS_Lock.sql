alter session SET Current_schema=DM;

--VAS lock
Select inventory_lock_code from lpn_lock where tc_lpn_id in ('00000197181447055176','00000197181447054971');

select DISTINCT(stat_code) from vas_carton where carton_nbr in ('00000197181447055176','00000197181447054971');

select carton_nbr,reqd_qty, cmpl_qty,stat_code from vas_carton where carton_nbr in ('00000197181447055176','00000197181447054971');









select order_id from orders where ext_purchase_order='CAR19581523';

select item_name, units_pakd from order_line_item where order_id ='32090031' and item_name='263G535 IVY 7'
select * from item_cbo where item_name='263G535 IVY 7';

select * from prod_trkg_tran where item_id='2228069'

select * from lpn where tc_lpn_id='00000197181447022017';

 