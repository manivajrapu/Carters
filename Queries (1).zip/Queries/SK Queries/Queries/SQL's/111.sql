select * from inpt_xref where sku_brcd in ('000012516247','000012553549','000012546237','000012527892','000012527311');

select * from item_master where sku_brcd in ('000012516247','000012553549','000012546237','000012527892','000012527311');

select distinct(sku_brcd) from inpt_xref where error_seq_nbr>0;

select * from inpt_bom_hdr where bom_id='1293251';

select * from inpt_bom_dtl where bom_id='1293251';

select * from bom_hdr where bom_id='1293251';

select * from bom_dtl where bom_id='1293251';

select * from inpt_asn_hdr where shpmt_nbr='181366001';

select * from inpt_asn_dtl where shpmt_nbr='181366001';

select * from asn_hdr where shpmt_nbr='181366001';

select * from asn_hdr where shpmt_nbr='181366001';