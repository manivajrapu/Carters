alter session SET Current_schema=DM;

select * from lpn where manifest_nbr='UPS000014085';
select * from lpn where manifest_nbr='UMI000007118';
select * from lpn where manifest_nbr='UPS000013625';
select * from lpn where manifest_nbr='UPS000013469';
select * from lpn where manifest_nbr='UPS000013437';
select * from lpn where manifest_nbr='UPS000013476';

--Fatal Error Query--
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000014310';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013119';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013084';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013081';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013082';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013083';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013086';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000012999';

select tc_lpn_id,lpn_facility_status,lpn_id,tc_order_id,total_lpn_qty from lpn where tc_lpn_id in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224');
select * from lpn_detail where lpn_id in ('54393166') and lpn_detail_status<'90';
select do_status, order_id,order_type from orders where tc_order_id in ('CAR23484629_1', 'CAR23485196_1', 'CAR23485197_1', 'CAR23485341_1', 'CAR23486170_1', 'CAR23484455_1', 'CAR23485169_1', 'CAR23486283_1', 'CAR23487028_1', 'CAR23487056_1', 'ICAR23489563_1', 'CAR23488223_1');
select * from picking_short_item where tc_lpn_id in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224');
select * from lpn_lock where tc_lpn_id in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224');
select count(*) from alloc_invn_dtl where cntr_nbr in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224') and stat_code<'90';
select * from alloc_invn_dtl where cntr_nbr in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224') and stat_code<'90';
select * from task_dtl where cntr_nbr in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224') and stat_code<'90';
select do_dtl_status,allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id='38944881' and do_dtl_status<'150';

--BOSS Carton Close
select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);

select tc_lpn_id,lpn_facility_status,lpn_id,tc_order_id,total_lpn_qty, last_updated_source from lpn where tc_lpn_id in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select * from lpn_detail where lpn_id in ('60149689') and lpn_detail_status <'90';
select order_type,do_status,order_id from orders where tc_order_id in ('CAR23481517_1','CAR23481667_1','CAR23481789_1','CAR23482276_1');
select * from picking_short_item where tc_lpn_id in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select * from alloc_invn_dtl where cntr_nbr in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select * from task_dtl where cntr_nbr in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select * from lpn_lock where tc_lpn_id in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select do_dtl_status from order_line_item where order_id in ('39183159') and do_dtl_status < '150';
select allocated_qty,orig_order_qty,order_qty,units_pakd from order_line_item where order_id in ('39182751') and do_dtl_status < '150';
select tc_lpn_id,tc_order_id,lpn_facility_status from lpn where tc_order_id in ('CAR23481517_1','CAR23481667_1','CAR23481789_1','CAR23482276_1');


--2285355,2285067

select * from wm_inventory where tc_lpn_id ='00000197181505060531' and item_id in ('2285355','2285067');

select * from lpn where tc_lpn_id in ('EXC_231216_000007457','EXC_231216_000007456');

--BOSS PTS Failed
select cle.name, to_char(cleq.msg_id) MSG_ID, l.tc_lpn_id, o.tc_order_id, when_queued, cleq.status, REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 14) USER_ID
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l, orders o
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and l.order_id = o.order_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 6)  = l.tc_lpn_id 
and o.order_type = 'EC'
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_PickConfirm') 
and error_count > 1;

select tc_lpn_id,lpn_facility_status,lpn_id,tc_order_id from lpn where tc_lpn_id in ('00000197181327430345'),'00000197181503711374','00000197181503711350');
select tc_order_id,do_status,order_type,order_id from orders where tc_order_id in ('CAR23211387_1','1217700550');--38792649,38622291
select do_dtl_status,allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id ='38792649' and item_id in ('2290435','2289923');
select * from lpn_detail where lpn_id in ('59482391','59482383');--2290435,2289923
select * from wm_inventory where item_id in ('2290435','2289923') and tc_lpn_id in ('00000197181502285401','00000197181503711374','00000197181503711350');

select * from lpn where tc_shipment_id ='CS19807110';
select * from lpn where tc_shipment_id ='CS19807708';
select * from lpn where tc_shipment_id ='CS19807104';

------------------------------------------------------------------------
select tc_lpn_id,lpn_facility_status,tc_order_id,tc_shipment_id,ship_via,manifest_nbr,last_updated_source from lpn where tc_lpn_id in ('00000197181328801274','00000197181328801762','00000197181328837709');
select order_type,do_status from orders where tc_order_id='1218562385';
select do_status,order_type from orders where tc_order_id in ('BCAR24015918_1','BCAR24015950_1','BCAR24019637_1');
select tc_lpn_id,lpn_facility_status,tc_order_id from lpn where tc_order_id in ('BCAR24015918_1','BCAR24015950_1','BCAR24019637_1');
select * from lpn where tc_shipment_id='CS20409742';
select * from ship_via where ship_via='UEGD';--UPS Ground Ecom
select * from shipment where tc_shipment_id='CS20409742';


