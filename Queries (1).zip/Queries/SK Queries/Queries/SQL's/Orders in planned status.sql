alter session SET Current_schema=DM;

Select o.ext_purchase_order, o.order_id, o.tc_order_id, o.order_status, o.do_status, l.tc_lpn_id, l.order_split_id, os.order_split_id, ship_via, to_char(l.shipment_id) shipment_Id, l.tc_shipment_Id, s.assigned_ship_via S_SHIP_VIA, s.shipment_id S_SHIP_ID, s.tc_shipment_id s_TC_SHIP_ID,
  'update lpn set order_split_id = '||chr(39)||os.order_split_id||chr(39)||', ship_via = '||chr(39)||s.assigned_ship_via||chr(39)||', shipment_id =  '||chr(39)||s.shipment_id||chr(39)||', tc_shipment_Id = '||chr(39)||s.tc_shipment_id||chr(39)||' where tc_lpn_id = '||chr(39)||l.tc_lpn_id||chr(39)||';' CCF
from orders o, lpn l, order_split os, shipment s where o.order_id = l.order_id and o.order_id = os.order_id (+) and os.shipment_Id = s.shipment_Id (+)
and o.ext_purchase_order in ('OKB BABBLE BOXX 7.13')
and l.lpn_facility_status < 40 and s.shipment_status = 60 and os.is_cancelled = 0
order by ext_purchase_order, tc_order_id and tc_sh;

select * from orders where tc_order_id='DH2E8VJ';

select ext_purchase_order "PURCHASE_ORDER", bill_to_name "CUSTOMER", 
        addr_code "DIV", rte_to "ROUTE_TO", lane_name "LANE", tc_shipment_id "ORDERS_SHIPMENT_ID", count(*) "TOTAL_ORDERS"
from orders o where order_type not in ('EC','SD') and order_status = 10 and do_status < 190
and exists (select 1 from lpn l where l.order_id = o.order_id and l.lpn_Facility_status < 90 and tc_shipment_Id is null and inbound_outbound_Indicator = 'O')
group by  ext_purchase_order, bill_to_name, addr_code, rte_to, lane_name, tc_shipment_id;

select * from lpn where tc_lpn_id ='99019326';

select * from lpn_detail where lpn_id='52128643';

select * from alloc_invn_dtl where cntr_nbr='52128643';

select * from task_hdr where task_id='52511897';
select  tc_lpn_id,wm_allocated_qty  from wm_inventory where tc_lpn_id in ('00000156740021195061', '00007160417170487003', '00007160417170487034', '00007160417170488116', '00007160417170488239', '00007160417170488581', '00007160417170488956', '00007160417170489007', '00007160417170489052', '00007160417170489083', '00007160417170489090', '00007160417171114380', '00007160417171116193', '00007160417171116209', '00007160417171116322', '00007160417171116346', '00007160417171116414', '00007160417171116476', '00007160417171116506', '00007160417171116513'); 
select unique(cntr_nbr) from task_dtl where task_id='52511897' and stat_code<'90';
select * from alloc_invn_dtl where task_genrtn_ref_nbr='201609220090' and stat_code<'90';



select * from lpn where ORDER_ID in ('DH2E8VJ');


select * from task_dtl where task_id in ('84606048');
