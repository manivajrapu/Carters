alter session SET Current_schema=DM;


select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status <= 180 and lpn_facility_status < 40 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status > 60);

select TC_ORDER_ID,ORDER_STATUS,DO_STATUS from DM.ORDERS where TC_ORDER_ID in('RCAR10509331_1');

select * from shipment where tc_shipment_id in ('CS36158501');--Cancelled   FXGE

select SHIPMENT_ID ,item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,SHIP_VIA,manifest_nbr,last_updated_source,order_id,TC_SHIPMENT_ID,
INBOUND_OUTBOUND_INDICATOR,LAST_UPDATED_DTTM from lpn where tc_lpn_id in ('00000197181647863465'); --ship_via:FEHD

select USER_ID,STAT_CODE from DM.SHIP_WAVE_PARM where SHIP_WAVE_NBR in('201803060103');  
--201803040045:CS26984711:BCAR28967425_1:00000197181594954728 -- new shipment

select * from Wave_queue where SHIP_WAVE_PARM_ID in ('130817');


select l.tc_order_id, o.order_id, o.order_status, o.do_status, o.shipment_id, o.tc_shipment_id, o.dsg_ship_via, o.line_haul_ship_via, l.tc_lpn_id, l.lpn_facility_status, l.tc_shipment_id, l.shipment_id, l.ship_via, o.ship_group_id, l.order_split_id
from orders o, lpn l where o.order_id = l.order_id and l.tc_lpn_id = '00000197181584758916';

select * from order_split where order_id = '49251873'
and  exists (select 1 from shipment where shipment.shipment_id = order_split.shipment_id and shipment_status = 60);

select description,ship_via from SHIP_VIA where ship_via in ('FXSP');

select o.tc_order_id, s.shipment_Id, s.tc_shipment_id, os.* from shipment s, orders o, order_split os where 
os.shipment_id = s.shipment_Id and os.order_id = o.order_id and o.tc_order_id in ('1222039389');



-------------------------------------------------------------------------------------------------------------------------------------------------
select * from ship_wave_parm where USER_ID= 'nigama';

select do_status from orders where TC_ORDER_ID = '1222039389' ;



select tc_order_id, tc_shipment_id, lpn_facility_status,ship_via,MANIFEST_NBR from lpn where tc_lpn_id in ('00000197181564853488');


select tc_order_id,do_status, order_id,order_type, tc_shipment_id, ext_purchase_order,order_type from orders where tc_order_id in ('CAR24785419_1');
select tc_lpn_id,tc_shipment_id,tc_order_id,lpn_facility_status,ship_via,last_updated_source from lpn where tc_lpn_id='00000197181529930650';
select * from orders where tc_order_id='1218458584';
select * from lpn where tc_order_id='1221520468';
select * from ship_via where ship_via='UPSC';


select * from POSTAL_CODE where postal_code='10033';
select * from ship_wave_parm where ship_wave_nbr='201704040003';
select * from ship_wave_parm where user_id = 'dsilvas';

select*from DM.SHIP_WAVE_PARM where PICK_WAVE_NBR = '201703090028';--

Select count(*) from alloc_invn_dtl where TASK_GENRTN_REF_NBR = '201703090028' and stat_code < 90;

select * from 
select * from DM.WAVE;

select lpn_facility_status,INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('00000156740031960079','970060866708');
select * from DM.task_dtl where cntr_nbr = '00000156740031960079' and stat_code<90;
select * from DM.ALLOC_INVN_DTL where cntr_nbr = '00000156740031960079' and stat_code<90;




00000156740031960079
970060866708

select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status <= 180 and lpn_facility_status < 40 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status > 60);






select * from manifest_hdr where tc_manifest_id='UPS000013020';
select * from lpn where manifest_nbr='UPS000013020';
select * from order_line_item where order_id='32506883';
select do_status,order_type, ext_purchase_order from orders where tc_order_id='1217772330';
select tc_order_id, tc_shipment_id, lpn_facility_status,ship_via from lpn where tc_lpn_id in ('00000197181506459778','00000197181506459594');
select * from ship_via where ship_via='UEGD';
select * from lpn where tc_order_id ='BCAR21431321_1';

--201611080049
select * from ship_wave_parm where ship_wave_nbr='201611080049';

select tc_lpn_id, tc_shipment_id, lpn_facility_status, ship_via, tc_order_id, shipment_id, manifest_nbr, last_updated_source from lpn where tc_lpn_id in ('00000197181473449895'),'00000197181471873395','00000197181472267223');

select description from ship_via where ship_via='HJBI';

select * from ship_wave_parm where ship_wave_nbr='201609270056';
is 201609270056

select * from lpn where tc_lpn_id='00000197181453451276';

select * from task_dtl where task_genrtn_ref_nbr='201608080002' and stat_code<'90';--Wave 201703090028 is showing complete by DF, but still showing up on the DF Dashboard in clean-up can you assist in this matter??

select * from alloc_invn_dtl where task_genrtn_ref_nbr='201608080002' and stat_code<'90';--100338384, 100338123 100338137

select * from locn_hdr where locn_id in ('100338384','100338123','100338137');
-- 00000156741217782867 477721670
-- 2239756
-- 20625583  312243763
select * from lpn where tc_lpn_id = '00000156741217780764';

select * from item_cbo where item_id='2239756';

select * from pkt_dtl where pkt_ctrl_nbr = '20625583' and pkt_seq_nbr = '312243763';
select tc_order_id,lpn_facility_status, tracking_nbr from lpn where tc_lpn_id = '00000197181325269671';
select * from lpn_detail where lpn_id = '49604465' and lpn_detail_id = '477721670';
select do_status from orders where tc_order_id ='BCAR21513670_1';

PDF0320B05 -DSP location
31734610 DM 4 item name


select tc_lpn_id,lpn_facility_status,tc_order_id,tc_shipment_id from lpn where tc_lpn_id in ('EXC_060217_000008308');
select * from alloc_invn_dtl where cntr_nbr='EXC_060217_000008308' and stat_code < '90';
