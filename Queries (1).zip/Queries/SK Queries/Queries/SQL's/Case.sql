select case_nbr,stat_code from case_hdr where case_nbr in ('00006644543314310644');

select case_nbr,actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in ('00006644543314310644');

select * from alloc_invn_dtl where cntr_nbr in ('00006644543314310644') and stat_code<'90';

select * from task_dtl where cntr_nbr in ('00006644543314310644') and stat_code<'90';
select * from task_hdr where cntr_nbr in ('00006644543314310644') and stat_code<'90';
-------------------------------------------------------------------------------------------

select case_nbr,stat_code from case_hdr where case_nbr in ('00007160414613672132', '00007160414613674303', '00007160414613674679', '00007160414613924828', '00007160414613925245', '00007160414613925962');

select case_nbr,actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in ('00007160414613672132', '00007160414613674303', '00007160414613674679', '00007160414613924828', '00007160414613925245', '00007160414613925962');

select * from alloc_invn_dtl where cntr_nbr in ('00007160414613672132', '00007160414613674303', '00007160414613674679', '00007160414613924828', '00007160414613925245', '00007160414613925962') and stat_code<'90';

select * from task_dtl where cntr_nbr in ('00007160414613672132', '00007160414613674303', '00007160414613674679', '00007160414613924828', '00007160414613925245', '00007160414613925962') and stat_code<'90';
select * from SHIP_WAVE_PARM where PICK_WAVE_NBR='201702040008';
select * from ALLOC_INVN_DTL where TASK_GENRTN_REF_NBR='201702040008' and stat_code<'90';
select * from TASK_DTL where TASK_GENRTN_REF_NBR='201702040008' and stat_code<'90';

select count(*)
from alloc_invn_dtl 
where invn_need_type='60'
and stat_code='0' 
  and cntr_nbr = '00007160415948636363';
  
  select count(*)
from alloc_invn_dtl 
where invn_need_type='60'
    and stat_code='00' 
    and cntr_nbr = '00007160415948636363';

--116132951

select * from task_hdr where sku_id='116109126' and stat_code <'90';

258G316 PRT FP002 3T
select * from item_master where style='258G316' and style_sfx='PRT' and sec_dim='FP002' and size_desc='3T';
select * from alloc_invn_dtl where sku_id='116109126' and task_genrtn_ref_nbr='201607210023';
select * from case_hdr;

select * from alloc_invn_dtl where task_genrtn_ref_nbr='201609080011' and stat_code<'90';

select * from ship_wave_parm where pick_wave_nbr='201609080011';
select * from alloc_invn_dtl where sku_id in ('116151943', '116151948', '116217580', '116151969', '116130922', '116151974', '116151988', '116151993', '116151998', '116237554', '116104538');

select * from item_master where style = '278G294' and style_sfx = 'DM' and size_desc= '6';

from  task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
   and aid.stat_code = '0'
  and aid.cntr_nbr in ('00006644543309323598','00007160412304388560')  
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id
   and td.stat_code < '99'; 
 
select *
from task_hdr
where task_id in (select td.task_id
from task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
and aid.stat_code = '00'
and aid.cntr_nbr in ('00006644543309323598','00007160412304388560')
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id)
   and stat_code <'99';
   
     select td.*
from  task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
   and aid.stat_code = '0'
  and aid.cntr_nbr in ('00006644543309323598','00007160412304388560')
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id
   and td.stat_code < '99'; 
   
   
   
   select rte_id, pkt_ctrl_nbr from carton_hdr where carton_nbr in ('00000197183465057460','00000197183465240183','00000197183465244198','00000197183465311876');

--3410246205 -pickticket

select rte_id,carton_nbr from carton_hdr where pkt_ctrl_nbr = '3410246205';

select rte_id,carton_nbr from carton_hdr where pkt_ctrl_nbr = '3413235488';

select rte_id from pkt_hdr where pkt_ctrl_nbr ='3413235488';

select case_nbr,stat_code from case_hdr where case_nbr in ('00007160417254108213','00007160419531332632','00006644543302680704');

select case_nbr,actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in ('00007160417254108213','00007160419531332632','00006644543302680704');

select * from alloc_invn_dtl where cntr_nbr in ('00007160417254108213','00007160419531332632','00006644543302680704');

select case_nbr,stat_code from case_hdr where case_nbr in ('00007160417254108213','00007160414105640038'); 

select case_nbr,actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in ('00007160417254108213','00007160414105640038'); 

select * from alloc_invn_dtl where cntr_nbr in ('00007160417254108213','00007160414105640038') and stat_code <'90'; 

select rte_id,carton_nbr from carton_hdr where pkt_ctrl_nbr = '3413235488';

select case_nbr,stat_code from case_hdr where case_nbr ='00006644543302680704';

select case_nbr,actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr='00006644543302680704';

select * from alloc_invn_dtl where cntr_nbr ='00006644543302680704' and stat_code<'90';


--183679,182806
select stat_code,shpmt_nbr from inpt_asn_hdr where shpmt_nbr in ('183679001','182806001');

select shpmt_nbr from inpt_asn_dtl where shpmt_nbr in ('183679001','182806001');

select stat_code,shpmt_nbr from asn_hdr where shpmt_nbr in ('183679001','182806001');

select shpmt_nbr from asn_dtl where shpmt_nbr in ('183679001','182806001');

select stat_code,shpmt_nbr from inpt_asn_hdr where shpmt_nbr ='182806001';

select shpmt_nbr from inpt_asn_dtl where shpmt_nbr='182806001';

select stat_code,shpmt_nbr from asn_hdr where shpmt_nbr ='182806001';

select shpmt_nbr from asn_dtl where shpmt_nbr ='182806001';
-------------------------------------------------------------

--Store Distro Input Bridge Failures
select distro_nbr, error_seq_nbr, proc_stat_code, stat_code from inpt_store_distro;
select * from msg_log where ref_value_1 in ('165120871','165120857','165120853','165120858','165120859','165120860','165120861','165120862','165120854','165120855','165120856','165120863','165120864','165120865','165120866','165120867','165120868','165120869','165120870');
select * from store_distro where distro_nbr in ('330143874050', '330143834347', '330143821100', '330143834346', '330143834342', '330143834345', '330143834343', '330143834344', '330143834349', '330143834350', '330143834348', '330143862750', '330143862749', '330143862748', '330143862746', '330143862747', '330143863050', '330143863049', '330143863048');