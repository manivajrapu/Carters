alter SESSION set current_schema =wmprod33;
---------Query to check unshipped cartons from shipped load:
select carton_nbr, pkt_ctrl_nbr, load_nbr, stat_code 
from carton_hdr 
where load_nbr in (select load_nbr from outbd_load where stat_code = '80') and stat_code < 90;

select * from cart