select voco_intrn_reverse_pallet_id, tc_lpn_id from lpn where wave_nbr='201606200053'  and voco_intrn_reverse_pallet_id in ('CORAL','ROYAL');

SELECT distinct(tc_order_id), tc_shipment_id from lpn where wave_nbr='201606200053';
SELECT distinct(lpn_facility_status), tc_shipment_id from lpn where wave_nbr='201606200053';

SELECT count(*) from lpn where wave_nbr='201606200053' and lpn_facility_status = '30'and voco_intrn_reverse_pallet_id in ('CORAL','ROYAL');

select * from shipment where tc_shipment_id in ('CS14825568','CS14825565','CS14762991','CS14817258'); -- CS14825568 carton both 20 and 30

select * from lpn where tc_shipment_id in ('CS14825568','CS14825565','CS14762991','CS14817258') and voco_intrn_reverse_pallet_id in ('CORAL','ROYAL');

select * from task_hdr where task_genrtn_ref_nbr='201606200053' and mhe_flag = 'Y'
select * from task_dtl where task_id in ('47526305','47526306','47526307','47526308','47526309','47526310','47526311','47526312','47526317','47526293') and stat_code = '90'