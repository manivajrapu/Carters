alter session SET Current_schema=DM;

select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;
--57148176
--970057148176, 970057148176

Select (l.tc_lpn_id) from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code in ('190795772128', '190795883985','190795982275','889802012325','190795830644')
and ld.batch_nbr = 'EC002'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';

select task_id, cntr_nbr, create_date_time, mod_date_time from task_dtl
where task_id ='68595098' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc;

--------------------------------------------------------------------------------------------------------------------------------------------------    

-------------------------------------------------------------------------------------------------------------------------------------------------
Select l.tc_lpn_id
from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code = '190795572537' and ld.batch_nbr = 'EC002'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';
--------------------------------------------------------------------------------------------------------------------------------------------------

select item_id from item_cbo where item_bar_code in ('190796063836', '190795039511');
select item_id,task_id, cntr_nbr, old_stat_code, new_stat_code,user_id, create_date_time, mod_date_time from prod_trkg_tran where item_id in ('2304695','2303379') and task_id='60216505';
select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl where task_id ='68269591' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc;
select * from task_dtl where task_id ='60216505' and stat_code = '40' and cntr_nbr is not null;
select * from task_dtl where task_id ='56196097' and stat_code = '40' and cntr_nbr is null;
select * from task_dtl where task_id ='55711291' and stat_code = '40' and cntr_nbr is null;

select * from lpn where tc_lpn_id ='EXC_091116_000006198';
select * from alloc_invn_dtl where cntr_nbr ='EXC_091116_000006198' and stat_code<'90';
select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status < 190 and lpn_facility_status = 90 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status < 80 );

-----Orphaned

select aid.cntr_nbr, im.item_name, im.item_bar_code, aid.batch_nbr, aid.carton_nbr, aid.qty_alloc, aid.mod_date_time
from alloc_invn_dtl aid, lpn l, orders o, item_cbo im where l.tc_lpn_id = aid.cntr_nbr and aid.tc_order_id = o.tc_order_id and aid.item_id = im.item_id 
            and aid.invn_need_type = 52 and aid.stat_code = 0
and l.lpn_facility_status <> 64 and o.order_type = 'EC';

select * from lpn where tc_lpn_id in ('970056174873');
select * from lpn_detail where lpn_id='57391095';
select * from task_hdr where task_id='55495451';
select * from task_dtl where task_id='55495451';
select distinct(cntr_nbr) from alloc_invn_dtl where item_id in ('2162949','2235422','2235455','2254705');
select * from lpn where wave_nbr='201611210027';


