select error_seq_nbr from inpt_xref where sku_brcd in ('000012516247','000012520428','000012526130','000012530199','000012524426','000012526321');

select * from item_master where sku_brcd in ('000012516247','000012520428','000012526130','000012530199','000012524426','000012526321');

select pkt_ctrl_nbr,error_seq_nbr from inpt_pkt_dtl where error_seq_nbr>0;

select * from inpt_pkt_dtl where pkt_ctrl_nbr in ('7000023892','7000024109','7000024110') and error_seq_nbr in ('10008984','10009896','10009897');

select * from item_master where style in ('120G082','239G155','239G155') and style_sfx in ('CO','PRT','PRT') and sec_dim in ('EC002','MEX01','MEX01') and size_desc in ('9M','18M','18M'); 

select * from item_master where style = '239G155' and style_sfx = 'PRT' and size_desc = '18M' and sec_dim = 'MEX01';


select stat_code,error_seq_nbr from inpt_bom_hdr where bom_id='1291109';

select * from msg_log where ref_value_1='10009925';

select * from inpt_bom_hdr where bom_id='1291109';

select * from inpt_bom_dtl where bom_id='1291109';

select * from bom_hdr where style='121G359' and style_sfx='DM' and sec_dim='INA01' and size_desc='24M';

select * from bom_hdr where bom_id='1291109';

select * from bom_dtl where bom_id='1291109';

desc bom_dtl;


