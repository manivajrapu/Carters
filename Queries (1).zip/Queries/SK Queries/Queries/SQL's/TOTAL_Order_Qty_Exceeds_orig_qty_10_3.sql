alter session SET Current_schema=DM;

with a as (
select o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr, min(oli.ref_field3) ORIG
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190 and oli.do_dtl_status < 190
group by o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr
),
b as (
select o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr, sum(order_qty) ORD
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190
group by o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr
)
select a.bill_to_name, a.tc_order_id, a.item_name, a.batch_nbr, a.orig, b.ord
from a, b
where a.tc_order_id = b.tc_order_id and a.item_id = b.item_id and a.batch_nbr = b.batch_nbr and b.ord > a.orig
order by 1;--1230877945--14681210 HE 9-12M

select o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.ref_field3, sum(orig_order_qty) ORIG_ORD, sum(order_qty) ORD_QTY, sum(allocated_qty) ALLOC_QTY, sum(units_pakd) UNITS_PAKD
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1230877945'
group by o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.ref_field3
having sum(order_qty) > oli.ref_Field3;--2588606--

select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty, allocated_qty, units_pakd, do_dtl_status
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1230877945' and oli.item_name ='14681210 HE 9-12M';

select qty_pulld,qty_alloc,stat_code,task_id from task_dtl where line_item_id='629862456' and item_id in ('2571054');--99
select qty_pulld,qty_alloc,stat_code,task_id from task_dtl where line_item_id='635503106' and item_id in ('2571054');--null
select qty_pulld,qty_alloc,stat_code,task_id from task_dtl where line_item_id='635503102' and item_id in ('2571054');--null
select qty_alloc,qty_pulld,stat_code from alloc_invn_dtl where  line_item_id='620422085';
select * from lpn_detail where lpn_detail_id='621604912';

select TASK_ID,TC_ORDER_ID,LINE_ITEM_ID,STAT_CODE,ORIG_REQMT,QTY_ALLOC,QTY_PULLD from DM.TASK_DTL where 
TC_ORDER_ID='1230540088' and LINE_ITEM_ID in ('623106711');--

select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty, allocated_qty, units_pakd, do_dtl_status
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1224708679' and oli.item_name ='337G260 PRT 12M';

select * from DM.TASK_DTL where LINE_ITEM_ID in('515399870');


select delivery_req,tc_order_id from orders where tc_order_id in ('BCAR36923397_1');
select * from sys_code where code_type='CCF';