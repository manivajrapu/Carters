alter session SET Current_schema=DM;
-------------------------------------------------------------------Alert-1---------------------------------------------------------------------------------------------
with a as (
select o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr, min(oli.ref_field3) ORIG
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190 and oli.do_dtl_status < 190
group by o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr
),
b as (
select o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr, sum(order_qty) ORD
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190
group by o.tc_order_id, oli.item_name, oli.item_id, oli.batch_nbr
)
select a.bill_to_name, a.tc_order_id, a.item_name, a.batch_nbr, a.orig, b.ord
from a, b
where a.tc_order_id = b.tc_order_id and a.item_id = b.item_id and a.batch_nbr = b.batch_nbr and b.ord > a.orig
order by 1;
--tc_order_id:1222702376,item_name:121H640 GY 18M
--tc_order_id:1222702376item_name:121H630 P 18M
----------------------------------------------------------------------------------------------------------------------------------------------------------------
select o.bill_to_name, oli.PARENT_LINE_ITEM_ID, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty,
allocated_qty, units_pakd, do_dtl_status, oli.batch_nbr from orders o, order_line_item oli
where o.order_id = oli.order_id and o.tc_order_id='1222702376' and oli.item_name='121H640 GY 18M';
