alter session set current_schema = DM;

select non_inventory_lpn_flag, lpn_facility_status,ship_via, lpn_id from lpn where tc_lpn_id='00000197181528825926';

select tc_order_id, manifest_nbr from lpn where tc_lpn_id in ('00000197181528825926');

Select * from dm.lpn_detail where lpn_id = '47254075';

with a as (select tc_lpn_id, sum(size_value) UNITS, (select count(*) from lpn where tc_reference_lpn_id = l.tc_lpn_id) CTNS
from lpn l, lpn_detail ld where l.lpn_id = ld.lpn_id and l.tc_lpn_id = '00000197181528825926'
group by tc_lpn_id)
select tc_lpn_id, UNITS "RETAIL_UNITS", CTNS "ECOM_CARTONS", UNITS+CTNS "TOTAL QTY"
from a;
