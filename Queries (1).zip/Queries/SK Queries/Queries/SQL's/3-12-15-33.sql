select *from asn_hdr;

select stat_code from asn_hdr where shpmt_nbr='330001852';

select *from case_hdr;

select stat_code from case_hdr where orig_shpmt_nbr='330001852';

select *from case_hdr where orig_shpmt_nbr='330001852';

select stat_code from outbd_stop where load_nbr='3300087145';

select * from outbd_stop where load_nbr='3300087145';

select * from outbd_load where load_nbr='3300087145';

select shpmt_nbr from outbd_load;

select load_nbr,shpmt_nbr,bol,master_bol,stat_code,count(*)
from carton_hdr
where load_nbr in (3300087145)
group by load_nbr,shpmt_nbr,bol,master_bol,stat_code;

Select ch.load_nbr,count(*)
From carton_hdr ch,
        carton_dtl cd
where ch.load_nbr='3300087145'
and cd.carton_nbr = ch.carton_nbr
and ch.stat_code = '90'
group by ch.load_nbr;

select *from outbd_stop;

select stat_code from outbd_load where load_nbr='3300086981';

select count(*) from carton_hdr where load_nbr='3300086981';

select stat_code from carton_hdr where load_nbr='3300086981';
select * from outbd_load where load_nbr='3300086981';


select stat_code from inpt_asn_hdr where shpmt_nbr='177084001';

select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
           --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;
  
