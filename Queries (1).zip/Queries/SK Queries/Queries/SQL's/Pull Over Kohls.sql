alter session SET Current_schema=DM;

select l.tc_order_id, o.order_id, o.order_status, o.do_status, l.tc_lpn_id, l.lpn_facility_status, l.tc_shipment_id, l.shipment_id, l.ship_via, 
o.ship_group_id, l.order_split_id, o.bill_to_name, o.acct_rcvbl_acct_nbr, l.created_dttm, l.voco_intrn_reverse_pallet_id
from dm.orders o, dm.lpn l where o.order_id = l.order_id and (o.ship_group_id = upper('FINDLAY 09/15') or 
o.ship_group_id = upper('FINDLAY 09/15') ) and l.lpn_facility_status < 50 and l.shipment_id is null order by 1;