alter session SET Current_schema=DM;
--------------------------------------------------------
select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,order_id,SHIP_VIA,
INBOUND_OUTBOUND_INDICATOR,TOTAL_LPN_QTY,last_updated_source,LAST_UPDATED_DTTM,SHIP_BY_DATE
from lpn where TC_LPN_ID in ('00000197181601286163');

select tc_lpn_id, stat_code from picking_short_item where tc_lpn_id = any ('00000197181601286200');
select * from orders where TC_ORDER_ID in ('RCAR10189337_1');

select tc_lpn_id, stat_code from picking_short_item where tc_lpn_id = any ('00000197181601286200');
select lpn_id, lpn_detail_status, size_value, initial_qty from lpn_detail where lpn_id in ('79949716');
select lpn_id, lpn_facility_status, total_lpn_qty from lpn where lpn_id = '79949716';
select do_dtl_status, units_pakd, order_qty, orig_order_qty, ref_field3, order_id from order_line_item where order_id = '51515121';

select do_status, order_id from orders where order_id = '51515121';

select lpn_id, lpn_detail_status, size_value, initial_qty,LPN_DETAIL_ID from lpn_detail where lpn_id in ('80237275');
select lpn_id, lpn_facility_status, total_lpn_qty from lpn where lpn_id = '80237275';
select do_dtl_status, units_pakd, order_qty, orig_order_qty, ref_field3, order_id, LINE_ITEM_ID from order_line_item where order_id = '51715461';
select lpn_id, lpn_detail_status, size_value, initial_qty,LPN_DETAIL_ID from lpn_detail where lpn_id in ('79949724');
select lpn_id, lpn_facility_status, total_lpn_qty from lpn where lpn_id = '79949724';
select do_dtl_status, units_pakd, order_qty, orig_order_qty, ref_field3, order_id,LINE_ITEM_ID from order_line_item where order_id = '51515143';
----------------------RCAR Order Support--------------------------------------------

select o.tc_order_id,oli.item_name, oli.ref_field3, oli.UNITS_PAKD, do_dtl_status
from orders o, DM.ORDER_LINE_ITEM oli WHERE o.ORDER_ID=oli.ORDER_ID and o.TC_ORDER_ID in ('RCAR10189338_1') and oli.DO_DTL_STATUS=150;