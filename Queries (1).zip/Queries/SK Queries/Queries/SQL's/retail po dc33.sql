alter session set current_schema=DM;

select po_nbr,pkt_ctrl_nbr, pkt_seq_nbr from pkt_dtl where wave_nbr='201704180001' and stat_code<90;

openallocations:
select sd.WHSE, 
       sd.DISTRO_NBR,
       sd.create_date_time,
       sd.SEQ_NBR, 
       sd.PO_NBR, 
       sd.store_nbr, 
       sc1.code_desc as STOREDISTROSTATUS, 
       sd.SHIP_WAVE_NBR, 
       sd.ORIG_REQ_QTY, 
       pd.PKT_CTRL_NBR, 
       pd.PKT_SEQ_NBR,
       sc2.code_desc as PICKTICKETDETAILSTATUS,
       im.STYLE, 
       im.STYLE_SFX as COLOR, 
       im.size_desc, 
       im.sec_dim as DIMCODE 
  from store_distro sd, pkt_dtl pd, item_master im, sys_code sc1, sys_code sc2 
 where sd.PO_NBR in ('10267796','10279647','10293673') -- Identify  PO Nbr(s) here
   and sc1.CODE_TYPE = '791'
   and sd.stat_code = sc1.code_id
   and sd.sku_id = im.SKU_ID
   and sd.PKT_CTRL_NBR = pd.PKT_CTRL_NBR
   and sd.PKT_SEQ_NBR = pd.PKT_SEQ_NBR
   and sc2.code_type = '808'
   and pd.stat_code = sc2.code_id
   and pd.STAT_CODE <> '90';

o/p:

select * from carton_hdr where pkt_ctrl_nbr in ('3400000090') and stat_code<90;---check the cartons which are less than 90.
select * from carton_hdr where pkt_ctrl_nbr in ('3400000090') and stat_code<90;

------------open task and open allocations----------
select * from alloc_invn_dtl where task_genrtn_ref_nbr='201704180001' and stat_code<90;
select * from task_dtl where task_genrtn_ref_nbr='201704180001' and stat_code<90;
