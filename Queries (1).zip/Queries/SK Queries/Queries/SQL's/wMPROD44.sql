select * from inpt_pkt_hdr where pkt_ctrl_nbr='7000023379';

select * from pkt_hdr where pkt_ctrl_nbr='7000023379';

select pkt_seq_nbr from inpt_pkt_dtl where pkt_ctrl_nbr='7000023379';

Select * from msg_log where ref_value_1=�9997927�;


select * from msg_log where ref_value_1 = '9997927';


select style,style_sfx,size_desc,sec_dim from inpt_pkt_dtl where error_seq_nbr > 0;