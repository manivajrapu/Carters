select * from inpt_xref where sku_brcd in ('000012516247','000012528189','000012527342','000012530335');

select * from item_master where sku_brcd in ('000012516247','000012528189','000012527342','000012530335'); 

select distinct(sku_brcd) from inpt_xref where error_seq_nbr>0;