alter session SET Current_schema=DM;

select td.task_id "Task ID",td.task_seq_nbr "Task Sequence", td.task_genrtn_ref_nbr "Wave Number", 
             td.invn_need_type "Need Type", lh.dsp_locn "Need Location", im.item_name "Need Item", td.qty_alloc "Qty Alloc", lh.locn_brcd, im.item_bar_code
from task_dtl td, wm_inventory wi, item_cbo im, locn_hdr lh
where td.pull_locn_id = wi.location_id(+)
and td.item_id = wi.item_id(+)
and td.pull_locn_id = lh.locn_id(+)
and td.item_id = im.item_id(+)
and (wi.location_id is null or wi.item_id is null)
and td.stat_code =0 and td.invn_need_type in (3,51)
and td.create_date_time > sysdate - 10;

select * from task_dtl where cntr_nbr in ('970100012372') and stat_code<'90';--88449935

select do_status from orders where tc_order_id in ('59720497');



--Fletcher Query
select * from task_dtl where task_id = '65287866' and TASK_SEQ_NBR not in (
select td.TASK_SEQ_NBR
from task_dtl td, item_cbo ic, locn_hdr lh, wm_inventory wi
where td.item_id = ic.item_id
and td.pull_LOCN_ID = lh.locn_id
and td.PULL_LOCN_ID = wi.location_id
and td.item_id = wi.item_id
and td.task_id = '65287866'
)
order by TASK_SEQ_NBR;

select td.task_id, td.cntr_nbr, td.invn_need_type, td.qty_alloc, td.stat_code, wi.tc_lpn_id, wi.wm_allocated_qty, on_hand_qty
from task_dtl td, wm_inventory wi where td.cntr_nbr = wi.tc_lpn_id (+) and td.stat_code < 90
and td.task_id in( 65287866                 
  ) and (wi.wm_allocated_qty = '0' or wi.wm_allocated_qty <> td.qty_alloc) --and wm_allocated_qty != on_hand_qty
order by task_id;



select stat_code FROM task_hdr where task_id in ('970900693523') and stat_code<'90';
select * FROM task_dtl where task_id in ('63907372') and stat_code<'90';

select tc_lpn_id,lpn_facility_status from lpn where tc_lpn_id in ('970100000261');




select * from lpn where tc_lpn_id in ('00000197181703856622');
select * from picking_short_item where tc_lpn_id in ('00000197181703856622') and stat_code <90;
select * from task_dtl where carton_nbr in ('00000197181703856622') and stat_code <90;--
select item_id,alloc_invn_dtl_id, stat_code, cntr_nbr, carton_nbr, invn_need_type from alloc_invn_dtl where carton_nbr in ('00000197181703856622') and stat_code <90;
select * from lpn_lock where tc_lpn_id in ('00000197181703856622');