alter session set current_schema = DM;

select tc_lpn_id, lpn_facility_status from lpn where tc_order_id = 'CAR22056881_1';
select do_status,order_type from orders where tc_order_id = 'CAR22056881_1'; 
select order_id, line_item_id,allocated_qty,order_qty,orig_order_qty,units_pakd,item_id,item_name from order_line_item where order_id = '37129938';
select * from lpn_detail where lpn_id = '56652367';

select tc_lpn_id, on_hand_qty, wm_allocated_qty from wm_inventory where lpn_detail_id in ('551117634','551117643');

select * from orders where BILL_TO_NAME = 'Rebecca Buffington' and BILL_TO_ADDRESS_1 = '800 Rittenhouse Dr' and BILL_TO_CITY = 'Reading' and BILL_TO_STATE_PROV = 'PA'
and BILL_TO_POSTAL_CODE = '19606' order by ORDER_DATE_DTTM desc;