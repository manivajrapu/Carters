select * from trans_invn;

--delete from trans_invn where trans_invn_type='10' and sku_id='115551934';
commit;
rollback;