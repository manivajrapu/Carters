alter session SET Current_schema=DM;

select im.item_name,im.item_id, batch_nbr,im.item_bar_code, nvl(start_invn,0) "605_YEST", nvl(pix_invn,0) PIX_INVN, nvl(crtn_invn,0) CRTN_INVN, nvl(end_invn,0) "605_TODAY",
    nvl(start_invn,0)+nvl(pix_invn,0)-nvl(crtn_invn,0)-nvl(end_invn,0) VAR, RUN_DATE, ADJ_CHECK_VAR
from MA_tmp_gen605_compare m, item_cbo im where m.item_id = im.item_id and trunc(run_date) = trunc(sysdate);

select pt.tran_type, pt.tran_code,pt.ACTN_CODE,pt.rsn_code,pt.REF_FIELD_1,im.ITEM_ID, im.item_name, pt.batch_nbr, pt.case_nbr, pt.invn_adjmt_qty, 
pt.invn_adjmt_type,pt.create_date_time from pix_tran pt, item_cbo im 
where im.item_id = pt.item_id and im.item_name = '118H951 HE 6M' and pt.create_date_time > sysdate - 2 
and pt.tran_type not in (620) order by pt.create_date_time desc;

select tran_type,tran_code,tran_nbr,CNTR_NBR,NBR_UNITS,REF_FIELD_1,OLD_STAT_CODE,NEW_STAT_CODE,MODULE_NAME,MENU_OPTN_NAME,CREATE_DATE_TIME,MOD_DATE_TIME 
from DM.PROD_TRKG_TRAN 
where item_id = '2400459'-- and tran_nbr = '272102861';--and cntr_nbr='00000156740032786357' 
order by create_date_time desc;  

select * from lpn where tc_lpn_id='00000156740031548413';
---------------------------------------------------------------------------------------------------------------------------------------------
select item_id from item_cbo where item_name = '126G364 HE 6M';
select * from lpn_lock where tc_lpn_id='00006644549833053598';
select * from lpn_lock where tc_lpn_id ='00006644549833053833';

select pt.tran_type, pt.tran_code,pt.ACTN_CODE,pt.rsn_code,pt.REF_FIELD_1, im.item_name, pt.batch_nbr, pt.case_nbr, pt.invn_adjmt_qty, pt.invn_adjmt_type, 
pt.create_date_time from pix_tran pt, item_cbo im where im.item_id = pt.item_id and im.item_name = '21468610 GY 3T' and 
pt.create_date_time > sysdate - 2 and pt.tran_type not in (620) and batch_nbr = 'DFLT'
order by pt.create_date_time desc;

select item_id from item_cbo where item_name = '21468610 GY 3T';


select tran_type,tran_code,tran_nbr,CNTR_NBR,NBR_UNITS,REF_FIELD_1,OLD_STAT_CODE,NEW_STAT_CODE,MODULE_NAME,MENU_OPTN_NAME,CREATE_DATE_TIME,MOD_DATE_TIME from DM.PROD_TRKG_TRAN 
where item_id = '2240905' and cntr_nbr = '00007160410733492261' order by create_date_time desc;

select pt.tran_type, pt.tran_code,pt.ACTN_CODE,pt.rsn_code,pt.REF_FIELD_1, im.item_name, pt.batch_nbr, pt.case_nbr, pt.invn_adjmt_qty, pt.invn_adjmt_type, 
pt.create_date_time from pix_tran pt, item_cbo im where im.item_id = pt.item_id and im.item_name = '225G623 HE 6M' and 
pt.create_date_time > sysdate - 2 and pt.tran_type not in (620) and batch_nbr = 'EC002'
order by pt.create_date_time desc;

select item_id from item_cbo where item_name = '225G623 HE 6M';

select tran_type,tran_code,tran_nbr,CNTR_NBR,NBR_UNITS,REF_FIELD_1,OLD_STAT_CODE,NEW_STAT_CODE,MODULE_NAME,MENU_OPTN_NAME,CREATE_DATE_TIME,MOD_DATE_TIME from DM.PROD_TRKG_TRAN 
where item_id = '2230795' and cntr_nbr = '00006644540240102800' order by create_date_time desc;

select * from prod_trkg_tran where item_id='2196420';

select inventory_lock_code from lpn_lock where tc_lpn_id in ('00007160410733492261')


select pt.actn_code,pt.* from pix_tran pt where ITEM_ID = '2135475' and batch_nbr = 'DFLT' and create_date_time > sysdate - 2  order by create_date_time desc;

select pt.actn_code,pt.* from pix_tran pt where ITEM_ID = '2162945' and create_date_time > sysdate - 2  order by create_date_time desc;

--
SELECT item_id from dm.item_cbo where item_name='118G396 Y NB';

select * from MA_tmp_gen605_compare where item_id='2054255';  --651557600 652272701

select * from tran_master  where tran_type='605';-- order by create_date_time desc

select * from tran_log_message

select * from prod_trkg_tran where tran_nbr ='651557600'

order by mod_date_time desc;                       --where create_date_time='04-MAY-2016'Wednesday, May 4, 2016 01:30:00 PM'; desc where tran_nbr  in ('651557600','649878412','652272701')

select * from pix_tran where tran_nbr='651557600' and item_id='2054255' and item_name='121D555 N 6M' and tran_type ='605' and ref_field_10='888510752875' and batch_nbr='EC002' order by mod_date_time desc;  888510752875
-- 652272701

select * from pix_tran where tran_nbr='651557600' and item_id ='2054255';
select tran_type, tran_code, actn_code, tran_nbr, invn_adjmt_qty, invn_adjmt_type, invn_type,create_date_time, mod_date_time from pix_tran where item_id='2162945' order by create_date_time desc


select tran_type, tran_code, actn_code, tran_nbr, proc_stat_code, case_nbr, item_id, batch_nbr, invn_adjmt_qty, invn_adjmt_type, create_date_time, mod_date_time from dm.pix_tran where item_id = '2157889' and batch_nbr = 'EC002' and tran_type not in ('620') order by create_date_time desc;

select * from DM.PROD_TRKG_TRAN where cntr_nbr = '00000156740022379859' and item_id = '2157889' order by create_date_time desc;

select pt.tran_type, pt.tran_code,pt.ACTN_CODE,pt.rsn_code,pt.REF_FIELD_1, im.item_name, pt.batch_nbr, pt.case_nbr, pt.invn_adjmt_qty, pt.invn_adjmt_type, pt.create_date_time
from pix_tran pt, item_cbo im where im.item_id = pt.item_id and im.item_name = '118G396 Y NB' and pt.create_date_time > sysdate - 2 and pt.tran_type not in (620) and batch_nbr = 'FP002'
order by pt.create_date_time desc;



select * from dm.outpt_orders where batch_ctrl_nbr = '120612500';

Select * from dm.outpt_order_line_item where batch_ctrl_nbr = '120612500';

select tran_type,tran_code,tran_nbr,CNTR_NBR,NBR_UNITS,REF_FIELD_1,OLD_STAT_CODE,NEW_STAT_CODE,MODULE_NAME,MENU_OPTN_NAME,CREATE_DATE_TIME,MOD_DATE_TIME from DM.PROD_TRKG_TRAN 
where item_id = '2157889' and cntr_nbr = '00000156740023241179' order by create_date_time desc;


select * from lpn where manifest_nbr='UPS000009648';
select * from purchase_orders where purchase_orders_id in ('10620641','10515095','10521485','10605389','10757719','10640384');
select * from orders where ext_purchase_order in ('10620641','10515095','10521485','10605389','10757719','10640384');

select * from outpt_lpn_detail where batch_nbr='ECOM';
select * from outpt_orders;



----

select level_1, level_2, level_3, level_4,level_5, a.name job_function_name, a.description job_function_description, c.name ACT_NAME, c.description ACT_DESCRIPTION, d.description labor_type_code, b.wm_Req_aprv WM_EVENT_APPROVAL,
B.LM_KIOSK_REQ_APRV LM_KIOSK_EVENT_APPROVAL, B.LM_MAN_EVNT_REQ_APRV LM_MANUAL_EVENT_APPROVAL, e.vhcl_type vehicle, e.description vehicle_description
from e_job_function a
left join e_Act b on
a.job_func_id = b.job_func_id
left join labor_activity c on
b.labor_Activity_id = c.labor_activity_id
left join e_labor_type_code d on
d.labor_type_id = b.labor_type_id
left join e_vhcl e on
b.vhcl_type_id = e.vhcl_type_id
order by 8;



----
select allocatable from wm_inventory where tc_lpn_id in ('00000197181703274532') and wm_inventory_id in ('6330802');

update wm_inventory set allocatable='Y' where tc_lpn_id in ('00000197181703274532') and wm_inventory_id in ('6330802');
