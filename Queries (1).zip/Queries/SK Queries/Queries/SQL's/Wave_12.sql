alter session SET Current_schema=DM;

select * from ship_wave_parm where ship_wave_nbr='201611150007';
select * from item_cbo where item_name='118G920 N 24M';
select allocated_qty,order_qty, orig_order_qty, units_pakd, item_id, item_name from order_line_item where item_id='2282223' and ship_wave_nbr='201611150007';
select distinct(to_be_filled_qty) from wm_inventory where item_id='2282223';
select * from wm_inventory where item_id='2282223' and location_id in ('0099339','0001992');
select * from wm_inventory where location_id in ('0099339','0001992');
select * from alloc_invn_dtl where task_genrtn_ref_nbr='201611150007' and item_id='2282223';
select * from task_dtl where task_genrtn_ref_nbr='201611150007' and item_id='2282223';
select * from task_hdr where task_id in ('55141430','55141301','55141453','55141394','55141430','55295263');
select * from locn_hdr where locn_id in ('0099339','0001992');
select * from lpn where wave_nbr='201611150007' and lpn_facility_status<'20';
select * from lpn_detail where lpn_id='56905539';
select distinct(item_id), on_hand_qty from wm_inventory where tc_lpn_id in ('00000197181489399092', '00000197181489401887', '00000197181489404987', '00000197181489400651', '00000197181489405281', '00000197181489405069', '00000197181489405328') and on_hand_qty='0';
select allocated_qty,order_qty, orig_order_qty, units_pakd, item_id, item_name from order_line_item where item_id in ('2282469','2282393','2279190','2279231','2279187','2279188','2279189','2279233','2282391','2282468') and units_pakd is null;
select * from lpn where tc_lpn_id='00000197181490548533';

select * from pkt_hdr ;