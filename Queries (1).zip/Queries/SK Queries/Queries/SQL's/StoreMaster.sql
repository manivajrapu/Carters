select * from inpt_store_master where store_nbr in ('0003','0178','0219','0244','0410','0434','0459','0484','0544','0580','0644','0687','0755','0811','0835','0859','0911','0935','0995','1021','1044','1091','1121','2064');

select DISTINCT(store_nbr) from store_master where store_nbr in ('0003','0178','0219','0244','0410','0434','0459','0484','0544','0580','0644','0687','0755','0811','0835','0859','0911','0935','0995','1021','1044','1091','1121','2064');

select * from inpt_store_master;

select * from store_master;

select error_seq_nbr from inpt_store_master;

select * from msg_log where ref_value_1='150971915';



select error_seq_nbr,porc_stat_code from inpt_store_master;