alter session SET Current_schema=DM;

select tc_lpn_id, lpn_facility_status, tc_order_id, total_lpn_qty,lpn_id from lpn where tc_lpn_id='00000197181488109685';
select * from lpn where tc_order_id='CAR22063447_1';
select order_id, do_status,order_type from orders where tc_order_id='CAR22063447_1';
select order_id, line_item_id, allocated_qty,order_qty, orig_order_qty, units_pakd, item_id,item_name from order_line_item where order_id='37153177';
select * from picking_short_item where tc_lpn_id='00000197181488109685';
select * from lpn_lock where tc_lpn_id='00000197181488109685';
select * from lpn_detail where lpn_id='56692795'; --2241321,31464811 PL 6
select * from item_cbo where item_id='2241321';
select tc_lpn_id, item_id,on_hand_qty, wm_allocated_qty from wm_inventory where tc_lpn_id='00000197181488109685' and item_id='2241321';