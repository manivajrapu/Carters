select * from item_cbo where item_name='B216A980 AST 8';

select * from lpn where manifest_nbr='UPS000009725';

select do_status from orders where tc_order_id='CAR19031746_1';

select do_status from orders where tc_order_id='ICAR19029188_1';

select * from alloc_invn_dtl where tc_order_id='CAR19031746_1' and stat_code<'90';

select * from alloc_invn_dtl where tc_order_id='ICAR19029188_1' and stat_code<'90';

select * from lpn where tc_lpn_id='00000197181435523342';

select * from lpn_detail where lpn_detail_id='45709349';

select * from task_dtl where tc_order_id='CAR19031746_1' and stat_code<'90';

select * from task_dtl where tc_order_id='ICAR19029188_1' and stat_code<'90';


select * from task_hdr where task_genrtn_ref_nbr='201605290033' and stat_code<'90';

