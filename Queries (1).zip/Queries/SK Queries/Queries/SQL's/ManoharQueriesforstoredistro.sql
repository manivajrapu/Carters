select * from item_master where style='251A472' and style_sfx='DM' and size_desc='3T';

--1.Query to check in store_distro table with  distro_nbr='330119550581' and found the variation in the required quantity and allocated quantity.

select pkt_ctrl_nbr,distro_nbr,invn_type,stat_code,sku_id,po_nbr,reqd_qty,ORIG_REQ_QTY,alloc_qty,case_nbr,wave_nbr,ship_wave_nbr,wave_alloc_qty
from store_distro where  pkt_ctrl_nbr='3331558636';distro_nbr='330110446311';--stat_code=30;

desc store_distro

--2. Checked in the pick ticket details for original order quantity, packed quantity ,units packed.

select stat_code,PKT_SEQ_NBR,sku_id,pkt_ctrl_nbr,orig_ord_qty,orig_pkt_qty,pkt_qty,to_be_verf_as_pakd,verf_as_pakd,units_pakd,std_bundl_qty ,user_id
from pkt_dtl where orig_ord_qty > pkt_qty and orig_ord_qty= orig_pkt_qty;

pkt_ctrl_nbr='3410647162' and sku_id='115474750' and pkt_seq_nbr='747';

select stat_code from pkt_hdr_intrnl where pkt_ctrl_nbr='3410647162';


pkt#3331558636


select * from sku_invn;

select * from pix_tran where tran_type='620' and tran_code='03';

TRAN_TYPE,TRAN_CODE,TRAN_NBR,PIX_SEQ_NBR,PROC_STAT_CODE,,CASE_NBR,SKU_ID,STYLE,STYLE_SFX,

desc pix_tran;

rollback;


update pkt_dtl 
set orig_ord_qty='1', 
 mod_date_time=sysdate
 where pkt_ctrl_nbr='3410647162' and pkt_seq_nbr='747';
 
update store_distro 
set reqd_qty='1', 
ORIG_REQ_QTY='1',
stat_code='90',

mod_date_time=sysdate
 where distro_nbr='330110446311';
 
 commit;

 
 commit;


desc pkt_dtl


select * from pkt_hdr where pkt_ctrl_nbr in ('7000022254','7000023471','7000023362','7000024128');

select * from carton_hdr where PKT_CTRL_NBR='7000023471';

select * from inpt_pkt_hdr where pkt_ctrl_nbr in ('7000022254','7000024128');

select distinct pkt_ctrl_nbr from inpt_pkt_dtl where pkt_ctrl_nbr in ('7000022254','7000024128');

select * from INPT_PKT_INSTR where pkt_ctrl_nbr in ('7000022254','7000024128');
