00006644549973177888 174603001

select * from inpt_asn_hdr where shpmt_nbr='174603001';

select * from asn_hdr where shpmt_nbr='174603001';

select * from inpt_case_hdr where orig_shpmt_nbr='174603001' and case_nbr='00006644549973177888';

select * from case_hdr where case_nbr='00006644549973177888';

select* from asn_hdr;

select * from appt_sched;




select * from inpt_xref where sku_brcd in ('000012529087','000012527892','000012527250','000012529780');

select * from item_master where sku_brcd in ('000012529087','000012527892','000012527250','000012529780'); 

select * from inpt_pkt_dtl where pkt_ctrl_nbr='7000023892' and error_seq_nbr='10006178';

select * from msg_log where ref_value_1='10006178';

select * from item_master where style='120G082' and sec_dim='EC002' and size_desc='9M' and style_sfx='CO';



