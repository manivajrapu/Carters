alter session set current_schema = DM;

select aid.cntr_nbr, im.item_name, im.item_bar_code, aid.batch_nbr, aid.carton_nbr, aid.qty_alloc, aid.mod_date_time
from alloc_invn_dtl aid, lpn l, orders o, item_cbo im where l.tc_lpn_id = aid.cntr_nbr and aid.tc_order_id = o.tc_order_id and aid.item_id = im.item_id 
            and aid.invn_need_type = 52 and aid.stat_code = 0
and l.lpn_facility_status <> 64 and o.order_type = 'EC';