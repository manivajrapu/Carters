select error_seq_nbr from inpt_xref where sku_brcd in ('000012516247','000012520428','000012526130','000012530199','000012524426','000012526321');

select * from msg_log where ref_value_1='140541436';

select * from item_master where sku_brcd in ('000012516247','000012520428','000012526130','000012530199','000012524426','000012526321');


000012516247

select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
             --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;
            
            
            
            
            
            
            
           Load nbr- #3300089084 New Store #2024
           
select stat_code,load_nbr from outbd_load where load_nbr='3300089084';
    
select phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,
ph.plan_bol, ph.plan_master_bol,count(*)
from pkt_hdr ph,
pkt_hdr_intrnl phi
where ph.pkt_ctrl_nbr in (select distinct ch.pkt_ctrl_nbr
from carton_hdr ch
where load_nbr='3300089084' 
and ((stat_code < '90') or
(stat_code = '99')))
and ph.plan_load_nbr='3300089084'
and phi.pkt_ctrl_nbr = ph.pkt_ctrl_nbr
group by phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,ph.plan_bol, ph.plan_master_bol;


Select load_nbr,stat_code,carton_nbr,shpmt_nbr,bol,master_bol,user_id,mod_date_time from  carton_hdr ch
where load_nbr='3300089084' and stat_code < '90';


select * from carton_hdr where carton_nbr='00000197183462195929';


select stat_code,case_nbr from case_hdr where case_nbr in ('00006644549910051530','00006644549910051691','00006644549910051707','00006644549910051721','00006644549910051820','00006644549910051851','00006644549910051905','00006644549910051936'); 

