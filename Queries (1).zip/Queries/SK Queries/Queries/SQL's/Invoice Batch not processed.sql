alter session SET Current_schema=DM;

---Alert Query : (STEP 1)
select invc_batch_nbr, count(*) ORDERS from dm.outpt_orders where proc_stat_code < 90 and created_dttm < sysdate - 1/24 group by invc_batch_nbr;
---

---To check faulty order ID: (STEP 2)
select tc_order_id, oo.LAST_UPDATED_SOURCE from outpt_orders oo where invc_batch_nbr = '121137193' 
and not exists (select 1 from outpt_order_line_item oli where oo.invc_batch_nbr = oli.invc_batch_nbr and oo.tc_order_id = oli.tc_order_id); 
---

---Check the 4 tables for appropriate conditions in SOP:(Use the invoice nbr & order nbr from step 1 & 2 respectively below):
select * from outpt_orders where tc_order_id='CAR34101374_1' and batch_ctrl_nbr='121137193';
select * from DM.OUTPT_ORDER_LINE_ITEM where tc_order_id='CAR34101374_1' and invc_batch_nbr='121137193'; 
select * from outpt_lpn where tc_order_id='CAR34101374_1' and invc_batch_nbr='121137193';
select * from outpt_lpn_detail where minor_po_nbr='CAR34101374_1' and invc_batch_nbr='121137193';


