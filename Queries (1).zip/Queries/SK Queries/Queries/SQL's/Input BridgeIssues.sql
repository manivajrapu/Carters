

----Item cross reference input bridge
select * from inpt_xref where sku_brcd in ('000012516247','000012528189','000012529520','000012529469');

select msg from msg_log where ref_value_1 in ('10016283', '10016294', '10016311', '10016359');

select * from item_master where sku_brcd in ('000012516247','000012528189','000012529520','000012529469'); 

-----BOM Input Bridge
1289302,1289555,1291109
select * from inpt_bom_hdr where bom_id='1291109';
select * from inpt_bom_dtl where bom_id='1289555';

select * from bom_dtl where bom_id='1289555';
select * from bom_hdr where bom_id='1291109';

select * from item_master where sku_id='117270989';



select * from inpt_asn_hdr;

select * from asn_hdr where shpmt_nbr='174603001';

select * from case_hdr where orig_shpmt_nbr='174603001' and case_nbr='00006644549973177888';

select * from case_hdr where case_nbr='00006644549973177888';

select * from case_hdr where orig_shpmt_nbr='177921004';

select * from case_hdr where case_nbr='00006644549943228473';

select * from inpt_store_master where error_seq_nbr='179165278';

select distinct error_seq_nbr,PROC_STAT_CODE from inpt_store_master;

--update inpt_store_master set PROC_STAT_CODE='0' , error_seq_nbr = '0';
--commit;

select msg from msg_log where ref_value_1='179165278';

select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
           --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;


