select * from inpt_pkt_dtl where pkt_ctrl_nbr='7000024110' and error_seq_nbr>0;

select * from msg_log where ref_value_1='10009928';

select * from item_master where style='239G155' and style_sfx='PRT' and size_desc='18M' and sec_dim='MEX01';


select * from inpt_xref where sku_brcd in ('000012516247','000012526819','000012527069','000012524624','000012525744');

select * from item_master where sku_brcd in ('000012516247','000012526819','000012527069','000012524624','000012525744');

select * from inpt_bom_hdr where bom_id='1291109';

select * from inpt_bom_dtl where bom_id='1291109';

select * from bom_hdr where bom_id='1291109';

select * from bom_dtl where bom_id='1291109';


select * from pkt_dtl where pkt_ctrl_nbr in ('4500001772','4500001770','4500001762','4500001771','4500001767','4500001764','4500001766','4500001769','4500001763','4500001765','4500001768','4500001761');

select * from pkt_hdr where pkt_ctrl_nbr in ('4500001772','4500001770','4500001762','4500001771','4500001767','4500001764','4500001766','4500001769','4500001763','4500001765','4500001768','4500001761');
desc pkt_hdr;


'4500001770','4500001762','4500001771','4500001767','4500001764','4500001766','4500001769','4500001763','4500001765','4500001768','4500001761' 

select stat_code from inpt_pkt_hdr; where pkt_ctrl_nbr='7000023471';

select * from pkt_hdr_intrnl where pkt_ctrl_nbr='7000023471';

select * from pkt_hdr where pkt_ctrl_nbr='7000023471';


------------------------------

select * from trans_invn;
