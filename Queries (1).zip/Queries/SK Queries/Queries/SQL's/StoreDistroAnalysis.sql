select pkt_ctrl_nbr,distro_nbr,invn_type,stat_code,sku_id,po_nbr,reqd_qty,ORIG_REQ_QTY,alloc_qty,case_nbr,wave_nbr,ship_wave_nbr,wave_alloc_qty
from store_distro where  pkt_ctrl_nbr='3331558636';

select stat_code,PKT_SEQ_NBR,sku_id,pkt_ctrl_nbr,orig_ord_qty,orig_pkt_qty,pkt_qty,to_be_verf_as_pakd,verf_as_pakd,units_pakd,std_bundl_qty ,user_id
from pkt_dtl where orig_ord_qty > pkt_qty and orig_ord_qty= orig_pkt_qty;



select sku_id,pkt_ctrl_nbr,pkt_seq_nbr,ds.distro_nbr,ds.invn_type,ds.stat_code as store_distro_stat_code,ds.po_nbr,ds.reqd_qty,
ds.ORIG_REQ_QTY,ds.alloc_qty,ds.case_nbr,ds.wave_nbr,ds.ship_wave_nbr,ds.wave_alloc_qty,pk.stat_code as pkt_stat_code,pk.orig_ord_qty,
pk.orig_pkt_qty,pk.pkt_qty,pk.to_be_verf_as_pakd,pk.verf_as_pakd,units_pakd,pk.std_bundl_qty,pk.user_id
from store_distro ds join pkt_dtl pk
where pkt_ctrl_nbr='3331558636'; and  pk.orig_ord_qty > pk.pkt_qty and pk.orig_ord_qty= pk.orig_pkt_qty;

select sku_id,pkt_ctrl_nbr,pkt_seq_nbr from store_distro ds,pkt_dtl pk
where pkt_ctrl_nbr='3331558636';



select pkt_ctrl_nbr,distro_nbr,invn_type,stat_code,sku_id,po_nbr,reqd_qty,ORIG_REQ_QTY,alloc_qty,case_nbr,wave_nbr,ship_wave_nbr,wave_alloc_qty
from store_distro where pkt_ctrl_nbr='3411108254' and sku_id='115617038'; --and stat_code ='30'
--sku id-115617038
--distro nbr-330110954315

select stat_code,PKT_SEQ_NBR,sku_id,pkt_ctrl_nbr,orig_ord_qty,orig_pkt_qty,pkt_qty,to_be_verf_as_pakd,verf_as_pakd,units_pakd,std_bundl_qty ,user_id
from pkt_dtl where sku_id='115617038' and pkt_seq_nbr='279';

update pkt_dtl 
set orig_ord_qty='24', 
 mod_date_time=sysdate
 where pkt_ctrl_nbr='3411108254' and pkt_seq_nbr='279';
 
update store_distro 
set reqd_qty='39', 
ORIG_REQ_QTY='39',
stat_code='90',
mod_date_time=sysdate
 where distro_nbr='330111003188';
 
 commit;
 
 select style,style_sfx,size_desc from item_master where sku_id='115617038';


--exp2

select pkt_ctrl_nbr,distro_nbr,invn_type,stat_code,sku_id,po_nbr,reqd_qty,ORIG_REQ_QTY,alloc_qty,case_nbr,wave_nbr,ship_wave_nbr,wave_alloc_qty
from store_distro where pkt_ctrl_nbr='3411114257' and sku_id='115580143';

select stat_code,PKT_SEQ_NBR,sku_id,pkt_ctrl_nbr,orig_ord_qty,orig_pkt_qty,pkt_qty,to_be_verf_as_pakd,verf_as_pakd,units_pakd,std_bundl_qty ,user_id
from pkt_dtl where sku_id='115580143' and pkt_seq_nbr='47';

update pkt_dtl 
set orig_ord_qty='39', 
 mod_date_time=sysdate
 where pkt_ctrl_nbr='3411114257' and pkt_seq_nbr='47';



