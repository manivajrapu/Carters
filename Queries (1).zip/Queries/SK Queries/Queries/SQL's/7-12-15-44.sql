select * from inpt_xref; where sku_brcd in ('000012527670','000012520213','000012523979','000012524754','000012525805');

select * from item_master where 

select unique(sku_brcd) from inpt_xref where error_seq_nbr>0 order by sku_brcd asc;

select * from msg_log where ref_value_1='10008154';

select * from item_master where sku_brcd in ('000012527670','000012520213','000012523979','000012524754','000012525805');


select stat_code,error_seq_nbr from inpt_asn_hdr where shpmt_nbr='177254001';

select * from msg_log where ref_value_1='10008983';

select stat_code from asn_hdr where shpmt_nbr='177254001';