alter session SET Current_schema=DM;

select im.item_name, im.item_bar_code, nvl(start_invn,0) "605_YEST", nvl(pix_invn,0) PIX_INVN, nvl(crtn_invn,0) CRTN_INVN, nvl(end_invn,0) "605_TODAY",
    nvl(start_invn,0)+nvl(pix_invn,0)-nvl(crtn_invn,0)-nvl(end_invn,0) VAR, RUN_DATE, ADJ_CHECK_VAR
from MA_tmp_gen605_compare m, item_cbo im where m.item_id = im.item_id and trunc(run_date) = trunc(sysdate);


select pt.tran_type, pt.tran_code,pt.ACTN_CODE,pt.rsn_code,pt.REF_FIELD_1, im.item_name, pt.batch_nbr, pt.case_nbr, pt.invn_adjmt_qty, pt.invn_adjmt_type, pt.create_date_time
from pix_tran pt, item_cbo im where im.item_id = pt.item_id and im.item_name = '331G174 PRT 18M' and pt.create_date_time > sysdate - 2 and pt.tran_type not in (620) and batch_nbr ='DFLT' order by pt.create_date_time desc;

select item_id from item_cbo where item_name='331G174 PRT 18M';
select * from lpn_lock where tc_lpn_id='00000156740026735286';

select tran_type,tran_code,tran_nbr,CNTR_NBR,NBR_UNITS,REF_FIELD_1,OLD_STAT_CODE,NEW_STAT_CODE,MODULE_NAME,MENU_OPTN_NAME,CREATE_DATE_TIME,MOD_DATE_TIME from DM.PROD_TRKG_TRAN 
where item_id = '2198746' and cntr_nbr='00000156740026735286' order by create_date_time desc;

