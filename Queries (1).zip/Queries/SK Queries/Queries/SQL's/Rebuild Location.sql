alter session SET Current_schema=DM;

--GET THE LOCATION_CLASS & LOCATION_ID FROM BELOW QUERY
select * from locn_hdr where dsp_locn in('PE19903A11');  --1 POSR01333 POSR04213

--PUT THE OBTAINED LOCATION_ID FROM ABOVE QUERY IN THE BELOW QUERY
select to_be_filled_qty, on_hand_qty, wm_allocated_qty from wm_inventory where location_id = '106010210';--'TBFQ' GOES TO 0

SELECT SUM(to_be_filled_qty) from wm_inventory where location_id = '106010210';   --1,3

SELECT sum(qty_alloc) from task_dtl where PULL_LOCN_ID='247195626' and STAT_CODE<90;  --2

select on_hand_qty,wm_allocated_qty,LAST_UPDATED_SOURCE from wm_inventory where location_id = '117077937';-- and location_dtl_id = '29232576' and item_id = '2411941';
--open allocation
select * from alloc_invn_dtl where pull_locn_id in ('443036759') and stat_code<90;

---open task
select * from task_dtl where pull_locn_id in ('117077937') and stat_code<90;


SELECT LAST_UPDATED_SOURCE from wm_inventory where location_id = '100369569';

select * from DM.WM_INVENTORY where location_id = '100408570' and location_dtl_id = '29232576' and item_id = '2411941';

select * from task_dtl where pull_locn_id in ('106010210') and stat_code<90;   --if open task or open allocation   --3

-- open task 0004524 0004534 0004539 0004544 0004545 0004558 0004580 0004581 0004584 0004585 0004588 0004591 0004595 0004600 0004605 0004613 0004615 0004818 0004836

select * from alloc_invn_dtl where pull_locn_id in ('106010210') and stat_code<90;   --inform user   --4

select * from task_dtl where dsp_locn in ('100369569');
select * from dm.task_dtl where TASK_GENRTN_REF_NBR = '201608150110' and stat_code < 90;

Select * from dm.alloc_invn_dtl where TASK_GENRTN_REF_NBR = '201608150110' and stat_code < 90;


select to_be_filled_qty,on_hand_qty, wm_allocated_qty from wm_inventory where location_id='0009167' and item_id='2282230';
select * from item_cbo where item_name='118H111 N 18M';

select * from locn_hdr where dsp_locn='PDF0336A02';
select * from pick_locn_dtl where first_wave_nbr='201612050077' and pikng_lock_code='AB';
select to_be_filled_qty, on_hand_qty, wm_allocated_qty from wm_inventory where location_id='100338696';

select * from locn_hdr where dsp_locn='PDF0336B01';
select * from pick_locn_dtl where first_wave_nbr='201612050077' and pikng_lock_code='AB';
select to_be_filled_qty, on_hand_qty, wm_allocated_qty from wm_inventory where location_id='100338700';

select * from task_hdr where locn_hdr_id='620497540';

select * from task_dtl where pull_locn_id='620497540';

select * from alloc_invn_dtl where task_genrtn_ref_nbr='201612050077' and cntr_nbr='970054784678';
select * from task_dtl where task_id='54784678';

select * from pick_locn_hdr;

select distinct(batch_nbr) from task_dtl where task_id='54869657';
select * from alloc_invn_dtl where cntr_nbr='970054869657';

select tc_lpn_id, lpn_facility_status from lpn where tc_lpn_id in ('00006644549887614196','00007160419047003903');
select * from alloc_invn_dtl where cntr_nbr in  ('00006644549887614196','00007160419047003903') and stat_code<'90';
select * from task_dtl where cntr_nbr in  ('00006644549887614196','00007160419047003903') and stat_code<'90';
select * from wm_inventory where tc_lpn_id in ('00006644549887614196','00007160419047003903'); 

select actl_invn_cases, to_be_filld_cases from pick_locn_dtl;

select * from locn_hdr where area='P' and lvl='D' and aisle='26';

select * from lpn_lock;

select * from shipment;

select * from stop_status

select * from stop_action

select * from stop_action_order

select * from stop_action_shipment

select * from stop_off_charge

select * from stop_action_order_template




select * from locn_hdr where area='P' and lvl='D' and aisle='26';

select actl_invn_cases, to_be_filld_cases from pick_locn_dtl;

select * from pick_locn_dtl;

select * from task_hdr;

select * from alloc_invn_dtl where stat_code<'90';

select lpn_facility_status, manifest_nbr, tc_order_id, tc_shipment_id from lpn where tc_lpn_id='00000197181433873142';

select tc_shipment_id from orders where tc_order_id='1213883969';

SELECT order_status FROM ORDERS where tc_order_id='1213883969';

select * from prod_trkg_tran where cntr_nbr = '00000197181433873142' order by create_date_time desc;

select tc_shipment_id, tc_order_id, tc_lpn_id from lpn where tc_order_id = '1213883969' and lpn_facility_status < 40;

-- 22-MAY-16 12.26.32.846000000 PM
select * from prod_trkg_tran where tc_order_id = '1213883969' order by create_date_time desc;

alter session set NLS_DATE_FORMAT = 'dd.mm.yy hh24:mi:Ss';

select * from DM.MANIFESTED_LPN where TC_LPN_ID = '00000197181433873142';


select pick_detrm_zone "Area", (select code_desc from sys_code where rec_type = 'B' and code_type = '330' and code_id = pick_locn_assign_zone) "Zone",
listagg(lh.dsp_locn,',') within group (order by lh.dsp_locn) "Location List",
count(*) "Locations", sum(nvl(locn_count,0)) "In Use", to_char(sum(nvl(locn_count,0))/count(*)*100,'999')||'%' "In Use %",
min(last_wave_nbr) "Oldest Wave", max(last_wave_nbr) "Newest Wave",
sum(on_hand_qty) "On Hand", sum(to_be_filled_qty) "To Be Filled", sum(wm_allocated_qty) "To Be Picked"
from locn_hdr lh, pick_locn_hdr plh,
(select pld.locn_id, max(lh.locn_pick_seq) locn_pick_seq, max(dsp_locn) dsp_locn, count(*) LOCN_COUNT , max(last_wave_nbr) last_wave_nbr,
 sum(on_hand_qty) on_hand_qty, sum(to_be_filled_qty) to_be_filled_qty, sum(wm_allocated_qty) wm_allocated_qty
from pick_locn_dtl pld, wm_inventory wi, locn_hdr lh
 where pld.pick_locn_dtl_id = wi.location_dtl_id
and pld.locn_id = lh.locn_id
and (on_hand_qty<>0 or to_be_filled_qty <> 0 or wm_allocated_qty <> 0)
group by  pld.locn_id
) pld
where lh.locn_id = plh.locn_id
and plh.locn_id = pld.locn_id (+)
and last_wave_nbr = '201702090075' and to_be_filled_qty <> 0
group by pick_detrm_zone, pick_locn_assign_zone
order by pick_detrm_zone, "Zone";

