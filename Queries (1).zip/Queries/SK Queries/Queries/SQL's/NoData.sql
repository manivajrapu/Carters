alter session SET Current_schema=DM;

select unique o.order_type, o.tc_order_id, o.order_id, o.do_status, l.tc_lpn_id, l.chute_id
from picking_short_item psi, orders o, lpn l, order_line_item oli
where psi.line_item_id = oli.line_item_id and o.order_id = oli.order_id and psi.tc_lpn_id = l.tc_lpn_id
and o.order_type in ('PR','EC') and l.lpn_Facility_status = 15 and psi.stat_code = 90 and do_dtl_status >=120
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.item_id = psi.item_id and td.stat_code < 90)
and not exists (select 1 from picking_short_item psi2 where psi2.line_item_id = psi.line_item_id and psi2.stat_code = 0)
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.tc_order_id = o.tc_order_id and td.stat_code < 90)
and not exists (select 1 from alloc_invn_dtl aid where aid.carton_nbr = psi.tc_lpn_id and aid.tc_order_id = o.tc_order_id and aid.stat_code < 90)
and not exists (select 1 from order_line_item oli2 where oli2.order_id = oli.order_id and oli2.do_dtl_status < 150);

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--carton_nbr for dc33
select prtl_ship_conf_flag from orders;
select * from orders where tc_order_id='1220487649';
select distinct RTL_PKT_FLAG from pkt_hdr;
select * from alloc_invn_dtl where cntr_nbr in  ('99033704') and stat_code<'90';

select * from task_dtl where TASK_ID='65279023' and STAT_CODE<90;--40
select count(*) from task_dtl where task_id = '65279023' and stat_code < '90';
select stat_code from task_hdr where task_id = '65279023';
select * from task_hdr where TASK_ID in ('65279023');--1
select * from lpn; where tc_lpn_id='000099038447' and inbound_outbound_indicator='I';--orphand aid 52
select order_type from orders where tc_order_id = 'CAR26227036_1';

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source,order_id,
INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('00000197181557947422');  --1st Execute status 15.

select total_lpn_qty from lpn where tc_lpn_id in ('00000197181557947422');  --a part

select lpn_facility_status,tc_lpn_id from lpn where tc_order_id in ('1220978666');    --b part

select * from DM.TASK_DTL where Carton_NBR in ('00000197181557947422') and  stat_code < '90';--970062490104     --2nd No open task

select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181557947422') and stat_code < '90';    -- 3rd No open Allocations

select * from picking_short_item where tc_lpn_id in ('00000197181557947422') and stat_code<90;     --4th No picking short items.

select * from lpn_lock where tc_lpn_id in ('00000197181557947422'); --5th ch lock


select * from lpn where tc_order_id = 'CAR26227036_1';--check if order hs multiple cartons.


select * from task_hdr where task_id = '65231600';
select * from item_cbo where item_name = '243H032 S 3T';--2356774

select do_status from orders where tc_order_id = 'CAR26227036_1';
select * from FACILITY_ALIAS where FACILITY_alias_id = '299848-1059921';
select do_dtl_status from order_line_item where order_id = '43984428' and item_id = '2365045';--item_id from lpn table
select * from lpn where manifest_nbr = 'USPS0004573';
select * from order_line_item;
SELECT * FROM SHIPMENT where shipment_status < '60' and SHIPMENT_CLOSED_INDICATOR = '0' and WMS_STATUS_CODE is not null;where manifest_nbr = 'USPS0004573';




--00000197181543486607-
--00000197181543268425--multiple lpn
--00000197181543559288-
--00000197181543521636-
--00000197181543449053-
--00000197181543520547-
--00000197181543446984-
--00000197181543507623-
--00000197181543521971-
--00000197181543268050--multiple lpn
select * from task_hdr carton_nbr = '00000197181543535596';
select cntr_nbr,alloc_invn_dtl_id, stat_code from task_dtl where carton_nbr = '00000197181543486607';
select * from task_dtl where cntr_nbr = '99038447';
select stat_code from alloc_invn_dtl where cntr_nbr = '99038447';
select * from task_hdr where carton_nbr = '00000197181543535596';
select cntr_nbr,stat_code from alloc_invn_dtl where alloc_invn_dtl_id = '693992299';

select STAT_CODE from alloc_invn_dtl where cntr_nbr in  ('99038447') and stat_code<'90';

select * from orders where tc_order_id = 'CAR25796826_1';
select  * from order_line_item where order_id = '43894538';
select * from lpn where tc_order_id = 'CAR25774845_1';--check if order hs multiple cartons.
select * from order_line_item;
select * from vas_carton where carton_nbr = '00000197181543535596';--check status of vas lock.
select * from DM.ITEM_cbo where item_name = '127G404 M 12M';--
select * from lpn_detail where lpn_id in ('64712225') and lpn_detail_status<'90';
select do_status,order_id from  orders where tc_order_id in ('BCAR25688207_1');
select * from picking_short_item where tc_lpn_id in ('00000197181543486607');
select * from lpn_lock where tc_lpn_id in ('00000197181542357861');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181543535596') and stat_code < '90';--carton_nbr for dc33--cntr--dealloc//carton--no data
select * from DM.ALLOC_INVN_DTL where alloc_invn_dtl_id = '65535431';
select * from task_hdr where task_id = '64120452';
select * from task_hdr;
select * from DM.TASK_DTL where CARTON_NBR in ('00000197181543486607') and stat_code < '90';--970062490104
select stat_code from dm.task_hdr where task_id = '62490104';
select stat_code from DM.TASK_DTL where task_id='62490104' and stat_code < '90';
select count(*) from task_dtl where cntr_nbr = '970062490104' and stat_code < 90;
select count(*) from dm.task_dtl where task_id = '62490104' and stat_code < '90';
select tc_order_id,tc_lpn_id from lpn where tc_order_id in ('CAR24314253_1');
select allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id='40494710' and item_id='2141782';
select * from wm_inventory where tc_lpn_id in ('970062490104') and item_id='2141782';--608657392



select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source from lpn where tc_lpn_id in ('00000197181540785550');
select * from lpn_detail where lpn_id in ('64712225') and lpn_detail_status<'90';
select do_status,order_id from  orders where tc_order_id in ('39318817');
select * from picking_short_item where tc_lpn_id in ('00000197181330546699');
select * from lpn_lock where tc_lpn_id in ('00000197181330546699');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181330546699') and stat_code < '90';
select * from DM.ALLOC_INVN_DTL where cntr_nbr in ('00000197181330546699') and stat_code < '90';
select * from DM.TASK_DTL where CARTON_NBR in ('00000197181330546699') and stat_code < '90';
select tc_order_id,tc_lpn_id from lpn where tc_order_id in ('CAR24314253_1');
select allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id='40494710' and item_id='2141782';
select * from wm_inventory where tc_lpn_id in ('970062490104') and item_id='2141782';--608657392



--------------------------------------------------------------------------------------------------------------------------------------------

select lpn_facility_status,lpn_id,tc_lpn_id,INBOUND_OUTBOUND_INDICATOR, tc_order_id,last_updated_source from lpn where tc_lpn_id in ('00000197181540755195');
select * from lpn_detail where lpn_id in ('64657680');
select do_status,order_type,order_id from orders where tc_order_id in ('1219947888');
select distinct do_dtl_status from DM.ORDER_LINE_ITEM where order_id='43500410';--do_dtl_status=200--then we can cancell
select * from picking_short_item where tc_lpn_id in ('00000197181540755195') and stat_code<90;----637871733
select * from lpn_lock where tc_lpn_id in ('00000197181540755195');
select * from DM.ALLOC_INVN_DTL where Carton_NBR in ('00000197181540755195') and stat_code < '90';
select * from DM.TASK_DTL where carton_nbr in ('00000197181540755195') and stat_code < '90';
select distinct tc_order_id,tc_lpn_id,lpn_facility_status from lpn where tc_order_id in ('1219947888');
select allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id in ('40559301') and item_id='2299357';
select TC_LPN_ID,ON_HAND_QTY,WM_ALLOCATED_QTY,TO_BE_FILLED_QTY from wm_inventory where tc_lpn_id in ('00000197181523644713') and item_id='2287974';
------------------
Select unique o.order_type, o.tc_order_id, o.order_id, o.do_status, l.tc_lpn_id, l.chute_id
from picking_short_item psi, orders o, lpn l, order_line_item oli
where psi.line_item_id = oli.line_item_id and o.order_id = oli.order_id and psi.tc_lpn_id = l.tc_lpn_id
and o.order_type in ('PR','EC') and l.lpn_Facility_status = 15 and psi.stat_code = 90 and do_dtl_status >=120
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.item_id = psi.item_id and td.stat_code < 90)
and not exists (select 1 from picking_short_item psi2 where psi2.line_item_id = psi.line_item_id and psi2.stat_code = 0)
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.tc_order_id = o.tc_order_id and td.stat_code < 90)
and not exists (select 1 from alloc_invn_dtl aid where aid.carton_nbr = psi.tc_lpn_id and aid.tc_order_id = o.tc_order_id and aid.stat_code < 90)
and not exists (select 1 from order_line_item oli2 where oli2.order_id = oli.order_id and oli2.do_dtl_status < 150);

--------------------------------------
select orders set do_status = 150 where order_type in ('EC') and do_status < 150
and not exists (select 1 from order_line_item oli where orders.order_id = oli.order_id and oli.do_dtl_status < 150);
------------------------------------------------------------------------------------------------------------------------------------------------
select*from lpn where tc_lpn_id='00000197181529880825';
select * from DM.LPN_DETAIL where lpn_id = '64657680';
------------------------------------------------------------------------------------------------------------------------------------------------

select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);
------------------------------------------------------------------------------------------------------------------------------------------------------
select tc_lpn_id,lpn_facility_status,tc_order_id from lpn where tc_lpn_id in ('00000197181519152321');
select BILL_ACCT_NBR from orders where tc_order_id='1218708623';
select distinct(tc_order_id), bill_acct_nbr from orders where bill_acct_nbr ='185-4X0';

select * from alloc_invn_dtl where cntr_nbr in ('970059456184','970059467904','970059468090','970059467905','970059468093') and stat_code<'90';
select * from task_dtl where cntr_nbr in ('970059456184','970059467904','970059468090','970059467905','970059468093') and stat_code<'90';
-----------------------------------------------------------------------------------------------------------------------------------------------
select shipment_status,SHIPMENT_CLOSED_INDICATOR,LPN_ASSIGNMENT_STOPPED,WMS_STATUS_CODE,last_updated_source,LAST_UPDATED_DTTM from shipment where tc_shipment_id='CS20714649';



Select * from dm.alloc_invn_dtl where task_genrtn_ref_nbr in ('201705040022') and stat_code < 90;

Select * from dm.task_dtl where task_genrtn_ref_nbr in ('201705040022') and stat_code < 90;

Select * from dm.lpn where wave_nbr in ('201705040022') and lpn_facility_status < 20;

SELECT * FROM dm.ORDER_LINE_ITEM WHERE WAVE_NBR in ('201705040022') AND DO_DTL_STATUS < 150;

SELECT * FROM dm.ALLOC_INVN_DTL, dm.ORDER_LINE_ITEM, dm.ORDERS
WHERE ORDERS.ORDER_ID = ORDER_LINE_ITEM.ORDER_ID
AND ORDER_LINE_ITEM.LINE_ITEM_ID = ALLOC_INVN_DTL.LINE_ITEM_ID
AND ORDERS.TC_ORDER_ID = ALLOC_INVN_DTL.TC_ORDER_ID
AND WHSE = '12'
AND STAT_CODE < 90
AND INVN_NEED_TYPE = 60
AND DO_TYPE = 10
AND WAVE_NBR in ('201705040022');

select * from dm.pkt_dtl where units_pakd=pkt_qty and WAVE_NBR in ('201705040022');




select emp.*,d.DESCRIPTION dept, s.DESCRIPTION shift,jf.NAME job_func,emp2.login_user_id supv
from dm.VIEW_EMP emp
left join dm.E_DEPT d on emp.dept_id = d.dept_id
left join dm.E_SHIFT s on emp.shift_id = s.shift_id
left join dm.E_JOB_FUNCTION jf on emp.JOB_FUNC_ID = jf.JOB_FUNC_ID
left join dm.VIEW_UCL_USER emp2 on emp2.emp_id = emp.SPVSR_EMP_ID
where emp.whse = '12';


select cle.name, to_char(cleq.msg_id) MSG_ID, l.tc_lpn_id, o.tc_order_id, when_queued, cleq.status, REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 14) USER_ID
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l, orders o
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and l.order_id = o.order_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 6)  = l.tc_lpn_id 
and o.order_type = 'EC'
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_PickConfirm') 
and error_count > 1;



select * from trailer_tran;
