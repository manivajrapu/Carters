select * from asn where bill_of_lading_number='00197181201755465'; 

select tc_shipment_id, ship_via from lpn where bol_nbr='00197181201755465';

select c from shipment where tc_shipment_id='CS14830652';

--tc_asn_id='2016183121747450080875111';

select * from ship_via where description like '%Call%';

select * from lpn where ship_via ='CALL'

select * from 