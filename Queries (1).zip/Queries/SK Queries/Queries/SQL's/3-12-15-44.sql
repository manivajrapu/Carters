select shpmt_nbr,stat_code,error_seq_nbr from inpt_asn_hdr where shpmt_nbr='177083001';

select * from msg_log where ref_value_1='10006097';

select * from inpt_asn_dtl; where shpmt_nbr='177083001';

select shpmt_nbr,stat_code from asn_hdr where shpmt_nbr='177084001';


select * from inpt_asn_hdr where shpmt_nbr='174603001';

select * from msg_log where ref_value_1='10006096';

select * from inpt_case_hdr where case_nbr='00006644549973177888'; and orig_shpmt_nbr='174603001';

select * from asn_hdr;

select * from appt_sched;


177083001

177084001




