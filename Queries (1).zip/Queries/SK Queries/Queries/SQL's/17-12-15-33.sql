select * from inpt_xref where sku_brcd in ('000012516247','000012528189','000012529520','000012529469');

select msg from msg_log where ref_value_1 in ('10016283', '10016294', '10016311', '10016359');

select * from item_master where std_case_qty>20; where sku_brcd in ('000012516247','000012528189','000012529520','000012529469'); 

select stat_code from asn_hdr where shpmt_nbr='330003049';

select * from case_hdr where case_nbr='00006644543308853263';

select * from prod_trkg_tran where sku_id='115771764'

select pkt_ctrl_nbr,distro_nbr,invn_type,stat_code,sku_id,po_nbr,reqd_qty,alloc_qty,case_nbr,wave_nbr,ship_wave_nbr,wave_alloc_qty 
from store_distro where distro_nbr='330119550581';

select sku_id,pkt_ctrl_nbr,orig_ord_qty,orig_pkt_qty,pkt_qty,to_be_verf_as_pakd,verf_as_pakd,units_pakd,std_bundl_qty 
from pkt_dtl where pkt_ctrl_nbr='3412410501' and sku_id='115771764';