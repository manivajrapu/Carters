select * from carton_hdr where wave_nbr in ('201604280022','201607120540','201610060529','201610040542');
select * from carton_dtl where carton_nbr and line_item_stat<'90';

select * from carton_dtl where carton_nbr and line_item_stat<'90';
select * from case_hdr;
select * from ship_wave_parm where pick_wave_nbr='201610040542';
select ship_wave_nbr, pick_wave_nbr,wave_desc, stat_code, create_date_time, mod_date_time from ship_wave_parm where ship_wave_nbr in ('201607120540','201610060529','201610040542','201604280022');
select * from alloc_invn_dtl where task_genrtn_ref_nbr in ('201607120540','201610060529','201610040542','201604280022') and stat_code<'90';
select * from task_dtl where task_genrtn_ref_nbr in ('201607120540','201610060529','201610040542','201604280022') and stat_code<'90';
select * from task_hdr where task_genrtn_ref_nbr in ('201607120540','201610060529','201610040542','201604280022') and stat_code<'90';

select distinct(po from store_distro where po_nbr in ('10267796','10279647','10293673');


--00000197183470238137,00000197183470336505  

select * from carton_dtl where carton_nbr in ('00000197183470238137','00000197183470336505');