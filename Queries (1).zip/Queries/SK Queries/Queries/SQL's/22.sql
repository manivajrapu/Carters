select stat_code,error_seq_nbr from inpt_xref where sku_brcd='000012519705';

select * from msg_log where ref_value_1='10003268';

select * from item_master where sku_brcd='000012519705';