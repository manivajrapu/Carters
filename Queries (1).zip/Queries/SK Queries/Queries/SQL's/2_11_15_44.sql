select sku_id,stat_code,error_seq_nbr from inpt_pkt_dtl where pkt_ctrl_nbr='7000023892';

select * from inpt_pkt_dtl where pkt_ctrl_nbr='7000023892' and error_seq_nbr='10005110';

select * from msg_log where ref_value_1='10005110';

select * from item_master where style='120G082' and style_sfx='CO' and sec_dim='EC002' and size_desc='9M';

select style,style_sfx,size_desc,sec_dim from inpt_pkt_dtl where error_seq_nbr > 0;

select * from inpt_asn_hdr