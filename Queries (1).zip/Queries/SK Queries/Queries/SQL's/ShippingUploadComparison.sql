select * from carton_hdr where stat_code<'90'; carton_nbr='0012016077067148756';

select * from item_master where style='235G299' and size_desc='18M';

select * from outpt_carton_hdr where proc_stat_code<'90';
select * from alloc_invn_dtl;