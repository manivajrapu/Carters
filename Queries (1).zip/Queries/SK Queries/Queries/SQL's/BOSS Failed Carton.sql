select tc_order_id, manifest_nbr from lpn where tc_lpn_id in ('00000197181528825926');

select d_city from orders where tc_order_id in ('BCAR19178537_1','BCAR19178916_1');