select stat_code from inpt_asn_hdr where shpmt_nbr='126414001';

select * from inpt_asn_dtl where shpmt_nbr='126414001';

select * from asn_hdr where shpmt_nbr='126414001';

select * from asn_hdr where shpmt_nbr='126414001';

182567001, 126414001

select stat_code from inpt_asn_hdr where shpmt_nbr='182567001';

select * from inpt_asn_dtl where shpmt_nbr='182567001';

select stat_code from asn_hdr where shpmt_nbr='182567001';

select * from asn_hdr where shpmt_nbr='182567001';