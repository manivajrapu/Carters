select stat_code from case_hdr where case_nbr='PT3415474';

select * from alloc_invn_dtl where task_genrtn_ref_nbr='201607300025'  and stat_code<90 and qty_alloc='0';--and invn_need_type='60';

select * from alloc_invn_dtl where cntr_nbr='PT3415474' and stat_code<90; and qty_alloc='0';

select * from item_master where (select sku_id from alloc_invn_dtl WHERE cntr_nbr='PT3415474');

select * from task_hdr where task_genrtn_ref_nbr='201607300025' and stat_code<'90' and invn_need_type='60';

select * from task_dtl where task_genrtn_ref_nbr='201607300025' and stat_code<'90';

select  from pkt_dtl where wave_nbr='201607300025'  and stat_code<90 and units_pakd>'0';
select * from pkt_dtl_stat
select * from task_dtl where cntr_nbr = 'PT3415474';
select invn_need_type, stat_code, cntr_nbr from alloc_invn_dtl where cntr_nbr = 'PT3415474' and stat_code<90;

select * from alloc_invn_dtl where task_genrtn_ref_nbr='201607300025' and stat_code<'90';

----------Invalid DC33 Transfer
select * from carton_hdr where carton_nbr in ('00000197183957905248', '00000197183957905286', '00000197183957904753', '00000197183957905231', '00000197183957905101', '00000197183957928025', '00000197183957927790', '00000197183957879631', '00000197183957904968', '00000197183957905224', '00000197183957905095', '00000197183957928131');

select * from carton_dtl where carton_nbr in ('00000197183957905248', '00000197183957905286', '00000197183957904753', '00000197183957905231', '00000197183957905101', '00000197183957928025', '00000197183957927790', '00000197183957879631', '00000197183957904968', '00000197183957905224', '00000197183957905095', '00000197183957928131');

select * from outpt_carton_hdr where carton_nbr in ('00000197183957905248', '00000197183957905286', '00000197183957904753', '00000197183957905231', '00000197183957905101', '00000197183957928025', '00000197183957927790', '00000197183957879631', '00000197183957904968', '00000197183957905224', '00000197183957905095', '00000197183957928131');

select * from outpt_carton_dtl where carton_nbr in ('00000197183957905248', '00000197183957905286', '00000197183957904753', '00000197183957905231', '00000197183957905101', '00000197183957928025', '00000197183957927790', '00000197183957879631', '00000197183957904968', '00000197183957905224', '00000197183957905095', '00000197183957928131');

select * from pkt_hdr where pkt_ctrl_nbr in ('3339112343');
select * from pkt_dtl where pkt_ctrl_nbr in ('3339112343');

select proc_stat_code from outpt_pkt_hdr where pkt_ctrl_nbr in ('3339112343');

select proc_stat_code from outpt_pkt_dtl where pkt_ctrl_nbr in ('3339112343');

select error_seq_nbr from inpt_store_master

select * from msg_log where ref_value_1='156010099';




select * from pkt_hdr where (select pkt_ctrl_nbr from alloc_invn_dtl where task_genrtn_ref_nbr='201607300025');

select * from ship_wave_parm where pick_wave_nbr='201607300025';


