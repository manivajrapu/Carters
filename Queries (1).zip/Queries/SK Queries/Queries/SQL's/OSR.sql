alter session SET Current_schema=DM;

with a as (select unique td.task_genrtn_ref_nbr, swp.wave_desc, th.task_id, th.stat_code, th.mhe_flag, 
decode(swp.wave_desc, 'Chase Wave', '7022','UNKNOWN') EVENT_ID
from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
and td.invn_need_type = 51 and th.stat_code = 10 and td.stat_code < 90 and th.mhe_flag = 'Y' and th.create_date_time < sysdate - 1/24
and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)
and
not exists (select 1 from event_message_history em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90);

-- to check success or failed 
select ek_wave_nbr, cl_message_id, stat_code, nbr_of_retry, event_id, event_message_id , create_date_time
from dm.event_message 
where ek_wave_nbr = any ('201612260028') 
and (event_id = 7019 or event_id = 7017 or event_id = 7022) 
order by ek_wave_nbr, create_date_time;  


select mhe_flag,task_id,stat_code,task_id from dm.task_hdr where task_id in ('50546181') and stat_code ='10' and task_cmpl_ref_nbr ='201608190058';


select mhe_flag,stat_code from dm.task_hdr where task_id in ('57562822');

select mhe_flag,stat_code from dm.task_hdr where task_id in ('57562794');

select mhe_flag,task_id,stat_code,task_id from dm.task_hdr where task_genrtn_ref_nbr ='201606230027' and mhe_flag='N';

with a as (select unique td.task_genrtn_ref_nbr, th.task_id, th.stat_code, th.mhe_flag,
                    decode(swp.wave_desc, 'eCOM Unit Sorter Wave', '7019','Wholesale Unit Sorter Wave','7019','Put Wall from EPM','7019','Chase Wave','7022','7017') EVENT_ID
     from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
     and th.invn_need_type in(3,51) and th.stat_code = 10 and th.mhe_flag = 'N' and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90);

--Chase wave

with a as (select unique td.task_genrtn_ref_nbr, swp.wave_desc, th.task_id, th.stat_code, th.mhe_flag, 
                    decode(swp.wave_desc, 'Chase Wave', '7022','UNKNOWN') EVENT_ID
     from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
     and td.invn_need_type = 51 and th.stat_code = 10 and td.stat_code < 90 and th.mhe_flag = 'Y' and th.create_date_time < sysdate - 1/24
     and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)
and
not exists (select 1 from event_message_history em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90);


with a as (select unique td.task_genrtn_ref_nbr, th.task_id, th.stat_code, th.mhe_flag,
                    decode(swp.wave_desc, 'eCOM Unit Sorter Wave', '7019','Wholesale Unit Sorter Wave','7019','Put Wall from EPM','7019','Chase Wave','7022','7017') EVENT_ID
     from task_hdr th, task_dtl td, ship_wave_parm swp, locn_hdr lh where th.task_id = td.task_id and td.pull_locn_id = lh.locn_id and td.task_genrtn_ref_nbr = swp.ship_wave_nbr
     and th.invn_need_type in(3,51) and th.stat_code = 10 and th.mhe_flag = 'N' and dsp_locn like 'PO%')
select *
from a where
not exists (select 1 from event_message em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90)
and
not exists (select 1 from event_message_history em where em.ek_wave_nbr = a.task_genrtn_ref_nbr and em.event_id = a.event_id and em.stat_code = 90);



