alter session SET Current_schema=DM;

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,TOTAL_LPN_QTY,tc_order_id,manifest_nbr,order_id,SHIP_VIA,TC_REFERENCE_LPN_ID,
INBOUND_OUTBOUND_INDICATOR,last_updated_source,LAST_UPDATED_DTTM,SHIP_BY_DATE
from lpn where TC_LPN_ID in ('00000197181619026157');

select DISTINCT(aid.CNTR_NBR),aid.ALLOC_INVN_DTL_ID,(aid.CARTON_NBR),aid.STAT_CODE,aid.INVN_NEED_TYPE
from DM.ALLOC_INVN_DTL aid where aid.CNTR_NBR in 
('99033278', '99023644', '99047775', '99053617', '99006935', '99045940', '99023283', '99046493', '99048642', '99040413', '99004872', '99019762', 
'99009552', '99042438', '99011970', '99001557', '99011274', '99007626', '99042499', '99000783', '99023698', '970900971486', '970099999998') 
and stat_code < '90';    -- 3rd No open Allocations  99011639  99036853

select * from DM.TASK_DTL where CNTR_NBR in () and  stat_code < '90';--970062490104 --2nd No open task

--------------------------------------------------------------
select TC_LPN_ID,LPN_FACILITY_STATUS,INBOUND_OUTBOUND_INDICATOR,LAST_UPDATED_SOURCE from lpn where TC_LPN_ID in 
('99026444','99034585','00007160417265642171','00007160415314626127',
'99049954','99044660','00006644540042922590','00007160415314659743','00000156740042347111','00007160415314630414','00007160415314625854',
'00007160419170634111','00007160419063284485','00000156740042941869','99039209','99043370','99013796','99014683','99002851','00006644540042957981',
'00007160419170641270','99010269','99001094','00006644540042941737','00007160419170643007','99008714','00006644540302643517','00007160415314627094',
'99037771','00007160419063289428','00007160414503332740','00007160419170631677','99009000','00000156740040543539');

select * from orders WHERE TC_ORDER_ID in ('1224625642');
select * from DM.SHIPMENT WHERE TC_SHIPMENT_ID in ('1224625642');

select o.TC_ORDER_ID,oli.REF_FIELD2,oli.ITEM_NAME,oli.SHIPPED_QTY,oli.DO_DTL_STATUS from ORDER_LINE_ITEM oli, orders o 
where oli.order_id='53784317' and oli.DO_DTL_STATUS=190 and o.order_id=oli.order_id;

select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty, allocated_qty, units_pakd, do_dtl_status
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = 'CAR30970135_1' and oli.item_id in ('2442254')