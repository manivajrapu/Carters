alter session SET Current_schema=DM;

select o.ext_purchase_order, o.order_id, o.tc_order_id, o.order_status, o.do_status, l.tc_lpn_id, ship_via, to_char(l.shipment_id) shipment_Id, l.tc_shipment_Id, s.assigned_ship_via S_SHIP_VIA, s.shipment_id S_SHIP_ID, s.tc_shipment_id s_TC_SHIP_ID,
  'update lpn set ship_via = '||chr(39)||s.assigned_ship_via||chr(39)||', shipment_id =  '||chr(39)||s.shipment_id||chr(39)||', tc_shipment_Id = '||chr(39)||s.tc_shipment_id||chr(39)||' where tc_lpn_id = '||chr(39)||l.tc_lpn_id||chr(39)||';' CCF
from orders o, lpn l, order_split os, shipment s where o.order_id = l.order_id and o.order_id = os.order_id (+) and os.shipment_Id = s.shipment_Id (+)
and o.ext_purchase_order in (
'321081'
)
and l.lpn_facility_status < 40 and s.shipment_status = 60 and os.is_cancelled = 0
order by ext_purchase_order, tc_order_id;

----new query
select o.ext_purchase_order, o.order_id, o.tc_order_id, o.order_status, o.do_status, l.tc_lpn_id, l.order_split_id, os.order_split_id, ship_via, to_char(l.shipment_id) shipment_Id, l.tc_shipment_Id, s.assigned_ship_via S_SHIP_VIA, s.shipment_id S_SHIP_ID, s.tc_shipment_id s_TC_SHIP_ID,
  'update lpn set order_split_id = '||chr(39)||os.order_split_id||chr(39)||', ship_via = '||chr(39)||s.assigned_ship_via||chr(39)||', shipment_id =  '||chr(39)||s.shipment_id||chr(39)||', tc_shipment_Id = '||chr(39)||s.tc_shipment_id||chr(39)||' where tc_lpn_id = '||chr(39)||l.tc_lpn_id||chr(39)||';' CCF
from orders o, lpn l, order_split os, shipment s where o.order_id = l.order_id and o.order_id = os.order_id (+) and os.shipment_Id = s.shipment_Id (+)
and o.ext_purchase_order in (
'BG6A5TC'
)
and l.lpn_facility_status < 40 and s.shipment_status = 60 and os.is_cancelled = 0
order by ext_purchase_order, tc_order_id;

--Alert Query
select ext_purchase_order "PURCHASE_ORDER", bill_to_name "CUSTOMER", 
        addr_code "DIV", rte_to "ROUTE_TO", lane_name "LANE", tc_shipment_id "ORDERS_SHIPMENT_ID", count(*) "TOTAL_ORDERS"
from orders o where order_type not in ('EC','SD') and order_status = 10 and do_status < 190
and exists (select 1 from lpn l where l.order_id = o.order_id and l.lpn_Facility_status < 90 and tc_shipment_Id is null and inbound_outbound_Indicator = 'O')
group by  ext_purchase_order, bill_to_name, addr_code, rte_to, lane_name, tc_shipment_id;

select * from ship_wave_parm where pick_wave_nbr='201707260002';
select distinct(tc_order_id) from orders where EXT_PURCHASE_ORDER ='A319243';
select ship_via, shipment_id, tc_shipment_id,order_split_id, last_updated_source,LPN_FACILITY_STATUS,tc_lpn_id from lpn where tc_order_id in ('1218431958','1218401060','1218487498','1218418720','1218308629');

select tc_shipment_id from lpn where TC_LPN_ID='00000197181561613122';





--SQL
select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status <= 180 and lpn_facility_status < 40 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status > 60);


-------------<40 status
select l.ship_via, l.shipment_id, l.tc_shipment_id,l.order_split_id, l.last_updated_source,l.LPN_FACILITY_STATUS,
l.tc_lpn_id,l.tc_order_id,o.EXT_PURCHASE_ORDER from lpn l,orders o where l.tc_order_id in (select distinct(tc_order_id)
from orders where 
orders.EXT_PURCHASE_ORDER in ('DH2E8VJ'))
and l.tc_order_id = o.tc_order_id and l.LPN_FACILITY_STATUS <40; 



