alter session SET Current_schema=DM;

Select proc_stat_code from outpt_orders where batch_ctrl_nbr in ('120680031','120680032','120680034');

Select  from outpt_order_line_item where batch_ctrl_nbr in ('120680031','120680032','120680034');

select invc_batch_nbr,tc_lpn_id,proc_stat_code, tc_order_id, last_updated_dttm from outpt_lpn where invc_batch_nbr in ('120680031','120680032','120680034');

select * from outpt_lpn_detail where invc_batch_nbr in ('120680031','120680032','120680034');

select do_status, tc_order_id from orders where tc_order_id in ('BCAR21566417_1', 'BCAR21564506_1', 'BCAR21618516_1');
select * from lpn where tc_lpn_id in ('00000197183967410510', '00000197183967410350', '00000197183967410572', '00000197183967410466', '00000197183967410435', '00000197183967410558', '00000197183967410589', '00000197183967410381', '00000197183967410411', '00000197183967410398', '00000197183967410541', '00000197183967410343', '00000197183967410596', '00000197183967410367', '00000197183967410442', '00000197183967410374', '00000197183967410473', '00000197183967410527', '00000197183967410503', '00000197183967410480', '00000197183967410428');

---------------Checks
Select acct_rcvbl_acct_nbr, ext_purchase_order, proc_stat_code,batch_ctrl_nbr,created_dttm,created_source,tc_order_id from outpt_orders where batch_ctrl_nbr = '120686445';
Select proc_stat_code,batch_ctrl_nbr,created_dttm,created_source, invc_batch_nbr from outpt_order_line_item where batch_ctrl_nbr = '120686445';
select proc_stat_code,tc_lpn_id,tc_order_id from outpt_lpn where invc_batch_nbr='120686445';
select proc_stat_code, invc_batch_nbr, created_dttm, lpn_detail_id from outpt_lpn_detail where invc_batch_nbr='120686445';
select lpn_facility_status, last_updated_source, tc_order_id from lpn where tc_lpn_id in ('00000197181484335965','00000197181484337068','00000197181484287547','00000197181484288445','00000197181484292213');
select do_status from orders where tc_order_id in ('CAR21803912_1','CAR21806827_1','CAR21802936_1','CAR21799933_1','ICAR21803101_1');


Select acct_rcvbl_acct_nbr, ext_purchase_order,do_status created_dttm,created_source,tc_order_id from orders where invc_batch_nbr = '120686445';
Select proc_stat_code,batch_ctrl_nbr,created_dttm,created_source, invc_batch_nbr from order_line_item where batch_ctrl_nbr = '120686445';
select proc_stat_code,tc_lpn_id,tc_order_id from lpn where invc_batch_nbr='120686445';
select proc_stat_code, invc_batch_nbr, created_dttm, lpn_detail_id from lpn_detail where invc_batch_nbr='120686445';

