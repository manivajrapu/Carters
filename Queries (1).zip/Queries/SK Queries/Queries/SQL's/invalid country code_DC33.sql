select cntry_of_orgn,carton_nbr from carton_dtl where carton_nbr in ('00000197183471073607') 
and cntry_of_orgn = 'MALA';


select count(*) from alloc_invn_dtl where carton_nbr in ('00000197183471073607') 
and cntry_of_orgn='MALA';

select CNTRY_OF_ORGN from alloc_invn_dtl where carton_nbr in ('00000197183471073607'); 

select distinct ad.cntry_of_orgn, 
                ad.vendor_id, 
                ad.PO_NBR,
                ah.SHPD_DATE,
                ad.SHPMT_NBR, 
                ad.SHPMT_SEQ_NBR, 
                im.style, 
                im.style_sfx, 
                im.sec_dim, 
                im.size_desc 
  from asn_hdr ah, asn_dtl ad, item_master im 
 where ah.SHPMT_NBR = ad.SHPMT_NBR 
   and ad.SHPMT_SEQ_NBR = ad.SHPMT_SEQ_NBR
   and ad.CNTRY_OF_ORGN = 'MALA'
   and ad.sku_id = im.sku_id
   and ah.STAT_CODE < 90;
   
   select count(*) from carton_dtl where CNTRY_OF_ORGN = 'MALA';