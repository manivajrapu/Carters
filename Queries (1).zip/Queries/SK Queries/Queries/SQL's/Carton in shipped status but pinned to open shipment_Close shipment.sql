alter session SET Current_schema=DM;

--SQL to check
select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status < 190 and lpn_facility_status = 90 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status < 80 );

select * from shipment where tc_shipment_id='CS24379105';

select tc_lpn_id, tc_order_id, tc_shipment_id, lpn_facility_status from lpn where tc_lpn_id='00000197181567006676';

select lpn_facility_status,TC_LPN_ID from lpn where TC_ORDER_ID='BCAR27123073_1';   --check status if any less than 40 reply carton under manifest

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,
last_updated_source, order_id, TOTAL_LPN_QTY,
INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in('00000197181567006676');


select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status < 190 and lpn_facility_status = 90 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status < 80 )
