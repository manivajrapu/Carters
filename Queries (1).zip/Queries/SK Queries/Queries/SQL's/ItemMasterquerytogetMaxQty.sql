select STD_PACK_QTY,STD_CASE_QTY,sku_id,style,style_sfx,color,size_desc from item_master where STD_CASE_QTY>20;

desc item_master;

789876543.00

select stat_code from asn_hdr where shpmt_nbr='330003047';

select stat_code from case_hdr where case_nbr='00006644543308853249';