select i.WHSECODE, sum(i.ONHANDQTY), SUM(ABS(a.OHQTYVARIANCE)), SUM(ABS(a.NAQTYVARIANCE)),a
from INVWHSUM i INNER JOIN WM_INBOUND_PIX605_AGED a
on i.PRODCODE = a.PRODCODE 
WHERE a.warehouse=i.WHSECODE
AND i.WHSECODE in ('12','33')
and a=(Select count(*) AS SKUCOUNT,warehouse 
From(
select distinct prodcode, sizedesc, warehouse from WM_INBOUND_PIX605_AGED
 
)group by warehouse
having warehouse in ('12','33'))
--AND i.WHSECODE in ('12','33','44','60','70','72','74')
GROUP BY i.WHSECODE
 
 UNION ALL
Select count(*) AS SKUCOUNT,warehouse 
From(
select distinct prodcode, sizedesc, warehouse from WM_INBOUND_PIX605_AGED
 
)group by warehouse
having warehouse in ('12','33')
--having warehouse in ('12','33','44','60','70','72','74');

UNION ALL
Select count(*) AS SKUCOUNT,warehouse 
From(
select distinct prodcode, sizedesc, warehouse from WM_INBOUND_PIX605_AGED
 
)group by warehouse
having warehouse in ('12','33');
--having warehouse in ('12','33','44','60','70','72','74');
