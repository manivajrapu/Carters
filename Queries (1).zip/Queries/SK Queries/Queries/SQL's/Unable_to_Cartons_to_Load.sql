select carton_nbr, stat_code, rte_id, ship_via from carton_hdr where carton_nbr in ('00000197183975498692','00000197183975513081','00000197183975515870','00000197183975643191','00000197183975643207','00000197183975679510','00000197183975679527');

select carton_nbr, stat_code, rte_id, ship_via from carton_hdr where pkt_ctrl_nbr in ('3414828833','3414830294','3414830967','3414846029','3414846780');

select rte_id from pkt_hdr where pkt_ctrl_nbr in ('3414828833','3414830294','3414830967','3414846029','3414846780');

select stat_code, user_id from outbd_load where load_nbr='3300100882';