select stat_code,error_seq_nbr from inpt_xref where sku_brcd='000012520176';

select * from msg_log where ref_value_1='140044872';

select * from item_master where sku_brcd='000012520176';

select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
           --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;
  
--case number  00007160419426712365
select case_nbr, stat_code from case_hdr where case_nbr='00007160419426712365';

select actl_qty, orig_qty,total_alloc_qty from case_dtl where case_nbr='00007160419426712365';

select *from alloc_invn_dtl where cntr_nbr='00007160419426712365' and stat_code<90; --got 28 open allocations


select td.*
from  task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
   and aid.stat_code = '0'
  and aid.cntr_nbr='00007160419426712365'
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id
   and td.stat_code < '99'; 
   
   
select *
from task_hdr
where task_id in (select td.task_id
from task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
and aid.stat_code = '00'
and aid.cntr_nbr='00007160419426712365'
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id)
   and stat_code <'99';
          
          
          
          
          
          
          
          
          
          
          
          