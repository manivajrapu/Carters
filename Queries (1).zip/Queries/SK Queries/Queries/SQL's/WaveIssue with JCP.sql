select * from ship_wave_parm where ship_wave_nbr='201705040022';

Select msg, log_date_time from msg_log where ref_value_1='201601210013' order by log_date_time;

select distinct(cntr_nbr) from prod_trkg_tran where wave_nbr='201601210013';

select stat_code, wave_desc, pick_wave_nbr from ship_Wave_parm where pick_wave_nbr='201601210013';

select * from ship_Wave_parm where pick_wave_nbr='201601210013';

select * from carton_hdr where pkt_ctrl_nbr='3336827147';     --wave_nbr='201601210013';

select * from pkt_hdr_intrnl where ship_wave_nbr='201601210513';


select * from task_hdr;

select stat_code from task_dtl where pkt_ctrl_nbr='3336827147';



Select rte_rqst_nbr,stat_code from dyn_rte_hdr where rte_rqst_nbr in ('330000001731482','330000001731490') 

