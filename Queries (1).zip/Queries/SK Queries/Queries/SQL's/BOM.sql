select error_seq_nbr, proc_stat_code from inpt_bom_hdr;

select * from msg_log where ref_value_1='159365779';

select error_seq_nbr, proc_stat_code, shpmt_nbr from inpt_asn_hdr;
select * from case_hdr where orig_shpmt_nbr='191593001'; --00007160415948019548
--00007160415948019555

select * from case_hdr where case_nbr in('00007160415948019548','00007160415948019555');

select * from asn_hdr where shpmt_nbr='191593001';

select * from inpt_bom_hdr;

select * from msg_log where ref_value_1='159365779';
select * from inpt_bom_dtl where bom_id='1514452';
select * from item_master where style='278G301' and style_sfx='PRT' and sec_dim='INT01' and size_desc='4';

select * from bom_hdr where bom_id='1514452';

select * from bom_dtl where bom_id='1514452';

select * from item_master where sku_id='115994393';
