alter session SET Current_schema=DM;

select 'Update lpn set total_lpn_qty = '||sum(size_value)||' where tc_lpn_id = '||chr(39)||l.tc_lpn_id||chr(39)||';' 
from lpn l, lpn_detail ld
where l.lpn_id = ld.lpn_id
and lpn_facility_status > '15'
and lpn_facility_status < '90'
and inbound_outbound_indicator = 'O'
having sum(size_value) <> total_lpn_qty
group by tc_lpn_id, total_lpn_qty;
