alter session set current_schema = DM;

select * from shipment where tc_shipment_id = 'CS21792120';--select the shipment no.

select stop_status from stop where shipment_id = '20829457';--add the shipment_id from above query// 
--stop__status needs to be made 10 to open shipment

--run the CCF for close and invoice shipment:-
--UPDATE SHIPMENT SET SHIPMENT_STATUS = 60, SHIPMENT_CLOSED_INDICATOR = 0, LPN_ASSIGNMENT_STOPPED = 'N', WMS_STATUS_CODE = NULL
--WHERE TC_SHIPMENT_ID = ' ';


