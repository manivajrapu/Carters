select stat_code, error_seq_nbr from inpt_asn_hdr where shpmt_nbr='186605001';

select * from inpt_asn_dtl where shpmt_nbr='186605001';

select stat_code,error_seq_nbr from asn_hdr where shpmt_nbr='186605001';

select * from asn_dtl where shpmt_nbr='186605001';

select * from inpt_item_master where inpt_item_master_id='45462465';


select stat_code from inpt_asn_hdr where shpmt_nbr='190906001';

select stat_code from asn_hdr where shpmt_nbr='190906001';




select * from msg_log where ref_value_1='147411923';

select * from item_master; where item_master_id='45462465';

select error_seq_nbr from inpt_store_master where store_nbr='0779';

select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
           --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;
            
            
--Item cross reference
select * from inpt_xref where sku_brcd in ('000012516247','000012525515','000012528790','000012552566','000012553877');

select * from item_master where sku_brcd in ('000012516247','000012525515','000012528790','000012552566','000012553877');

select distinct(sku_brcd) from inpt_xref where error_seq_nbr>0;

--BOM Failures
select * from inpt_bom_hdr where bom_id in ('1005888', '1027078', '1027082', '1028780', '104634 ', '104635 ', '104636 ', '104637 ', '1065825', '1065840', '1065959', '1066263', '1068331');

select * from inpt_bom_dtl where bom_id in ('1005888', '1027078', '1027082', '1028780', '104634 ', '104635 ', '104636 ', '104637 ', '1065825', '1065840', '1065959', '1066263', '1068331');

select * from bom_hdr where bom_id in ('1005888', '1027078', '1027082', '1028780', '104634 ', '104635 ', '104636 ', '104637 ', '1065825', '1065840', '1065959', '1066263', '1068331');

select * from bom_dtl where bom_id in ('1005888', '1027078', '1027082', '1028780', '104634 ', '104635 ', '104636 ', '104637 ', '1065825', '1065840', '1065959', '1066263', '1068331');


select stat_code from carton_hdr where carton_nbr in ('00000197183464532753', '00000197183464745573', '00000197183464745825', '00000197183464712575', '00000197183464713367', '00000197183464800586', '00000197183464781830', '00000197183464780130', '00000197183464833249', '00000197183464643381', '00000197183464745733', '00000197183464802795', '00000197183464833041', '00000197183464769616', '00000197183464770025') ;

select proc_stat_code from outpt_carton_hdr where carton_nbr in ('00000197183464532753', '00000197183464745573', '00000197183464745825', '00000197183464712575', '00000197183464713367', '00000197183464800586', '00000197183464781830', '00000197183464780130', '00000197183464833249', '00000197183464643381', '00000197183464745733', '00000197183464802795', '00000197183464833041', '00000197183464769616', '00000197183464770025') ;


--Store Master input bridge
select error_seq_nbr from inpt_store_master where store_nbr='0003';
select * from msg_log where ref_value_1 = '148693312';

select * from inpt_store_master;

select * from msg_log where ref_value_1='153522638';

select * from store_master;

select * from inpt_asn_hdr
select * from inpt_asn_dtl

select * from asn_hdr 
select * from asn_dtl

select * from inpt_bom_hdr where bom_id in ('1005888','1028780','1068331','131999','144151');

select * from msg_log where ref_value_1 in ('153237050','153237049','153237047','153237048','153237051');

select * from inpt_bom_dtl where bom_id in ('1005888','1028780','1068331','131999','144151');

select ERROR_SEQ_NBR,PROC_STAT_CODE from inpt_bom_hdr;
select * from inpt_bom_hdr;
select * from inpt_bom_dtl;
select * from msg_log where REF_VALUE_1='168435430';
--delete from inpt_bom_dtl;
--commit;


select ERROR_SEQ_NBR,PROC_STAT_CODE from inpt_store_master;
select * from inpt_store_master;
select * from msg_log where REF_VALUE_1 in ('168435483');
--update inpt_store_master set proc_stat_code = 0, error_seq_nbr = 0;
--commit;









