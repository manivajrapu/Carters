alter session SET Current_schema=DM;


select do_status,tc_order_id,order_id from dm.orders where ext_purchase_order in ('164046','164060');
--29

select o.order_id, '1', 'VS', 'Convert to ECOM', '0', null, '0', oli.line_item_id, 'EC' from dm.orders o, dm.order_line_item oli where ref_field_3 = 'RP' and 
do_status = '110' and o.order_id = oli.order_id and o.tc_order_id in ('1219315216', '1219315217', '1219315218', '1219315220', '1219315221', '1219315222', '1219315223', '1219315224', '1219315225', '1219315226', '1219315227', '1219315229', '1219315230', '1219315231', '1219315232', '1219315233', '1219315234', '1219315235', '1219315236', '1219315237', '1219315238', '1219315239', '1219315240', '1219315241', '1219315242', '1219315243', '1219315244', '1219315245', '1219315246')
 and o.order_id not in(select order_id from dm.order_note);
 --95


select lpn_facility_status, tc_lpn_id, tc_order_id, manifest_nbr from lpn where tc_lpn_id in ('00000197183968879507');








