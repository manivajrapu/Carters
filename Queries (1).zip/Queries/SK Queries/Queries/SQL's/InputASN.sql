select * from inpt_asn_hdr;

select * from asn_hdr where shpmt_nbr='177921001';

select * from case_hdr where orig_shpmt_nbr='177921001' and case_nbr='00006644549943247559';

select * from case_hdr where case_nbr='00006644549943227605';

select * from case_hdr where orig_shpmt_nbr='177921004';

select * from case_hdr where case_nbr='00006644549943228473';

select * from inpt_store_master where error_seq_nbr='140942388';

select * from inpt_store_master;

select msg from msg_log where ref_value_1='140942388';


