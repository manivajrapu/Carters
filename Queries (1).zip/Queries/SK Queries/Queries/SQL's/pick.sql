select p.tran_nbr, p.proc_stat_code, sum(p.INVN_ADJMT_QTY), p.tran_type, p.tran_code, p.item_name, p.ref_field_3 
from pix_tran p, item_cbo i where i.item_id = p.item_id and p.tran_type = '620' and p.style||'_'||p.color||'_'||p.size_desc||'_'||p.ref_field_3 in 
('11108311_984_24M_1213988690') and p.proc_stat_code <> 91 group by p.tran_nbr, p.proc_stat_code, p.tran_type, p.tran_code, p.item_name, p.ref_field_3 order by p.tran_nbr;
