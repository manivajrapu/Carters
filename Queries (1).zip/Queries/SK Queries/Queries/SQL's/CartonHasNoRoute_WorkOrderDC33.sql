alter SESSION set current_schema =wmprod33;

select phi.STAT_CODE, ph.ORD_TYPE, ph.PKT_CTRL_NBR, ph.CUST_PO_NBR, ph.ACCT_RCVBL_ACCT_NBR, ph.CARTON_CUBNG_INDIC from pkt_hdr ph, pkt_hdr_intrnl phi 
 where ph.ACCT_RCVBL_ACCT_NBR = '800012' 
   and ph.ord_type = 'RP' 
   and ph.CARTON_CUBNG_INDIC = '51'
   and ph.PKT_CTRL_NBR = phi.PKT_CTRL_NBR
   and phi.STAT_CODE < 90;
   
  select ORD_TYPE, ACCT_RCVBL_ACCT_NBR, CARTON_CUBNG_INDIC from pkt_hdr where CUST_PO_NBR in ('160721');--enter the work order number from mail
   ----------------------------------------------------carton has no route------------------------------------------------------------------------------------------------------------
   select distinct(rte_id) from carton_hdr where PKT_CTRL_NBR in ('3407039403', '3415318270', '3415319122', '3415321212', '3415321890', '3415322947', '3415323602', '3415328596', '3415329296', '3415329948', '3415331196', '3415331841', '3410469639', '3415318373', '3415319227', '3415321314', '3415322451', '3415323040', '3415323707', '3415328701', '3415329401', '3415330044', '3415331301', '3415331936');
   
   select PKT_CTRL_NBR,rte_id from carton_hdr where pkt_ctrl_nbr in ('3407039403', '3415318270', '3415319122', '3415321212', '3415321890', '3415322947', '3415323602', '3415328596', '3415329296', '3415329948', '3415331196', '3415331841', '3410469639', '3415318373', '3415319227', '3415321314', '3415322451', '3415323040', '3415323707', '3415328701', '3415329401', '3415330044', '3415331301', '3415331936') and rte_id is null;
   select pkt_ctrl_nbr,rte_id from carton_hdr where pkt_ctrl_nbr in ('3407039403', '3415318270', '3415319122', '3415321212', '3415321890', '3415322947', '3415323602', '3415328596', '3415329296', '3415329948', '3415331196', '3415331841', '3410469639', '3415318373', '3415319227', '3415321314', '3415322451', '3415323040', '3415323707', '3415328701', '3415329401', '3415330044', '3415331301', '3415331936');
   
   select * from user_master where login_user_id = 'DSILVAS';
   
select * from outbd_load where tractor_nbr = 'STORE 1168';
select pkt_ctrl_nbr,rte_id from carton_hdr where load_nbr = '3300103665'  and rte_id is not null;
   
