select * from dyn_rte_hdr;  where stat_code<90;
select * from dyn_rte_dtl where rte_rqst_nbr in ('330000001760347','330000001760356');
select pkt_ctrl_nbr, stat_code from pkt_hdr_intrnl where pkt_ctrl_nbr in ('3337630591','3337630698');
select pkt_ctrl_nbr, stat_code from pkt_hdr_intrnl where stat_code='40';
select * from carton_hdr where pkt_ctrl_nbr in ('3337630591','3337630698');
select * from carton_hdr where ship_via='CLLQ';
select * from carton_hdr where tms_to_id='130174351';

select * from dyn_rte_hdr where ship_via='CLLQ';

select * from dyn_rte_hdr where rte_to='93872';

select * from dyn_rte_hdr where rqst_shipto='93872';

select * from dyn_rte_hdr where rdy_to_ship_date_time='22-MAR-16';

select * from dyn_rte_hdr where cust_load_id='130174351';

select * from dyn_rte_hdr where sched_pickup_date='22-MAR-2016' and rte_to='93872'; and cust_load_id='130174351';