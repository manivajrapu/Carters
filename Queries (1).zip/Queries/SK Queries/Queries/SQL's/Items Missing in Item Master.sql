alter session SET Current_schema=DM;

select * from asn where tc_asn_id='15034808041600004';

select tran_log.tran_log_id, sequence_number, msg_line_number, tran_log.created_dttm, msg_line_text
from tran_log, tran_log_message
where tran_log.tran_log_id = tran_log_message.tran_log_id
and msg_line_text like  '%15034808041600004%'
and tran_log.created_dttm >= to_date('8/10/2016','mm/dd/yyyy') and tran_log.created_dttm < to_date('8/12/2016','mm/dd/yyyy')
and tran_log.msg_type = 'ASN'-- order by tran_log_id, sequence_number, msg_line_number
--and origin_id = 'OMNIA';
order by created_dttm desc;



278A450 PRT 4

select item_name, item_bar_code from item_cbo where item_name in ('KV790BKI AST 09WD','KV790BKI AST 06MD','KV790BKI AST 02WD','KV790BKI AST 02MD','KV888BOP AST 135MD','KV790BKI AST 05WD','KV790BKI AST 075WD','KV888BOP AST 2YMD','KV790BKI AST 08MD','KV790BKI AST 03MD','KV888BOP AST 11MD','KV790BKI AST 07WD','KV790BKI AST 085MD','KV790BKI AST 065WD','KV888BOP AST 3YMD','KV888BOP AST 1YMD','KV790BKI AST 095MD','KV790BKI AST 075MD','KV790BKI AST 04WD','KV790BKI AST 05MD','KV888BOP AST 125MD','KV790BKI AST 03WD','KV790BKI AST 065MD','KV888BOP AST 105MD','KV790BKI AST 08WD','KV790BKI AST 085WD','KV888BOP AST 25YMD','KV888BOP AST 115MD','KV790BKI AST 10MD','KV790BKI AST 055MD','KV790BKI AST 04MD','KV790BKI AST 10WD','KV888BOP AST 15YMD','KV790BKI AST 06WD','KV790BKI AST 095WD','KV790BKI AST 09MD','KV790BKI AST 07MD','KV888BOP AST 13MD','KV790BKI AST 055WD','KV888BOP AST 12MD');