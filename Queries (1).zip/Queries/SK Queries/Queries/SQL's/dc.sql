select proc_stat_code, error_seq_nbr from inpt_pkt_hdr;
select style, style_sfx, sec_dim, size_desc from inpt_pkt_dtl where error_seq_nbr = '10204666';
select * from msg_log where ref_value_1 = '10204666';
-- Pickticket 7000025815 sequence 2894 has neither a Item ID nor any Item components identified

select * from inpt_item_master where style = '341G233' and style_sfx = 'S' and sec_dim = 'INT01' and size_desc = '2T';

select * from inpt_asn_hdr where shpmt_nbr='186749001';

select * from inpt_asn_dtl where shpmt_nbr='186749001';

select * from asn_hdr where shpmt_nbr='186749001';

select * from asn_dtl where shpmt_nbr='186749001';