alter session SET Current_schema=DM;

select wm.location_dtl_id, wm.item_id, wm.batch_nbr, count(*), min(lh.dsp_locn)
from dmmsf.locn_hdr lh, dm.wm_inventory wm, dm.item_cbo im where lh.locn_id = wm.location_id and wm.item_id = im.item_id
and lh.locn_class = 'C' 
and lh.dsp_locn like 'POSR%'
group by wm.location_dtl_id, wm.item_id, wm.batch_nbr having count(*) > 1;      --Alert Query

select * from locn_hdr where dsp_locn in ('');    --Give Location obtained from above alert Query. 

select to_be_filled_qty, on_hand_qty, wm_allocated_qty,WM_INVENTORY_ID ,ITEM_ID,LAST_UPDATED_SOURCE
from wm_inventory where location_id in('') and ITEM_ID in ('');   --

select ITEM_ID,ITEM_NAME from item_cbo where ITEM_ID in ('');

select * from wm_inventory where wm_inventory_id in ('');  


select wm.WM_INVENTORY_ID,WM.ON_HAND_QTY,wm.TO_BE_FILLED_QTY,wm.WM_ALLOCATED_QTY,wm.LAST_UPDATED_SOURCE,wm.ITEM_ID,ic.item_name,
WM.LAST_UPDATED_DTTM from wm_inventory wm, item_cbo ic 
where wm.location_id='' and wm.item_id=ic.item_id ORDER BY wm.LAST_UPDATED_DTTM DESC; 

--alert query:
select wm.location_dtl_id,lh.locn_id, wm.item_id, im.item_name,wm.batch_nbr, count(*), min(lh.dsp_locn)
from dmmsf.locn_hdr lh, dm.wm_inventory wm, dm.item_cbo im where lh.locn_id = wm.location_id and wm.item_id = im.item_id
and lh.locn_class = 'C' 
and lh.dsp_locn like 'POSR%'
group by wm.location_dtl_id, lh.locn_id,wm.item_id, wm.batch_nbr,im.item_name having count(*) > 1; 

select wm.wm_inventory_id,wm.on_hand_qty,wm.wm_allocated_qty,wm.to_be_filled_qty,ic.item_name,ic.item_id from wm_inventory wm, item_cbo ic
where location_id in ('0008181') and wm.item_id=ic.item_id and item_name in ('126H445 B 0-3'); 
