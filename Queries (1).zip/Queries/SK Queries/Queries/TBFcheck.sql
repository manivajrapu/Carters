alter session set current_schema = DM;
Select * from dm.locn_hdr where dsp_locn ='PDF0109 C03'; -- A T
select * from wm_inventory  where location_id='100336567';
select to_be_filld_cases, pack_qty, pick_locn_dtl_id,item_id from pick_locn_dtl where locn_id='100336567';

select * from pick_locn_dtl where locn_id='100336567'; -- item 2195964

select * from task_dtl where task_genrtn_ref_nbr='201702160031' and stat_code<90;
select * from alloc_invn_dtl where task_genrtn_ref_nbr='201702160031' and stat_code<90;

select * from task_dtl where dest_locn_id='100337612' and item_id = '2195964' order by create_date_time desc;
-- mod date time 18-FEB-17 05.16.26.000000000 PM  create 18-FEB-17 03.38.30.000000000 PM
select * from dm.task_dtl where TASK_GENRTN_REF_NBR = '201702220052' and stat_code < 90;
Select * from dm.alloc_invn_dtl where TASK_GENRTN_REF_NBR = '100336567' and stat_code < 90;
-- 99043573  16-FEB-17 08.50.12.000000000 AM	18-FEB-17 03.40.34.000000000 PM
select * from prod_trkg_tran where item_id = '2195964' and module_name = 'Replenish' order by create_date_time desc;
select * from prod_trkg_tran where cntr_nbr = '93572365' order by create_date_time desc;

 select * from wm_inventory where location_id='100336567';
 
 select * from task_dtl where pull_locn_id='100336567';
 
 select * from task_dtl where task_id is null;
 
 select * from carton_hdr where cur_loc_id='100337612';
 
 select * from item_cbo where item_name = '126G368 P 3M';
 
 select * from task_dtl where task_id='60061532';