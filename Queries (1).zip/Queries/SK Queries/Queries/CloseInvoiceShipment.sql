
alter session SET Current_schema=DM;

-----------------------------------------tc_shipment_id from mail---------------------------------------------------------
select tc_shipment_id, shipment_status,SHIPMENT_CLOSED_INDICATOR,LPN_ASSIGNMENT_STOPPED,WMS_STATUS_CODE from shipment where tc_shipment_id='CS31482689';--
--------------------------------------------------------------------------------------------------------------------------

select * from DM.SHIPMENT where TC_SHIPMENT_ID='CS31482689';

