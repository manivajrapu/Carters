alter session set current_schema = DM;


------------for lpn status-------------------------------------

select lpn_facility_status from lpn where tc_lpn_id = '00000197181674744089';--- before packing: 15 ; after packing: 20

-------open task/open allocations------------------------------
select stat_code from task_dtl where carton_nbr = '00000197181345195066' and stat_code<90;--- open tasks
select * from ALLOC_INVN_DTL where carton_nbr =  '00000197181345195066' and stat_code<90;-- open allocations

---------------------------------------------------------------------
--These are retail cartons for PTS (Put to Store)

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and d_facility_alias_id is not null and tc_lpn_id in ('00000197181345226845', '00000197181343188312', '00000197181343748172', '00000197181343303265', '00000197181343303166', '00000197181343753534');

--These are STS cartons (BOSS)

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and misc_instr_code_3 > 0 and d_facility_alias_id is  null and tc_lpn_id in ('00000197181342993214');

---------------------------------------------------------------------