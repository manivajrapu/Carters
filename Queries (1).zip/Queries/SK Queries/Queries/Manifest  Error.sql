alter session SET Current_schema=DM;
----------Manifest Carton Error: weight is invalid for the FedEx Ground residential service
select lane_name, delivery_req, count(*) from dm.orders where ref_field_3 = 'EC' group by lane_name, delivery_req;


--Find aggregate orders in released status with cartons printed, packed, etc..
select tc_order_id, do_status, store_nbr from dm.orders o where order_type = 'SD' and do_status = 109 and exists (select 1 from dm.lpn l where l.order_id = o.order_id and l.lpn_facility_status < 90);
--Identify child orders bringing aggregated down to released (110)
select unique o.tc_order_id, o.do_status, o.parent_order_id, o2.tc_order_id, o2.do_status
from dm.orders o, dm.orders o2 where o.parent_order_id = o2.tc_order_id and o2.order_type = 'SD' and o.do_status = 109 and o2.do_status = 109;
