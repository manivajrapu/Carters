alter session SET Current_schema=DM;
--------------------------------------------------Scenario 1 Database Error {0}::{1}:{2}-----------------------------------------------------------

select td.task_id, th.stat_code "Hdr Status", td.stat_code "Dtl Status", td.QTY_ALLOC, td.QTY_PULLD 
from task_hdr th, task_dtl td where th.task_id = td.task_id and td.task_id = '57396886';    --hdr status and dtl status 'll be different

select task_id, QTY_ALLOC, QTY_PULLD, stat_code from task_dtl where stat_code < 90 and task_id = any ('57396886');

-- Update the stat code to 99 use following query through ccf:

--	Update task_dtl set QTY_ALLOC = 0, QTY_PULLD = 0, stat_code = 99 where stat_code < 90 and task_id = any ('57396886');

select task_id, stat_code from task_hdr where task_id = any ('57396886');

--Update the task_hdr status to 99 use following query through ccf:

---	update task_hdr set stat_code = 99 where task_id = any ('57396886');

-----------------------------------------------------------------Scenario 2 Allocated for order can't be de-allocated-------------------------------


select tc_lpn_id,lpn_facility_status, inbound_outbound_indicator from lpn where tc_lpn_id in ('970087834570', '970087660807', '970087834564', '970087834572', '970087926163', '970087834565', '970087948154', '970087989973', '970087989974', '970087989964', '970087989965', '970087989975', '970087989967', '970087989966', '970087989971', '970088006696', '970088006698', '970088006701', '970087778908');
select * from alloc_invn_dtl where cntr_nbr in ('970087834570', '970087660807', '970087834564', '970087834572', '970087926163', '970087834565', '970087948154', '970087989973', '970087989974', '970087989964', '970087989965', '970087989975', '970087989967', '970087989966', '970087989971', '970088006696', '970088006698', '970088006701', '970087778908') and stat_code<'90';--1
select * from task_dtl where cntr_nbr in ('970087834570', '970087660807', '970087834564', '970087834572', '970087926163', '970087834565', '970087948154', '970087989973', '970087989974', '970087989964', '970087989965', '970087989975', '970087989967', '970087989966', '970087989971', '970088006696', '970088006698', '970088006701', '970087778908') and stat_code<'90';--746

--distinct open tasks
select distinct task_id,cntr_nbr from 
task_dtl where stat_code < 90 and cntr_nbr in ('970100005142', '970100002374', '970100004728', '970100001938', '00000156740059003666', '970100001822', '970100004780', '970100000561', '970100000415', '970100005793', '970100003002', '970100002431', '970100005191', '00000156740059003659', '970100005239', '970100004684', '970100000401', '970100004365', '970100000771', '970100000467'); 

select task_id,cntr_nbr,stat_code from task_dtl where task_id in ('86511755');

--any open cartons <20
select ic.item_bar_code, ic.item_name, aid.batch_nbr, aid.qty_alloc, aid.cntr_nbr, aid.stat_code, aid.carton_nbr, lfs.description, l.lpn_facility_status LFS, l.chute_id, aid.mod_date_time
from item_cbo ic, alloc_invn_dtl aid, lpn l, lpn_facility_status lfs
where  aid.item_id = ic.item_id and aid.carton_nbr = l.tc_lpn_id
and l.inbound_outbound_indicator = lfs.inbound_outbound_indicator and l.lpn_facility_status = lfs.lpn_facility_status
and aid.cntr_nbr in ('99018920')
and aid.stat_code < '90'
order by aid.carton_nbr asc;

select * from sys_code where code_type in ('CCF');


