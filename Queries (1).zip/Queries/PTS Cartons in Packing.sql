alter session set current_schema = DM;


------------for lpn status-------------------------------------

select lpn_facility_status from lpn where tc_lpn_id = '00000156741219930358';

-------open task/open allocations------------------------------
select stat_code from task_dtl where carton_nbr = '00000156741219930358' and stat_code<90;
select * from ALLOC_INVN_DTL where carton_nbr  '00000197181328901714' and stat_code<90;

---------------------------------------------------------------------
---------------------------------------------------------------------