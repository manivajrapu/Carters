alter session set current_schema=DM;

select * from task_hdr where task_id in ('71971288');

select TASK_ID, START_CURR_WORK_AREA,START_CURR_WORK_GRP from task_hdr where task_id in ('71971288');

select task_id, cntr_nbr, pull_locn_id from dm.task_dtl where task_id = '71971288' and stat_code < 90 order by task_seq_nbr asc;

select work_grp, work_area from locn_hdr where locn_id = '100169207';