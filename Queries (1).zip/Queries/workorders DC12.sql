  select ORD_TYPE, ACCT_RCVBL_ACCT_NBR, CARTON_CUBNG_INDIC from pkt_hdr where CUST_PO_NBR in ('160721'); --take from mail or attachment

select phi.STAT_CODE, ph.ORD_TYPE, ph.PKT_CTRL_NBR, ph.CUST_PO_NBR, ph.ACCT_RCVBL_ACCT_NBR, ph.CARTON_CUBNG_INDIC from pkt_hdr ph, pkt_hdr_intrnl phi 
 where ph.ACCT_RCVBL_ACCT_NBR = '800012' 
   and ph.ord_type = 'RP' 
   and ph.CARTON_CUBNG_INDIC = '51'
   and ph.PKT_CTRL_NBR = phi.PKT_CTRL_NBR
   and phi.STAT_CODE < 90;
   
--after that create ccf.
   
