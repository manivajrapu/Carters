 alter session SET Current_schema=DM;

select * from locn_hdr where dsp_locn in ('PE25009A05');
620497531
620502461
620502462
select * from pick_locn_dtl where locn_id = '100352955';
select to_be_filled_qty, on_hand_qty, wm_allocated_qty, last_updated_dttm from wm_inventory where location_id IN  ('620502461');


SElect * from task_dtl where pull_locn_id IN ('100408718') AND STAT_CODE<90;
select * from alloc_invn_dtl where pull_locn_id in ('100408718') and stat_code<90 ;


select to_be_filled_qty,on_hand_qty, wm_allocated_qty from wm_inventory where location_id='100408718' ;
select * from item_cbo where item_name='118H111 N 18M';

select * from locn_hdr where dsp_locn in ('PE30501A02');
select * from pick_locn_dtl where first_wave_nbr='201706070003' and pikng_lock_code='AB';
select to_be_filled_qty, on_hand_qty, wm_allocated_qty from wm_inventory where location_id IN ('100408718');

select * from locn_hdr where dsp_locn='PDF0336B01';
select * from pick_locn_dtl where first_wave_nbr='201612050077' and pikng_lock_code='AB';
select to_be_filled_qty, on_hand_qty, wm_allocated_qty from wm_inventory where location_id='100386856';----------620497531,620502461

select * from task_hdr where locn_hdr_id='620497540';

select * from locn_hdr where locn_id='100338700';
SElect * from task_dtl where pull_locn_id IN ('100127691') AND STAT_CODE<90;
SELECT * from task_dtl where pull_locn_id='620502462';

select * from alloc_invn_dtl where pull_locn_id in ('100359282') and stat_code<90 ;




select * from task_dtl where task_id='54784678';

select * from pick_locn_hdr;

select distinct(batch_nbr) from task_dtl where task_id='54869657';
select * from alloc_invn_dtl where cntr_nbr='970054869657';

select tc_lpn_id, lpn_facility_status from lpn where tc_lpn_id in ('00006644549887614196','00007160419047003903');
select * from alloc_invn_dtl where cntr_nbr in  ('00006644549887614196','00007160419047003903') and stat_code<'90';
select * from task_dtl where cntr_nbr in  ('00006644549887614196','00007160419047003903') and stat_code<'90';
select * from wm_inventory where tc_lpn_id in ('00006644549887614196','00007160419047003903'); 

select actl_invn_cases, to_be_filld_cases from pick_locn_dtl;

select * from locn_hdr where area='P' and lvl='D' and aisle='26';

select * from lpn_lock;

select * from shipment;

select * from stop_status

select * from stop_action

select * from stop_action_order

select * from stop_action_shipment

select * from stop_off_charge

select * from stop_action_order_template




select * from locn_hdr where area='P' and lvl='D' and aisle='26';

select actl_invn_cases, to_be_filld_cases from pick_locn_dtl;

select * from pick_locn_dtl;

select * from task_hdr;

select * from alloc_invn_dtl where stat_code<'90';

select lpn_facility_status, manifest_nbr, tc_order_id, tc_shipment_id from lpn where tc_lpn_id='00000197181433873142';

select tc_shipment_id from orders where tc_order_id='1213883969';

SELECT order_status FROM ORDERS where tc_order_id='1213883969';

select * from prod_trkg_tran where cntr_nbr = '00000197181433873142' order by create_date_time desc;

select tc_shipment_id, tc_order_id, tc_lpn_id from lpn where tc_order_id = '1213883969' and lpn_facility_status < 40;

-- 22-MAY-16 12.26.32.846000000 PM
select * from prod_trkg_tran where tc_order_id = '1213883969' order by create_date_time desc;

alter session set NLS_DATE_FORMAT = 'dd.mm.yy hh24:mi:Ss';

select * from DM.MANIFESTED_LPN where TC_LPN_ID = '00000197181433873142';


select pick_detrm_zone "Area", (select code_desc from sys_code where rec_type = 'B' and code_type = '330' and code_id = pick_locn_assign_zone) "Zone",
listagg(lh.dsp_locn,',') within group (order by lh.dsp_locn) "Location List",
count(*) "Locations", sum(nvl(locn_count,0)) "In Use", to_char(sum(nvl(locn_count,0))/count(*)*100,'999')||'%' "In Use %",
min(last_wave_nbr) "Oldest Wave", max(last_wave_nbr) "Newest Wave",
sum(on_hand_qty) "On Hand", sum(to_be_filled_qty) "To Be Filled", sum(wm_allocated_qty) "To Be Picked"
from locn_hdr lh, pick_locn_hdr plh,
(select pld.locn_id, max(lh.locn_pick_seq) locn_pick_seq, max(dsp_locn) dsp_locn, count(*) LOCN_COUNT , max(last_wave_nbr) last_wave_nbr,
 sum(on_hand_qty) on_hand_qty, sum(to_be_filled_qty) to_be_filled_qty, sum(wm_allocated_qty) wm_allocated_qty
from pick_locn_dtl pld, wm_inventory wi, locn_hdr lh
 where pld.pick_locn_dtl_id = wi.location_dtl_id
and pld.locn_id = lh.locn_id
and (on_hand_qty<>0 or to_be_filled_qty <> 0 or wm_allocated_qty <> 0)
group by  pld.locn_id
) pld
where lh.locn_id = plh.locn_id
and plh.locn_id = pld.locn_id (+)
and last_wave_nbr = '201704260097' and to_be_filled_qty <> 0
group by pick_detrm_zone, pick_locn_assign_zone
order by pick_detrm_zone, "Zone";

jon-------
WITH alloc AS (
SELECT pull_locn_id, item_id, batch_nbr, sum(qty) qty FROM (
SELECT pull_locn_id, item_id, batch_nbr, qty_alloc-qty_pulld qty
FROM task_dtl WHERE stat_code < 40 AND pull_locn_id IN (SELECT location_id FROM wm_inventory WHERE locn_class = 'C') 
UNION ALL
SELECT pull_locn_id, item_id, batch_nbr, qty_alloc-qty_pulld qty
FROM alloc_invn_dtl WHERE stat_code < 40 AND pull_locn_id IN (SELECT location_id FROM wm_inventory WHERE locn_class = 'C') )
GROUP BY pull_locn_id, item_id, batch_nbr)
SELECT dsp_locn, locn_brcd, area, ZONE, aisle, bay, lvl "LEVEL", posn "POSITION", item_name, qty AS alloc_qty_from_task, wm_allocated_qty 
FROM alloc, wm_inventory wi, locn_hdr lh, item_cbo ic
WHERE wi.location_id = alloc.pull_locn_id
AND wi.location_id = lh.locn_id
AND wi.item_id = ic.item_id
AND wi.item_id = alloc.item_id
AND wi.batch_nbr = alloc.batch_nbr
AND qty <> wm_allocated_qty;


select LH.LOCN_BRCD,lh.area, lh.zone, lh.aisle, lh.bay, lh.lvl, lh.posn 
from wm_inventory wi
join locn_hdr lh on lh.locn_id = wi.location_id
where wi.to_be_filled_qty > 0 and wi.location_id not in (
  select dest_locn_id
  from task_dtl where invn_need_type = 9 and stat_code < 90)
and lh.locn_class = 'C';
