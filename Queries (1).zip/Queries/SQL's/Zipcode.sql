alter session set current_schema=wmprod33;

select ph.pkt_ctrl_nbr, 
       ph.whse, ph.shipto, 
       ph.shipto_name, 
       ph.shipto_addr_1, 
       ph.shipto_addr_2, 
       ph.shipto_addr_3, 
       ph.shipto_city, 
       ph.shipto_zip,
       phi.stat_code,
       sm.addr_id,
       adr.addr_key_1,
       adr.addr_line_1,
       adr.addr_line_2, 
       adr.addr_line_3,
       adr.city,
       adr.state,
       adr.zip
from pkt_hdr ph, pkt_hdr_intrnl phi, store_master sm, address adr 
where phi.major_minor_pkt = 'P'
  and phi.pkt_ctrl_nbr = ph.pkt_ctrl_nbr
  and ph.shipto = sm.store_nbr
  and sm.addr_id = adr.addr_id
  and adr.zip is null;
  
  select shipto_zip from pkt_hdr where pkt_ctrl_nbr in ('3400000284');
  select zip from address where addr_id in ('8432');
  select rte_zip from store_master where addr_id in ('8432');
