--Change control for DC12 Repacks-----------------------------------------------


alter session SET Current_schema=DM;

----------------------------------------------------------------------------------

select tc_order_id, ext_purchase_order from orders where ext_purchase_order = 'PGA bodysuits 030322';

select do_status,tc_order_id,order_id,REF_FIELD_3 from dm.orders where ext_purchase_order in ('259150', '259151', '259152', '259153', '259154', '259155', '259156', '259157', '259159', '259158');

select * from order_note where order_id in ('1210886705');

select vas_process_type,price_tkt_type from order_line_item  where order_id in(select order_id from orders where ref_field_3 = 'RP' and 
do_status = '110' and
tc_order_id in ('1211893346', '1211844088', '1211844089', '1211893347', '1211893348', '1211844090', '1211844091', '1211893350', '1211893349', '1211893351', '1211893352', '1211837768', '1211895624', '1211893353'));

select lpn_cubing_indic,pre_pack_flag,LAST_UPDATED_DTTM from orders where TC_ORDER_ID in ('1211893346', '1211844088', '1211844089', '1211893347', '1211893348', '1211844090', '1211844091', '1211893350', '1211893349', '1211893351', '1211893352', '1211837768', '1211895624', '1211893353');


----------------------------------------------------------------------------------


select do_status,tc_order_id,order_id,REF_FIELD_3 from dm.orders where ext_purchase_order in ('188114','188115');--1237297582
--1
select * from orders where tc_order_id in ('1237541172');--1237541171,1237541172
select * from order_note where order_id in ('132606313', '132606301', '132606302', '132606307', '132606308', '132606303', '132606304', '132606306', '132606309', '132606310', '132606311', '132606305', '132615311', '132606312');--81025065,81025015
 select tc_order_id from orders where order_id in ('80112227');
 
select o.order_id, '1', 'VS', 'Remove Bag - Vas', '0', null, '0', oli.line_item_id, 'EC' from dm.orders o, dm.order_line_item oli where ref_field_3 = 'RP' and 
do_status = '110' and o.order_id = oli.order_id and o.tc_order_id in ('1237541172','1237541171')
and o.order_id not in(select order_id from dm.order_note);

select o.order_id, '2', 'VS', 'UPC Sticker Required', '0', null, '0', oli.line_item_id, 'VB' from dm.orders o, dm.order_line_item oli where ref_field_3 = 'RP' and 
do_status = '110' and o.order_id = oli.order_id and o.tc_order_id in ('1237541172','1237541171')
and o.order_id not in(select order_id from dm.order_note);
 --6

select lpn_facility_status, tc_lpn_id, tc_order_id, manifest_nbr from lpn where tc_lpn_id in ('00000197183968879507');

select ESD.els_tran_id,ESH.LOGIN_USER_ID,ESH.SCHED_START_DATE,ESH.ACTUAL_END_DATE, 
JF.NAME JOB_FUNCTION,LA.NAME ACTIVITY,LT.DESCRIPTION, 
ELM.DESCRIPTION Element,ESD.PFD_SAM,esd.TOTAL_SAM, esd.uom_qty 
FROM 
dm.E_EVNT_SMRY_HDR ESH 
LEFT join dm.E_EVNT_SMRY_ELM_DTL ESD on ESH.ELS_TRAN_ID = ESD.ELS_TRAN_ID  
LEFT join dm.E_ELM ELM on ELM.ELM_ID = ESD.ELM_ID 
LEFT join dm.e_act_elm AE on ELM.ELM_ID = AE.ELM_ID  
LEFT JOIN DM.E_ACT A ON ESH.ACT_ID = A.ACT_ID AND A.ACT_ID = AE.ACT_ID 
LEFT JOIN DM.E_MSRMNT U ON U.MSRMNT_ID = ELM.MSRMNT_ID 
LEFT JOIN DM.LABOR_ACTIVITY LA ON LA.LABOR_ACTIVITY_ID = A.LABOR_ACTIVITY_ID 
LEFT JOIN DM.E_JOB_FUNCTION JF ON JF.JOB_FUNC_ID = A.JOB_FUNC_ID 
LEFT JOIN DM.E_LABOR_TYPE_CODE LT ON ESH.LABOR_TYPE_ID = LT.LABOR_TYPE_ID 
Where ESH.SCHED_START_DATE > sysdate - 15 
and ESH.SCHED_START_DATE < sysdate - 1 

and JF.NAME = 'OSR PACKOUT' 
GROUP BY JF.NAME, LA.NAME, ELM.DESCRIPTION,LT.DESCRIPTION,  
ESD.els_tran_id,ESH.LOGIN_USER_ID,ESH.SCHED_START_DATE,ESH.ACTUAL_END_DATE,ESD.PFD_SAM,esd.TOTAL_SAM, esd.uom_qty;

select * from order_note where note like '%Rehand - VAS%';
select lpn_cubing_indic,pre_pack_flag,LAST_UPDATED_DTTM from orders where TC_ORDER_ID in ('1237017943', '1237017944', '1237017945', '1237017946', '1237017947', '1237017948', '1237017949', '1237017950', '1237017951');
select vas_process_type,price_tkt_type from order_line_item  where order_id in(select order_id from orders where ref_field_3 = 'RP' and 
do_status = '110' and
tc_order_id in ('1237541172','1237541171'));

select order_id from orders where ref_field_3 = 'RP' and do_status = '110' and
tc_order_id in ('1236958522');



select * from order_note where NOTE like '%Rehang - VAS%'; 

select o.order_id, '1', 'VS', 'Rehang - VAS', '0', null, '0', oli.line_item_id, 'VB' from dm.orders o, dm.order_line_item oli where ref_field_3 = 'RP' and 
do_status = '110' and o.order_id = oli.order_id and o.tc_order_id in ('1237541171','1237541172')
and o.order_id  in(select order_id from dm.order_note);

select vas_process_type,price_tkt_type from order_line_item  where order_id in(select order_id from orders where ref_field_3 = 'RP' and 
do_status = '110' and
  tc_order_id in ('1237541172','1237541171'));
  
  select lpn_cubing_indic,pre_pack_flag,LAST_UPDATED_DTTM from orders where TC_ORDER_ID in ('1237541171','1237541172');
  
  select vas_process_type,price_tkt_type from order_line_item  where order_id in(select order_id from orders where ref_field_3 = 'RP' and 
do_status = '110' and
tc_order_id in ('1237541171','1237541172'));
