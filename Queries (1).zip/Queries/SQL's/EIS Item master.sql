alter session SET Current_schema=wmprod33;



select distinct error_seq_nbr, proc_stat_code from inpt_item_whse_master;-- take the error_seq_nbr and give in below statement
select * from msg_log where ref_value_1 in ('227084866'); --to check the error message

select * from V$SQL where SQL_TEXT like '%select * from msg_log%';--5dnyfafdt3xz5

select distinct style from inpt_item_master; --take style and give in below stmt
select * from item_master where style in ('19583810', '19584010', '19584210', '19584410', '19584610', '19584810', '19585310', '19585510', '19585710', '19585910', '19586710', '19587110', '19587510', '19587910', '19932110', '19932310', '19932510', '19932710', '1G897310', '1G897410', '1G897510', '1G897710', '1G898910', '1G898911', '1G898912', '1G899110', '1G904410', '1G904411', '1G904510', '1G905610', '1H571810', '29931710', '29932110', '29932310', '29932510', '29932710', '2G897310', '2G897410', '2G897510', '2G897710', '2G898910', '2G898911', '2G898912', '2G899110', '2G899210', '2G904410', '2G904411', '2G904510', '2H561710', '39931710', '39932110', '39932310', '39932510', '39932710', '3G897010', '3G897410', '3G897610', '3G897810', '3G898910', '3G898911', '3G898912', '3G899110', '3G899210', '3G904410', '3G904411', '3G904510', '3H521410', '3H593310'); 

select * from WMPROD33.INPT_IMMD_NEEDS;
