select code_desc fiscal_month, to_char(to_date(substr(code_id,1,6),'YYMMDD'),'YYYY-MM-DD') month_start_date,
  to_char(to_date(substr(code_id,-6,6),'YYMMDD'),'YYYY-MM-DD') month_end_date,to_date(substr(code_id,-6,6),
  'YYMMDD')-to_date(substr(code_id,1,6),'YYMMDD')+1 days_in_month from sys_code
where code_type = 'FCM';


select o.DC_ctr_nbr,ol.tc_lpn_id carton,  o.bill_to_fax_number event,
  wms.spl_instr_2 zone,
  to_char(trunc(ol.shipped_dttm),'MM-DD-YYYY') shipped_date,
  sum(size_value) total_units_shipped
  from outpt_lpn ol, outpt_lpn_detail old, item_cbo ic, orders o, item_wms wms
where ol.tc_lpn_id=old.tc_lpn_id and ol.invc_batch_nbr = old.invc_Batch_Nbr
and old.item_id=ic.item_id and ol.tc_order_id=o.tc_order_id 
and ic.item_id=wms.item_id
and trunc(ol.shipped_dttm)>=to_date('2019-10-27','YYYY-MM-DD')
and trunc(ol.shipped_dttm)<=to_date('2019-11-23','YYYY-MM-DD')
and o.acct_rcvbl_acct_nbr='249380'
--and ol.created_DTTM >= sysdate -2
group by o.dc_ctr_nbr,ol.tc_lpn_id,
  o.bill_to_fax_number ,wms.spl_instr_2,
  to_char(trunc(ol.shipped_dttm),'MM-DD-YYYY');
