alter session set current_schema = DM;

Select shipment_status, shipment_closed_indicator, lpn_assignment_stopped, wms_status_code from shipment where tc_shipment_id='CS22330852';

select * from LPN where lpn_id='00000197181540241629';

select * from orders where order_id='1219533366';

select * from lpn where  = '000000113618';

select * from lpn where tc_lpn_id='00000197181537234030' and inbound_outbound_indicator='I'; 


select tc_order_id, store_nbr, d_facility_alias_id, major_order_grp_attr, dc_ctr_nbr, created_dttm, last_updated_dttm, do_status
from orders where do_status < 190 and store_nbr != substr(d_facility_alias_id, -4) and order_type = 'SD';

