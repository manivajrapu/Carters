alter session SET Current_schema=DM;

--SQL to check
select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status < 190 and lpn_facility_status = 90 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status < 80 );

select * from shipment where tc_shipment_id in('CS46171727','CS46166924','CS46151567');

select tc_lpn_id, tc_order_id, tc_shipment_id, lpn_facility_status from lpn where tc_lpn_id in('00000197181745968017','00000197181751395944');
 
select SHIPMENT_STATUS, SHIPMENT_CLOSED_INDICATOR, LPN_ASSIGNMENT_STOPPED, WMS_STATUS_CODE from shipment where tc_shipment_id = 'CS43482638'; 

select * from sys_code where code_type in ('CCF');