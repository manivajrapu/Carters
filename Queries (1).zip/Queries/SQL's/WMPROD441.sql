--RUN FROM OMNIA
--DC12 COMPARE
Select  x.*, iw.onhandqty cur_oh, iw.notavailqty cur_NA,
(case when lpn.lpn_status = '45'
then 'LPN '||lpn.col||' '||lpn.dsp_locn
       when lpn.lpn_status = '70'
then 'Consumed with null units'
 when lpn.lpn_status = '100'
then 'PSORT Issue?'
     when uns.lpn_status is not null
then uns.lpn_status
when mes.lpn_status is not null
then mes.lpn_status
when msb.lpn_status is not null
then msb.lpn_status
when np.lpn_status is not null
then np.lpn_status
when lis.lpn_status is not null
then lis.lpn_status
    when om_oh=0 and wm_oh<0
then 'WM went Neg'
     when    o2.lpn_status is not null
then    o2.lpn_status
 when wm_oh=0 and om_oh>0
then 'WM fixed neg issue man adjust' 
 when iw.onhandqty=wm_oh and wm_na=iw.notavailqty
then 'Late Post'
else null  
END) issue  , 
col,
dsp_locn,
/*(CASE WHEN ms.carton_or_distro IS NOT null
THEN MS.CARTON_OR_DIsTRO
WHEN mes.carton_or_distro IS NOT NULL
THEN MES.CARTON_OR_DISTRO 
ELSE NULL) DETAIL,*/
(Case when lpn.units <>0
then lpn.units
       when uns.units<>0
then uns.units
      when o2.units<>0
then o2.units
else
  null end  )  units
   from (select
    coalesce(WM.SKU, OM.SKU) SKU,
    nvl(OM.OM_OH_QTY,0) OM_OH, 
    nvl(OM.OM_DEL_INV_QTY,0) OM_DEL_INV, 
    nvl(WM.OH,0) WM_OH,
    nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0)) OH_VAR,
    nvl(OM.OM_HELD_QTY,0) OM_NA, 
    nvl(WM.NA,0) WM_NA,
    nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0) NA_VAR
from 
(
    select coalesce(oh.sku, na.sku) SKU, nvl(oh.oh_qty,0) + nvl(na.na_qty,0) as OH, nvl(na.na_qty,0) NA, coalesce(oh.dt, na.dt) dt
    from (
        select pt.style || '_'||pt.color|| '_'||pt.size_desc || decode(pt.batch_nbr,'DFLT',decode(pt.style_sfx,null,null,'_'||pt.style_sfx),'_'||pt.batch_nbr)  SKU, pt.invn_adjmt_qty oh_qty, trunc(pt.create_date_time) dt, pt.*
        from DM.PIX_TRAN@WMOS12LINK.WORLD pt
        where pt.TRAN_TYPE='605'
        and pt.tran_code='97'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) OH
    full outer join (
        select pt.style || '_'||pt.color|| '_'||pt.size_desc || decode(pt.batch_nbr,'DFLT',decode(pt.style_sfx,null,null,'_'||pt.style_sfx),'_'||pt.batch_nbr)  SKU, pt.invn_adjmt_qty na_qty, trunc(pt.create_date_time) dt
        from DM.PIX_TRAN@WMOS12LINK.WORLD pt
        where pt.TRAN_TYPE='605'
        and pt.tran_code='98'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) NA
    on NA.SKU = OH.SKU
) WM
full outer join (
    select 
        coalesce(av.style ||'_'|| av.color ||'_'|| av.size_desc|| case when av.sec_dim = av.color then '' else '_'||av.sec_dim end , hi.style ||'_'|| hi.color || '_'|| hi.size_desc||case when hi.sec_dim = hi.color then '' else '_'||hi.sec_dim end ) as SKU, 
        coalesce(trunc(av.create_date_time), trunc(hi.create_date_time)) snap_date, 
        nvl(av.invn_adjmt_qty,0) OM_OH_QTY, nvl(di.invn_adjmt_qty,0) OM_DEL_INV_QTY, nvl(hi.invn_adjmt_qty,0) OM_HELD_QTY
    from 
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='97') av
    left outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time)= to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='96') di
    on di.style = av.style and di.color = av.color and av.size_desc = di.size_desc and di.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(di.create_date_time)
    full outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='98') hi
    on hi.style = av.style and hi.color = av.color and av.size_desc = hi.size_desc and hi.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(hi.create_date_time)
) OM
    on OM.SKU=WM.SKU
where 
    (nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0))) <> 0
    or (nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0)) <> 0) x
left outer join invwhsum iw on prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)=x.sku
LEFT OUTER JOIN (select  DISTINCT lpn_status, LISTAGG(carton_number,',') within group (order by carton_number) as col, LISTAGG(dsp_locn,',') within group (order by dsp_locn) dsp_locn,item,sum(units) units from (
select distinct L.LPN_STATUS lpn_status,TC_LPN_ID carton_number,NULL DSP_LOCN, ic.item_style||'_'||ic.item_color||'_'||ic.item_size_desc||decode(ld.batch_nbr,'DFLT',decode(ic.item_style_sfx,null,null,'_'||ic.item_style_sfx),'_'||ld.batch_nbr) item,LD.size_value units from 
dm.lpn_detail@WMOS12LINK.WORLD ld
join dm.lpn@WMOS12LINK.WORLD l on ld.lpn_id=l.lpn_id
join dm.item_cbo@WMOS12LINK.WORLD ic on ic.item_id=ld.item_id
join (select item_id, batch_nbr from dm.pix_tran@WMOS12LINK.WORLD where tran_type='605' and trunc(mod_date_time)=trunc(sysdate)) pt on pt.item_id=ld.item_id and pt.batch_nbr=ld.batch_nbr
--join dm.locn_hdr lh on lh.locn_id=l.curr_sub_locn_id
where L.LPN_STATUS='70' AND LPN_FACILITY_STATUS='95'
AND SIZE_VALUE IS NULL
--AND l.inbound_outbound_indicator='I'
UNION
select distinct l.lpn_status,l.tc_lpn_id,lh.dsp_locn, ic.item_style||'_'||ic.item_color||'_'||ic.item_size_desc||decode(ld.batch_nbr,'DFLT',decode(ic.item_style_sfx,null,null,'_'||ic.item_style_sfx),'_'||ld.batch_nbr) item,   ld.size_value from 
dm.lpn_detail@WMOS12LINK.WORLD ld
join dm.lpn@WMOS12LINK.WORLD l on ld.lpn_id=l.lpn_id
join dm.item_cbo@WMOS12LINK.WORLD ic on ic.item_id=ld.item_id
join dm.locn_hdr@WMOS12LINK.WORLD lh on lh.locn_id=l.curr_sub_locn_id
join (select item_id, batch_nbr from dm.pix_tran@WMOS12LINK.WORLD where tran_type='605' and trunc(mod_date_time)=trunc(sysdate)) pt on pt.item_id=ld.item_id and pt.batch_nbr=ld.batch_nbr
where l.tc_lpn_id like '97%'
and l.lpn_status='45' and l.inbound_outbound_indicator='I'
and l.total_lpn_qty=0 and ld.size_value<>0
and lh.dsp_locn like 'USM%'
union
select 100 lpn_status,
null,
null,
ic.item_style||'_'||ic.item_color||'_'||ic.item_size_desc||decode(wi.batch_nbr,'DFLT',decode(ic.item_style_sfx,null,null,'_'||ic.item_style_sfx),'_'||wi.batch_nbr) item,
sum(on_hand_qty) units
from dm.wm_inventory@WMOS12LINK.WORLD wi
join dm.item_cbo@WMOS12LINK.WORLD ic on wi.item_id=ic.item_id
join dm.locn_hdr@WMOS12LINK.WORLD lh on wi.location_id=lh.locn_id
join (select item_id, batch_nbr from dm.pix_tran@WMOS12LINK.WORLD where tran_type='605' and trunc(mod_date_time)=trunc(sysdate)) pt on pt.item_id=wi.item_id and pt.batch_nbr=wi.batch_nbr
where dsp_locn like 'PSORT%' and trunc(last_updated_dttm)< trunc(sysdate)
group by ic.item_style||'_'||ic.item_color||'_'||ic.item_size_desc||decode(wi.batch_nbr,'DFLT',decode(ic.item_style_sfx,null,null,'_'||ic.item_style_sfx),'_'||wi.batch_nbr)) 
group by lpn_status,item) lpn on lpn.item=x.sku
left outer join (select DISTINCT lpn_status, item, shipped units from (select lpn_status, item, applied, shipped from (
select 'Unapplied' lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(st.appliedqty) applied, sum(st.shippedqty) shipped from o2_ech_shipment_tran ST
join prodskus ps on st.produpc= ps.produpc
and st.shippedqty<>st.appliedqty
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode))
where applied<>shipped)) uns on uns.item=x.sku
left outer join  (select distinct MAX(decode(error_text, null,'Not processed in o2_pix_tran','PIX Error: '||error_text)) lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(tranqty) units from o2_pix_tran pt
left outer join o2_pix_tran_error er on pt.esb_batch_number=er.esb_batch_number
join prodskus ps on ps.produpc=pt.produpc
where pt.whsecode='12' 
and transtype<>'620' 
and processed=0 
and tranqty<>0
and trunc(pt.updated_on)>trunc(sysdate-10)
And bypass_code is null
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ) o2 on o2.item=x.sku 
left outer join (select 'Missing ECOM shipment' lpn_status,LISTAGG(wm.orders,',') within group (order by wm.orders) carton_or_distro, wm.item from (
select item_style||'_'||item_color||'_'||item_size_desc||decode(batch_nbr,'DFLT',null,'_'|| batch_nbr) item, ord.tc_order_id orders, trunc(l.shipped_dttm) shipdate
from   dm.outpt_lpn_detail@WMOS12LINK.WORLD ld
  join dm.outpt_lpn@WMOS12LINK.WORLD l on ld.tc_lpn_id=l.tc_lpn_id
  join dm.outpt_orders@WMOS12LINK.WORLD ord on ord.tc_order_id=l.tc_order_id
  where ord.acct_rcvbl_code='EC' and trunc(l.last_updated_dttm)>=trunc(sysdate-7) and trunc(l.last_updated_dttm)<trunc(sysdate)  )wm
left outer join (Select  prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,null,null,'_'|| dimcode) item, trunc(shipdate) ship_date, ship_advice_number orders
 from o2_ech_shipment_tran s
  join prodskus ord on ord.produpc=s.produpc 
  where trunc(shipdate) >=trunc(sysdate-8) and trunc(shipdate) <trunc(sysdate)) st on wm.item=st.item and wm.orders=st.orders
  where st.orders is null and wm.orders is not null
  group by wm.item) mes on mes.item=x.sku
 LEFT OUTER JOIN (select DISTINCT ord.lpn_status, ord.item from (select 'Missing DC12 shipment' LPN_STATUS, l.tc_lpn_id carton, l.invc_batch_nbr btc_nbr,  item_style||'_'||item_color||'_'||item_size_desc||decode(batch_nbr,'DFLT',decode(item_style_sfx,null,null,'_'||item_style_sfx),'_'|| batch_nbr) item
from dm.outpt_lpn@WMOS12LINK.WORLD l 
JOIN DM.OUTPT_LPN_DETAIL@WMOS12LINK.WORLD lD ON L.TC_LPN_ID=LD.TC_LPN_ID
join dm.outpt_orders@WMOS12LINK.WORLD o on o.tc_order_id=l.tc_order_id
where o.acct_rcvbl_code!='EC' and trunc(l.shipped_dttm)>=trunc(sysdate-5) and trunc(l.shipped_dttm)<trunc(sysdate)
AND L.PROC_STAT_CODE=90)ord
left outer join       
(select to_char(pt.container_id) batch_nbr, ht.invoice_batch_number btch_nbr, PT.pick_ticket_number nbr, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ITEM
from omdba.o2_shipment_header_tran HT
JOIN O2_SHIPMENT_PRODUCT_TRAN PT ON PT.HEADER_TRAN_ID=HT.ID
where whsecode='12' and trunc(shipdate)>=trunc(sysdate-5)) dc12 on dc12.batch_nbr=ord.carton AND  DC12.btch_nbr=ORD.btc_nbr
where dc12.batch_nbr is null and ord.carton is not null) MSB ON MSB.ITEM=X.SKU
left outer join (select 'Not processed in o2' lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(shipped_quantity) units
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on ht.id=pt.header_tran_id
where trunc(shipdate)<trunc(sysdate) and trunc(shipdate)>=trunc(sysdate-7)
and ht.whsecode='12' and pt.pix_esb_batch_number is null
--and  prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ='34817710_200_MIX_RF457'
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)) np on np.item=x.sku
left outer join (
select distinct lpn_status, item from (
select distinct location, destination, pallet_id, ilpn, status lpn_status, last_updated, user_id, units, item from (
select lh.dsp_locn as Location, 
LH2.DSP_LOCN AS Destination,
 tc_parent_lpn_id AS Pallet_ID, 
 tc_lpn_id as iLPN,-- td.task_id as Task_ID, 
--decode(td.stat_code, '90', 'Completed', '99', 'Cancelled', '20', 'In Drop Zone', '40', 'In Progress') as TD_Status,
--aid.invn_need_type as INT, 
decode(lpn_facility_status, '45', 'Partially Allocated', '50', 'Allocated', '64', 'Allocated and Pulled') as Status, 
lpn.last_updated_dttm as Last_Updated, 
lpn.last_updated_source as User_ID,
sum(size_value) units, ic.item_style||'_'||ic.item_color||'_'||ic.item_size_desc||decode(ld.batch_nbr,'DFLT',decode(ic.item_style_sfx,null,null,'_'||ic.item_style_sfx),'_'||ld.batch_nbr) as Item
from dm.lpn@WMOS12LINK.WORLD
join dm.lpn_detail@WMOS12LINK.WORLD ld on lpn.lpn_id=ld.lpn_id
join dm.item_cbo@WMOS12LINK.WORLD ic on ic.item_id=ld.item_id
join (select item_id, batch_nbr from dm.pix_tran@WMOS12LINK.WORLD where tran_type='605' and trunc(mod_date_time)=trunc(sysdate)) pt on pt.item_id=ld.item_id and pt.batch_nbr=ld.batch_nbr
left outer join dm.alloc_invn_dtl@WMOS12LINK.WORLD aid on lpn.tc_lpn_id = aid.cntr_nbr
left outer join dm.task_dtl@WMOS12LINK.WORLD td on aid.alloc_invn_dtl_id = td.alloc_invn_dtl_id
join dm.locn_hdr@WMOS12LINK.WORLD lh on lpn.CURR_SUB_LOCN_ID = lh.locn_id
join dm.LOCN_HDR@WMOS12LINK.WORLD LH2 on lpn.DEST_SUB_LOCN_ID = LH2.LOCN_ID
where inbound_outbound_indicator = 'I'
and lpn.lpn_facility_status between '45' and '64'
and lpn.last_updated_dttm <= sysdate -3
group by lh.dsp_locn , 
LH2.DSP_LOCN ,
tc_parent_lpn_id , 
tc_lpn_id ,
lpn.last_updated_dttm , 
lpn.last_updated_source ,
decode(lpn_facility_status, '45', 'Partially Allocated', '50', 'Allocated', '64', 'Allocated and Pulled') ,
ic.item_style||'_'||ic.item_color||'_'||ic.item_size_desc||decode(ld.batch_nbr,'DFLT',decode(ic.item_style_sfx,null,null,'_'||ic.item_style_sfx),'_'||ld.batch_nbr)))) lis on lis.item=x.sku
where iw.whsecode='12' and (x.oh_var<>0 or x.na_var<>0)
order by x.sku
;


--DC33 COMPARE
select distinct * from (
Select x.*, iw.onhandqty cur_ih, iw.notavailqty cur_NA ,
Case  when iw.onhandqty=wm_oh and wm_na=iw.notavailqty
then 'Late Post'
when asn.lpn_status is not null
then asn.lpn_status
 when mp.lpn_status is not null
 then mp.lpn_status
 when md.lpn_status is not null
 then  md.lpn_status
when miss_batch.lpn_status is not null
 then miss_batch.lpn_status
 when un_miss.lpn_status is not null
 then un_miss.lpn_status
 when upp.lpn_status is not null
 then upp.lpn_status
 when und.lpn_status is not null
 then und.lpn_status
 when  unpo2.lpn_status is not null
  then unpo2.lpn_status
 else null end
  reason
 from (select
    coalesce(WM.SKU, OM.SKU) SKU,
    nvl(OM.OM_OH_QTY,0) OM_OH, 
    nvl(OM.OM_DEL_INV_QTY,0) OM_DEL_INV, 
    nvl(WM.OH,0) WM_OH,
    nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0)) OH_VAR,
    nvl(OM.OM_HELD_QTY,0) OM_NA, 
    nvl(WM.NA,0) WM_NA,
    nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0) NA_VAR
from 
(
    select coalesce(oh.sku, na.sku) SKU, nvl(oh.oh_qty,0) + nvl(na.na_qty,0) as OH, nvl(na.na_qty,0) NA, coalesce(oh.dt, na.dt) dt
    from (
        select pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim) SKU, pt.invn_adjmt_qty oh_qty, trunc(pt.create_date_time) dt, pt.*
        from WMPROD33.PIX_TRAN@WMOSLINK pt
        inner join WMPROD33.ITEM_WHSE_MASTER@WMOSLINK iwm
        on iwm.sku_id = pt.sku_id
        where pt.TRAN_TYPE='605'
        and pt.tran_code='97'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) OH
    full outer join (
        select pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim) SKU, pt.invn_adjmt_qty na_qty, trunc(pt.create_date_time) dt
        from WMPROD33.PIX_TRAN@WMOSLINK pt
        inner join WMPROD33.ITEM_WHSE_MASTER@WMOSLINK iwm
        on iwm.sku_id = pt.sku_id
        where pt.TRAN_TYPE='605'
        and pt.tran_code='98'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) NA
    on NA.SKU = OH.SKU
) WM
full outer join (
    select 
         coalesce(av.style ||'_'|| av.color ||'_'|| av.size_desc|| case when av.sec_dim = av.color then '' else '_'||av.sec_dim end , hi.style ||'_'|| hi.color || '_'|| hi.size_desc||case when hi.sec_dim = hi.color then '' else '_'||hi.sec_dim end ) as SKU, 
        coalesce(trunc(av.create_date_time), trunc(hi.create_date_time)) snap_date, 
        nvl(av.invn_adjmt_qty,0) OM_OH_QTY, nvl(di.invn_adjmt_qty,0) OM_DEL_INV_QTY, nvl(hi.invn_adjmt_qty,0) OM_HELD_QTY
    from 
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='97') av
    left outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time)= to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='96') di
    on di.style = av.style and di.color = av.color and av.size_desc = di.size_desc and di.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(di.create_date_time)
    full outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='98') hi
    on hi.style = av.style and hi.color = av.color and av.size_desc = hi.size_desc and hi.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(hi.create_date_time)
) OM
    on OM.SKU=WM.SKU
where 
    (nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0))) <> 0
    or (nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0)) <> 0) x
left outer join invwhsum iw on prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)=x.sku
left outer join (select 'Invoice not processed' lpn_status, style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension) sku, invoicebatchctlnbr asn_invc_nbr,sum(unitspacked) units
from esb_rw.asn_invoice inv
join planes pl on inv.stylesuffix=pl.planesdesc
where pl.divcode='001' and omn_processed<>'SENT TO OMNIA' and warehouse='33' and  trunc(to_date(shipdate,'YYYY-MM-DD HH24:MI:SS'))< TRUNC(SYSDATE) and trunc(to_date(shipdate,'YYYY-MM-DD HH24:MI:SS'))>= TRUNC(SYSDATE-3)
group by style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension), invoicebatchctlnbr) asn on asn.sku=x.sku
left outer join (select 'Missing Units in ordalloc from pick' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select ord.picktktctlnbr pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.picktktctlnbr=pt.pick_ticket_number 
where distro_number is null and pt.pix_esb_batch_number is not null and ht.whsecode='33' and ord.whsecode='33' and ord.distronumber='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) mp on mp.sku=x.sku 
left outer join (select 'Missing from o2 tables' lpn_status,row_id, inv.invoicebatchctlnbr, style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension) item, cartonnbr, pickticketctlnbr, distronumber , created_date
from (select rowid row_id,style, stylesuffix,sizedesc, secdimension ,pickticketctlnbr, distronumber, invoicebatchctlnbr, cartonnbr, warehouse, created_date from esb_rw.asn_invoice where warehouse='33'
and omn_processed='SENT TO OMNIA' and trunc(created_date)>=trunc(sysdate-7) )inv
join planes pl on inv.stylesuffix=pl.planesdesc
where pl.divcode='001' and warehouse='33' and (cartonnbr, style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension), decode(distronumber,null,pickticketctlnbr,distronumber)) not in 
(select container_id, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode), decode(distro_number,null,pick_ticket_number,distro_number) from o2_shipment_product_tran )
order by style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension)) md on md.item=x.sku 
left outer join (select 'Missing Batch' lpn_status, pt.invc_batch_nbr, pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim) item, sum(units_pakd) units
from wmprod33.outpt_carton_dtl@WMOSLINK pt
 join WMPROD33.ITEM_WHSE_MASTER@WMOSLINK iwm  on iwm.sku_id = pt.sku_id
 join (select sku_id from wmprod33.pix_tran@WMOSLINK where tran_type='605' and tran_code='97' and trunc(mod_date_time)=trunc(sysdate)) px on px.sku_id=pt.sku_id
       where  trunc(pt.mod_date_time)=trunc(sysdate-1) 
         and pt.invc_batch_nbr not IN (SELECT INVOICEBATCHCTLNBR FROM ESB_RW.asn_invoice WHERE WAREHOUSE='33')
       and pt.proc_stat_code='90'
       group by pt.invc_batch_nbr, pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim)) miss_batch on miss_batch.item=x.sku 
left outer join (select 'Missing Units in ordalloc from distro' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select ord.distronumber pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord 
on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.distronumber=pt.distro_number 
where distro_number is not null and ht.whsecode='33' and ord.whsecode='33' and ord.distronumber!='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is not null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) un_miss on un_miss.sku=x.sku        
left outer join (select 'Unprocessed Pick' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select ord.picktktctlnbr pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.picktktctlnbr=pt.pick_ticket_number 
where distro_number is null and pt.pix_esb_batch_number is  null and ht.whsecode='33' and ord.whsecode='33' and ord.distronumber='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) upp on upp.sku=x.sku   
left outer join (select distinct 'Unprocessed distro' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select distinct ord.distronumber pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord 
on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.distronumber=pt.distro_number 
where distro_number is not null and ht.whsecode='33' and ord.whsecode='33' and ord.distronumber!='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) und on und.sku=x.sku
LEFT OUTER JOIN (select distinct 'Not processed out from 02_pix_tran' lpn_status, sku from  (select prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'|| dimcode) sku, pt.esb_batch_number, trandate,tranqty, pt.picktktctlnbr, pt.distronumber from o2_pix_tran pt
join prodskus ps on ps.produpc= pt.produpc
where transtype='910' and processed=0)) unpo2 on  unpo2.sku=x.sku
where iw.whsecode='33')
order by sku
;


--DC46 COMPARE
Select  x.*, iw.onhandqty cur_oh, iw.notavailqty cur_NA,
(case when    o2.lpn_status is not null
then    o2.lpn_status
when    MSB.lpn_status is not null
then    MSB.lpn_status
when    NP.lpn_status is not null
then    NP.lpn_status
 when wm_oh=0 and om_oh>0
then 'WM fixed neg issue man adjust' 
 when iw.onhandqty=wm_oh and wm_na=iw.notavailqty
then 'Late Post'
else null  
END) issue  
   from (select
    coalesce(DM.SKU, OM.SKU) SKU,
    nvl(OM.OM_OH_QTY,0) OM_OH, 
    nvl(OM.OM_DEL_INV_QTY,0) OM_DEL_INV, 
    nvl(DM.OH,0) WM_OH,
    nvl(DM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0)) OH_VAR,
    nvl(OM.OM_HELD_QTY,0) OM_NA, 
    nvl(DM.NA,0) WM_NA,
    nvl(DM.NA,0) - nvl(OM.OM_HELD_QTY,0) NA_VAR
from 
(
    select coalesce(oh.sku, na.sku) SKU, nvl(oh.oh_qty,0) + nvl(na.na_qty,0) as OH, nvl(na.na_qty,0) NA, coalesce(oh.dt, na.dt) dt
    from (
        select     CASE
        WHEN length(style_sfx) < 4   THEN pt.style || style_sfx
        ELSE pt.style
    END
    || '_'
    || pt.color
    || '_'
    || pt.size_desc
    || CASE
        WHEN length(style_sfx) < 4
             AND pt.batch_nbr = 'DFLT' THEN NULL
        WHEN length(style_sfx) > 4 and pt.batch_nbr = 'DFLT' THEN '_' || pt.style_sfx
        WHEN style_sfx is null and pt.batch_nbr = 'DFLT' then null
        ELSE '_' || pt.batch_nbr end SKU, pt.invn_adjmt_qty oh_qty, trunc(pt.create_date_time) dt, pt.*
        from DM.PIX_TRAN@WMOS46LINK.WORLD pt
        where pt.TRAN_TYPE='605'
        and pt.tran_code='97'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) OH
    full outer join (
        select     CASE
        WHEN length(style_sfx) < 4   THEN pt.style || style_sfx
        ELSE pt.style
    END
    || '_'
    || pt.color
    || '_'
    || pt.size_desc
    || CASE
        WHEN length(style_sfx) < 4
             AND pt.batch_nbr = 'DFLT' THEN NULL
        WHEN length(style_sfx) > 4 and pt.batch_nbr = 'DFLT' THEN '_' || pt.style_sfx
        WHEN style_sfx is null and pt.batch_nbr = 'DFLT' then null
        ELSE '_' || pt.batch_nbr end SKU, pt.invn_adjmt_qty na_qty, trunc(pt.create_date_time) dt
        from DM.PIX_TRAN@WMOS46LINK.WORLD pt
        where pt.TRAN_TYPE='605'
        and pt.tran_code='98'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) NA
    on NA.SKU = OH.SKU
) dM
full outer join (
    select 
        coalesce(av.style ||'_'|| av.color ||'_'|| av.size_desc|| case when av.sec_dim = av.color then '' else '_'||av.sec_dim end , hi.style ||'_'|| hi.color || '_'|| hi.size_desc||case when hi.sec_dim = hi.color then '' else '_'||hi.sec_dim end ) as SKU, 
        coalesce(trunc(av.create_date_time), trunc(hi.create_date_time)) snap_date, 
        nvl(av.invn_adjmt_qty,0) OM_OH_QTY, nvl(di.invn_adjmt_qty,0) OM_DEL_INV_QTY, nvl(hi.invn_adjmt_qty,0) OM_HELD_QTY
    from 
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='97') av
    left outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time)= to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='96') di
    on di.style = av.style and di.color = av.color and av.size_desc = di.size_desc and di.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(di.create_date_time)
    full outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='98') hi
    on hi.style = av.style and hi.color = av.color and av.size_desc = hi.size_desc and hi.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(hi.create_date_time)
) OM
    on OM.SKU=DM.SKU
where 
    (nvl(DM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0))) <> 0
    or (nvl(DM.NA,0) - nvl(OM.OM_HELD_QTY,0)) <> 0) x
left outer join invwhsum iw on prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)=x.sku
left outer join  (select distinct MAX(decode(error_text, null,'Not processed in o2_pix_tran','PIX Error: '||error_text)) lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(tranqty) units from o2_pix_tran pt
left outer join o2_pix_tran_error er on pt.esb_batch_number=er.esb_batch_number
join prodskus ps on ps.produpc=pt.produpc and ps.compcode='04'
where pt.whsecode='46' 
and transtype<>'620' 
and processed=0 
and tranqty<>0
and trunc(pt.updated_on)>trunc(sysdate-10)
And bypass_code is null
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ) o2 on o2.item=x.sku 
left outer join (select 'Missing ECOM shipment' lpn_status,LISTAGG(wm.orders,',') within group (order by wm.orders) carton_or_distro, wm.item from (
select CASE
        WHEN length(item_style_sfx) < 4   THEN item_style || item_style_sfx
        ELSE item_style
    END
    || '_'
    || item_color
    || '_'
    || item_size_desc
    || CASE
        WHEN length(item_style_sfx) < 4
             AND batch_nbr = 'DFLT' THEN NULL
        WHEN length(item_style_sfx) > 4 and batch_nbr = 'DFLT' THEN '_' || item_style_sfx
        WHEN item_style_sfx is null and batch_nbr = 'DFLT' then null
        ELSE '_' || batch_nbr end item, ord.tc_order_id orders, trunc(l.shipped_dttm) shipdate
from   dm.outpt_lpn_detail@WMOS46LINK.WORLD ld
  join dm.outpt_lpn@WMOS46LINK.WORLD l on ld.tc_lpn_id=l.tc_lpn_id
  join dm.outpt_orders@WMOS46LINK.WORLD ord on ord.tc_order_id=l.tc_order_id
  where ord.acct_rcvbl_code='EC' and trunc(l.last_updated_dttm)>=trunc(sysdate-7) and trunc(l.last_updated_dttm)<trunc(sysdate)  )wm
left outer join (Select  prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,null,null,'_'|| dimcode) item, trunc(shipdate) ship_date, ship_advice_number orders
 from o2_ech_shipment_tran s
  join prodskus ord on ord.produpc=s.produpc  and ord.compcode='04'
  where trunc(shipdate) >=trunc(sysdate-8) and trunc(shipdate) <trunc(sysdate)) st on wm.item=st.item and wm.orders=st.orders
  where st.orders is null and wm.orders is not null
  group by wm.item) mes on mes.item=x.sku
  LEFT OUTER JOIN (select DISTINCT ord.lpn_status, ord.item from (select 'Missing DC46 shipment' LPN_STATUS, l.tc_lpn_id carton, l.invc_batch_nbr btc_nbr, CASE
        WHEN length(item_style_sfx) < 4   THEN item_style || item_style_sfx
        ELSE item_style
    END
    || '_'
    || item_color
    || '_'
    || item_size_desc
    || CASE
        WHEN length(item_style_sfx) < 4
             AND batch_nbr = 'DFLT' THEN NULL
        WHEN length(item_style_sfx) > 4 and batch_nbr = 'DFLT' THEN '_' || item_style_sfx
        WHEN item_style_sfx is null and batch_nbr = 'DFLT' then null
        ELSE '_' || batch_nbr end item
from dm.outpt_lpn@WMOS46LINK.WORLD l 
JOIN DM.OUTPT_LPN_DETAIL@WMOS46LINK.WORLD lD ON L.TC_LPN_ID=LD.TC_LPN_ID
join dm.outpt_orders@WMOS46LINK.WORLD o on o.tc_order_id=l.tc_order_id
where o.acct_rcvbl_code!='EC' and trunc(l.shipped_dttm)>=trunc(sysdate-5) and trunc(l.shipped_dttm)<trunc(sysdate)
AND L.PROC_STAT_CODE=90)ord
left outer join       
(select to_char(pt.container_id) batch_nbr, ht.invoice_batch_number btch_nbr, PT.pick_ticket_number nbr, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ITEM
from omdba.o2_shipment_header_tran HT
JOIN O2_SHIPMENT_PRODUCT_TRAN PT ON PT.HEADER_TRAN_ID=HT.ID
where whsecode='46' and trunc(shipdate)>=trunc(sysdate-5)) dc12 on dc12.batch_nbr=ord.carton AND  DC12.btch_nbr=ORD.btc_nbr
where dc12.batch_nbr is null and ord.carton is not null) MSB ON MSB.ITEM=X.SKU
left outer join (select 'Not processed in o2' lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(shipped_quantity) units
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on ht.id=pt.header_tran_id
where trunc(shipdate)<trunc(sysdate) and trunc(shipdate)>=trunc(sysdate-7)
and ht.whsecode='46' and pt.pix_esb_batch_number is null
--and  prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ='34817710_200_MIX_RF457'
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)) np on np.item=x.sku
left outer join (select DISTINCT lpn_status, item, shipped units from (select lpn_status, item, applied, shipped from (
select 'Unapplied' lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(st.appliedqty) applied, sum(st.shippedqty) shipped 
from o2_ech_shipment_tran ST
join prodskus ps on st.produpc= ps.produpc and ps.compcode='04'
and st.shippedqty<>st.appliedqty and st.compcode='04'
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode))
where applied<>shipped)) uns on uns.item=x.sku
where iw.whsecode='46' and iw.compcode='04' and (x.oh_var<>0 or x.na_var<>0)
order by x.sku
;

--DC44 COMPARE
select distinct * from (
Select x.*, iw.onhandqty cur_om_oh, iw.notavailqty cur_om_NA ,
Case  when iw.onhandqty=wm_oh and wm_na=iw.notavailqty
then 'Late Post'
when asn.lpn_status is not null
then asn.lpn_status
 when mp.lpn_status is not null
 then mp.lpn_status
 when md.lpn_status is not null
 then  md.lpn_status
when miss_batch.lpn_status is not null
 then miss_batch.lpn_status
 when un_miss.lpn_status is not null
 then un_miss.lpn_status
 when upp.lpn_status is not null
 then upp.lpn_status
 when und.lpn_status is not null
 then und.lpn_status
 when  unpo2.lpn_status is not null
  then unpo2.lpn_status
 else null end
  reason
 from (select
    coalesce(WM.SKU, OM.SKU) SKU,
    nvl(OM.OM_OH_QTY,0) OM_OH, 
    nvl(OM.OM_DEL_INV_QTY,0) OM_DEL_INV, 
    nvl(WM.OH,0) WM_OH,
    nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0)) OH_VAR,
    nvl(OM.OM_HELD_QTY,0) OM_NA, 
    nvl(WM.NA,0) WM_NA,
    nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0) NA_VAR
from 
(
    select coalesce(oh.sku, na.sku) SKU, nvl(oh.oh_qty,0) + nvl(na.na_qty,0) as OH, nvl(na.na_qty,0) NA, coalesce(oh.dt, na.dt) dt
    from (
        select pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim) SKU, pt.invn_adjmt_qty oh_qty, trunc(pt.create_date_time) dt, pt.*
        from WMPROD44.PIX_TRAN@WMOSLINK pt
        inner join WMPROD44.ITEM_WHSE_MASTER@WMOSLINK iwm
        on iwm.sku_id = pt.sku_id
        where pt.TRAN_TYPE='605'
        and pt.tran_code='97'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) OH
    full outer join (
        select pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim) SKU, pt.invn_adjmt_qty na_qty, trunc(pt.create_date_time) dt
        from WMPROD44.PIX_TRAN@WMOSLINK pt
        inner join WMPROD44.ITEM_WHSE_MASTER@WMOSLINK iwm
        on iwm.sku_id = pt.sku_id
        where pt.TRAN_TYPE='605'
        and pt.tran_code='98'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) NA
    on NA.SKU = OH.SKU
) WM
full outer join (
    select 
         coalesce(av.style ||'_'|| av.color ||'_'|| av.size_desc|| case when av.sec_dim = av.color then '' else '_'||av.sec_dim end , hi.style ||'_'|| hi.color || '_'|| hi.size_desc||case when hi.sec_dim = hi.color then '' else '_'||hi.sec_dim end ) as SKU, 
        coalesce(trunc(av.create_date_time), trunc(hi.create_date_time)) snap_date, 
        nvl(av.invn_adjmt_qty,0) OM_OH_QTY, nvl(di.invn_adjmt_qty,0) OM_DEL_INV_QTY, nvl(hi.invn_adjmt_qty,0) OM_HELD_QTY
    from 
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='97') av
    left outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time)= to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='96') di
    on di.style = av.style and di.color = av.color and av.size_desc = di.size_desc and di.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(di.create_date_time)
    full outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='98') hi
    on hi.style = av.style and hi.color = av.color and av.size_desc = hi.size_desc and hi.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(hi.create_date_time)
) OM
    on OM.SKU=WM.SKU
where 
    (nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0))) <> 0
    or (nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0)) <> 0) x
left outer join invwhsum iw on prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)=x.sku
left outer join (select 'Invoice not processed' lpn_status, style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension) sku, invoicebatchctlnbr asn_invc_nbr,sum(unitspacked) units
from esb_rw.asn_invoice inv
join planes pl on inv.stylesuffix=pl.planesdesc
where pl.divcode='001' and omn_processed<>'SENT TO OMNIA' and warehouse='44' and  trunc(to_date(shipdate,'YYYY-MM-DD HH24:MI:SS'))< TRUNC(SYSDATE) and trunc(to_date(shipdate,'YYYY-MM-DD HH24:MI:SS'))>= TRUNC(SYSDATE-3)
group by style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension), invoicebatchctlnbr) asn on asn.sku=x.sku
left outer join (select 'Missing Units in ordalloc from pick' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select ord.picktktctlnbr pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.picktktctlnbr=pt.pick_ticket_number 
where distro_number is null and pt.pix_esb_batch_number is not null and ht.whsecode='44' and ord.whsecode='44' and ord.distronumber='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) mp on mp.sku=x.sku 
left outer join (select 'Missing from o2 tables' lpn_status,row_id, inv.invoicebatchctlnbr, style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension) item, cartonnbr, pickticketctlnbr, distronumber , created_date
from (select rowid row_id,style, stylesuffix,sizedesc, secdimension ,pickticketctlnbr, distronumber, invoicebatchctlnbr, cartonnbr, warehouse, created_date from esb_rw.asn_invoice where warehouse='44'
and omn_processed='SENT TO OMNIA' and trunc(created_date)>=trunc(sysdate-7) )inv
join planes pl on inv.stylesuffix=pl.planesdesc
where pl.divcode='001' and warehouse='44' and (cartonnbr, style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension), decode(distronumber,null,pickticketctlnbr,distronumber)) not in 
(select container_id, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode), decode(distro_number,null,pick_ticket_number,distro_number) from o2_shipment_product_tran )
order by style||'_'||planecode||'_'||sizedesc||decode(secdimension,null,null,'_'||secdimension)) md on md.item=x.sku 
left outer join (select 'Missing Batch' lpn_status, pt.invc_batch_nbr, pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim) item, sum(units_pakd) units
from WMPROD44.outpt_carton_dtl@WMOSLINK pt
 join WMPROD44.ITEM_WHSE_MASTER@WMOSLINK iwm  on iwm.sku_id = pt.sku_id
 join (select sku_id from WMPROD44.pix_tran@WMOSLINK where tran_type='605' and tran_code='97' and trunc(mod_date_time)=trunc(sysdate)) px on px.sku_id=pt.sku_id
       where  trunc(pt.mod_date_time)=trunc(sysdate-1) 
         and pt.invc_batch_nbr not IN (SELECT INVOICEBATCHCTLNBR FROM ESB_RW.asn_invoice WHERE WAREHOUSE='44')
       and pt.proc_stat_code='90'
       group by pt.invc_batch_nbr, pt.style ||'_'|| iwm.misc_short_alpha_1 || '_' || pt.size_desc||decode(pt.sec_dim,null,null,'_'||pt.sec_dim)) miss_batch on miss_batch.item=x.sku 
left outer join (select 'Missing Units in ordalloc from distro' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select ord.distronumber pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord 
on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.distronumber=pt.distro_number 
where distro_number is not null and ht.whsecode='44' and ord.whsecode='44' and ord.distronumber!='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is not null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) un_miss on un_miss.sku=x.sku        
left outer join (select 'Unprocessed Pick' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select ord.picktktctlnbr pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.picktktctlnbr=pt.pick_ticket_number 
where distro_number is null and pt.pix_esb_batch_number is  null and ht.whsecode='44' and ord.whsecode='44' and ord.distronumber='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) upp on upp.sku=x.sku   
left outer join (select distinct 'Unprocessed distro' lpn_status, sku from (select pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch, sum(wm_shipped) wm_shipped, pickcomplete, ship_date
from (
select distinct ord.distronumber pkt,ord.iordnumber omnia_ord, ord.lineseq, ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode) sku, 
ord.pickedqty pickedqty, ord.shippedqty shippedqty, ht.bol_number,ht.invoice_batch_number invc_batch, pt.container_id, pt.shipped_quantity wm_shipped, ord.pickcomplete, pt.ship_date
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on pt.header_tran_id=ht.id
join ordalloc ord 
on pt.prodcode||'_'||pt.planecode||'_'||pt.sizecode||decode(pt.dimcode,pt.planecode,null,'_'||pt.dimcode)=ord.prodcode||'_'||ord.planecode||'_'||ord.sizecode||decode(ord.dimcode,ord.planecode,null,'_'||ord.dimcode)
and ord.distronumber=pt.distro_number 
where distro_number is not null and ht.whsecode='44' and ord.whsecode='44' and ord.distronumber!='000000000000'
and trunc(pt.ship_date)>=trunc(sysdate-20)
and pix_esb_batch_number is null
and ord.pickedqty<>0 and ord.shippedqty=0
)
group by pkt, omnia_ord, sku, pickedqty, shippedqty,invc_batch,pickcomplete, ship_date)) und on und.sku=x.sku
LEFT OUTER JOIN (select distinct 'Not processed out from 02_pix_tran' lpn_status, sku from  (select prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'|| dimcode) sku, pt.esb_batch_number, trandate,tranqty, pt.picktktctlnbr, pt.distronumber from o2_pix_tran pt
join prodskus ps on ps.produpc= pt.produpc
where transtype='910' and processed=0)) unpo2 on  unpo2.sku=x.sku
where iw.whsecode='44')
order by sku
;

--DC67 COMPARE
Select  x.*, iw.onhandqty cur_oh, iw.notavailqty cur_NA,
(case when    o2.lpn_status is not null
then    o2.lpn_status
when    MSB.lpn_status is not null
then    MSB.lpn_status
when    NP.lpn_status is not null
then    NP.lpn_status
 when wm_oh=0 and om_oh>0
then 'WM fixed neg issue man adjust' 
 when iw.onhandqty=wm_oh and wm_na=iw.notavailqty
then 'Late Post'
else null  
END) issue  
   from (select
    coalesce(WM.SKU, OM.SKU) SKU,
    nvl(OM.OM_OH_QTY,0) OM_OH, 
    nvl(OM.OM_DEL_INV_QTY,0) OM_DEL_INV, 
    nvl(WM.OH,0) WM_OH,
    nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0)) OH_VAR,
    nvl(OM.OM_HELD_QTY,0) OM_NA, 
    nvl(WM.NA,0) WM_NA,
    nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0) NA_VAR
from 
(
    select coalesce(oh.sku, na.sku) SKU, nvl(oh.oh_qty,0) + nvl(na.na_qty,0) as OH, nvl(na.na_qty,0) NA, coalesce(oh.dt, na.dt) dt
    from (
        select pt.style || '_'||pt.color|| '_'||pt.size_desc || decode(pt.batch_nbr,'DFLT',decode(pt.style_sfx,null,null,'_'||pt.style_sfx),'_'||pt.batch_nbr)  SKU, pt.invn_adjmt_qty oh_qty, trunc(pt.create_date_time) dt, pt.*
        from WM.PIX_TRAN@WMOS67LINK pt
        where pt.TRAN_TYPE='605'
        and pt.tran_code='97'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) OH
    full outer join (
        select pt.style || '_'||pt.color|| '_'||pt.size_desc || decode(pt.batch_nbr,'DFLT',decode(pt.style_sfx,null,null,'_'||pt.style_sfx),'_'||pt.batch_nbr)  SKU, pt.invn_adjmt_qty na_qty, trunc(pt.create_date_time) dt
        from WM.PIX_TRAN@WMOS67LINK pt
        where pt.TRAN_TYPE='605'
        and pt.tran_code='98'
        and trunc(pt.create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD')) NA
    on NA.SKU = OH.SKU
) WM
full outer join (
    select 
        coalesce(av.style ||'_'|| av.color ||'_'|| av.size_desc|| case when av.sec_dim = av.color then '' else '_'||av.sec_dim end , hi.style ||'_'|| hi.color || '_'|| hi.size_desc||case when hi.sec_dim = hi.color then '' else '_'||hi.sec_dim end ) as SKU, 
        coalesce(trunc(av.create_date_time), trunc(hi.create_date_time)) snap_date, 
        nvl(av.invn_adjmt_qty,0) OM_OH_QTY, nvl(di.invn_adjmt_qty,0) OM_DEL_INV_QTY, nvl(hi.invn_adjmt_qty,0) OM_HELD_QTY
    from 
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='97') av
    left outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time)= to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='96') di
    on di.style = av.style and di.color = av.color and av.size_desc = di.size_desc and di.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(di.create_date_time)
    full outer join
        (select * from O2_INV_PIX_TRAN_DAILY where trunc(create_date_time) = to_date(:v_timestamp,'YYYY-MM-DD') and invn_adjmt_qty>0 and whse=:whse and tran_code='98') hi
    on hi.style = av.style and hi.color = av.color and av.size_desc = hi.size_desc and hi.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(hi.create_date_time)
) OM
    on OM.SKU=WM.SKU
where 
    (nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0))) <> 0
    or (nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0)) <> 0) x
left outer join invwhsum iw on prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)=x.sku
left outer join  (select distinct MAX(decode(error_text, null,'Not processed in o2_pix_tran','PIX Error: '||error_text)) lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(tranqty) units from o2_pix_tran pt
left outer join o2_pix_tran_error er on pt.esb_batch_number=er.esb_batch_number
join prodskus ps on ps.produpc=pt.produpc
where pt.whsecode='67' 
and transtype<>'620' 
and processed=0 
and tranqty<>0
and trunc(pt.updated_on)>trunc(sysdate-10)
And bypass_code is null
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ) o2 on o2.item=x.sku 
 LEFT OUTER JOIN (select DISTINCT ord.lpn_status, ord.item from (select 'Missing DC67 shipment' LPN_STATUS, l.tc_lpn_id carton, l.invc_batch_nbr btc_nbr,  item_style||'_'||item_color||'_'||item_size_desc||decode(batch_nbr,'DFLT',decode(item_style_sfx,null,null,'_'||item_style_sfx),'_'|| batch_nbr) item
from wm.outpt_lpn@WMOS67LINK l 
JOIN wM.OUTPT_LPN_DETAIL@WMOS67LINK lD ON L.TC_LPN_ID=LD.TC_LPN_ID
where trunc(l.shipped_dttm)>=trunc(sysdate-5) and trunc(l.shipped_dttm)<trunc(sysdate)
AND L.PROC_STAT_CODE=90)ord
left outer join       
(select to_char(pt.container_id) batch_nbr, ht.invoice_batch_number btch_nbr, PT.pick_ticket_number nbr, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ITEM
from omdba.o2_shipment_header_tran HT
JOIN O2_SHIPMENT_PRODUCT_TRAN PT ON PT.HEADER_TRAN_ID=HT.ID
where whsecode='67' and trunc(shipdate)>=trunc(sysdate-5)) dc12 on dc12.batch_nbr=ord.carton AND  DC12.btch_nbr=ORD.btc_nbr
where dc12.batch_nbr is null and ord.carton is not null) MSB ON MSB.ITEM=X.SKU
left outer join (select 'Not processed in o2' lpn_status, prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) item, sum(shipped_quantity) units
from o2_shipment_product_tran pt
join o2_shipment_header_tran ht on ht.id=pt.header_tran_id
where trunc(shipdate)<trunc(sysdate) and trunc(shipdate)>=trunc(sysdate-7)
and ht.whsecode='67' and pt.pix_esb_batch_number is null
--and  prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode) ='34817710_200_MIX_RF457'
group by prodcode||'_'||planecode||'_'||sizecode||decode(dimcode,planecode,null,'_'||dimcode)) np on np.item=x.sku
where iw.whsecode='67' and (x.oh_var<>0 or x.na_var<>0)
order by x.sku
;


