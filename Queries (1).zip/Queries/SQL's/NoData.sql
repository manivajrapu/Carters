alter session SET Current_schema=DM;



---------Justin Query -----------

SELECT o.tc_order_id, ds.description "Order Status", o.lane_name, to_char(o.created_dttm, 'DD-MON-YY HH24:MI:SS') "Create Date",
    listagg(l.tc_lpn_id, ', ') within group (order by l.tc_lpn_id) "oLPNs"
FROM orders o 
LEFT JOIN lpn l ON o.tc_order_id = l.tc_order_id
JOIN do_status ds ON o.do_status = ds.order_status
where o.order_type = 'EC'
and to_char(trunc(o.created_dttm),'MON-DD-YYYY') = 'NOV-22-2021'
--and trunc(o.created_dttm) = trunc(sysdate) - 4
and o.do_status in ('140')
--and nvl(o.o_phone_number,'P') <> 'B'
--and o.lane_name in ('2ND DAY','OVERNIGHT')
GROUP BY o.tc_order_id, ds.description, o.lane_name, o.created_dttm
ORDER BY o.created_dttm;

select do_status, order_type,order_id from orders where tc_order_id in ('RCAR12136808_1', 'BCAR70366727_1', 'BCAR70367202_1', 'CAR70368500_1', 'BCAR70370530_1', 'BCAR70371023_1', 'RCAR12138206_1', 'BCAR70372745_1');

SELECT  lpn_facility_status,lpn_id,tc_lpn_id FROM LPN WHERE TC_ORDER_ID in ('RCAR12136808_1', 'BCAR70366727_1', 'BCAR70367202_1', 'CAR70368500_1', 'BCAR70370530_1', 'BCAR70371023_1', 'RCAR12138206_1', 'BCAR70372745_1');

----------------------------------------------------------------------------------------------------------------------------------------------


SELECT o.tc_order_id, ds.description "Order Status", o.lane_name, to_char(o.created_dttm, 'DD-MON-YY HH24:MI:SS') "Create Date",
    listagg(l.tc_lpn_id, ', ') within group (order by l.tc_lpn_id) "oLPNs"
FROM orders o
LEFT JOIN lpn l ON o.tc_order_id = l.tc_order_id
JOIN do_status ds ON o.do_status = ds.order_status
where o.order_type = 'EC'
and to_char(trunc(o.created_dttm),'MON-DD-YYYY') = 'NOV-22-2021'
--and trunc(o.created_dttm) = trunc(sysdate) - 4
and o.do_status in ('140')
--and nvl(o.o_phone_number,'P') <> 'B'
and o.lane_name not in ('BOSS')
GROUP BY o.tc_order_id, ds.description, o.lane_name, o.created_dttm
ORDER BY o.created_dttm; 


select tc_order_id,tc_lpn_id, lpn_facility_status,LAST_UPDATED_DTTM from lpn where tc_order_id in ('CAR76951894_1');


-------------------------------------
select unique o.order_type, o.tc_order_id, o.order_id, o.do_status, l.tc_lpn_id, l.chute_id
from picking_short_item psi, orders o, lpn l, order_line_item oli
where psi.line_item_id = oli.line_item_id and o.order_id = oli.order_id and psi.tc_lpn_id = l.tc_lpn_id
and o.order_type in ('PR','EC') and l.lpn_Facility_status = 15 and psi.stat_code = 90 and do_dtl_status >=120
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.item_id = psi.item_id and td.stat_code < 90)
and not exists (select 1 from picking_short_item psi2 where psi2.line_item_id = psi.line_item_id and psi2.stat_code = 0)
and not exists (select 1 from task_dtl td where td.carton_nbr = psi.tc_lpn_id and td.tc_order_id = o.tc_order_id and td.stat_code < 90)
and not exists (select 1 from alloc_invn_dtl aid where aid.carton_nbr = psi.tc_lpn_id and aid.tc_order_id = o.tc_order_id and aid.stat_code < 90)
and not exists (select 1 from order_line_item oli2 where oli2.order_id = oli.order_id and oli2.do_dtl_status < 150);

00000197181550608917
1220520340

'00000197181332438282','00000197181332202036'
------------------------------------------------------------------------------------------------------------------------------------------------------------

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,order_id,last_updated_source from lpn where tc_lpn_id in ('00000197181358539109') ;  --1235174532
'1220980586'

select * from order_line_item where order_id in ('44115494','44117821');

select * from order_line_item;

select * from DM.lpn where  in ('201901300051');

select lpn_facility_status,tc_lpn_id from lpn where tc_order_id in ('1220520340') and lpn_facility_status < 20;
select distinct stat_code from task_dtl where task_id = '65367456';
select * from lpn_detail where lpn_id in ('67024887') and lpn_detail_status<'90';

select do_status, order_type,order_id from orders where tc_order_id in ('1235174532'); --will be 140

select do_status,order_type,order_id from orders where tc_purchase_order in ('CAR25912717_1');
-----------------------------------------------------------------------------------------------------------------
select do_status,order_type,order_id from orders where ext_purchase_order in ('CAR41136223_1');
select * from orders where ext_purchase_order in ('207838462');
select  from orders where ext_purchase_order in ('CAR25539865');
------------------------------------------------------------------------------------------------------------------


select * from picking_short_item where tc_lpn_id in ('00000197181556377558');
select * from lpn_lock where tc_lpn_id in ('970901611307');

select * from vas_carton where carton_nbr in ('00000156741220551504');



SELECT TC_ORDER_ID FROM LPN WHERE TC_LPN_ID IN('00000197181541727030','00000197181541091933');

--only the lpn ids in the mail must be same as the result.. if any extra lpns come up then dont pack the orders..
SELECT TC_LPN_ID,TC_ORDER_ID,LPN_FACILITY_STATUS,TC_LPN_ID FROM LPN WHERE TC_ORDER_ID IN('CAR41136223_1');   
AND LPN_FACILITY_STATUS <20;

SELECT  lpn_facility_status,lpn_id,tc_lpn_id FROM LPN WHERE TC_ORDER_ID in ('CAR25202030_1','CAR25194290_1');

select * from DM.ALLOC_INVN_DTL where carton_nbr in  ('00000197181556377558') and stat_code < '90';
00000197181545469196
00000197181545492989


select * from DM.TASK_DTL where CARTON_NBR in ('00000197181556377558') and stat_code < '90';
select STAT_CODE from DM.TASK_HDR where TASK_ID='80939563';

select task_id,STAT_CODE from task_dtl where task_id in ('80939563');

select DISTINCT th.TASK_ID from
DM.TASK_HDR th, DM.TASK_DTL td
where td.STAT_CODE = '90' and th.STAT_CODE='30'
and th.TASK_ID=td.TASK_ID;

select tc_order_id,tc_lpn_id from lpn where tc_order_id in ('BCAR41711889_1');
select order_id,LINE_ITEM_ID,allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id='73024225' and item_id='2141782';
select * from wm_inventory where tc_lpn_id in ('970100018140', '970100018695', '970100013873', '970100013163') and item_id='2141782';--608657392
select * from order_line_item where order_id ='41154287' and do_dtl_status <150; 
--only so much-----------------------------------------------------------------------------

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id, MANIFEST_NBR, shipment_id, 
total_lpn_qty, LAST_UPDATED_SOURCE from lpn where tc_lpn_id in ('99003255', '99009886', '99018030', '99039586', '99014616', '99018619', '99046975');--RCAR11112350_1
select * from picking_short_item where tc_lpn_id in ('99003255', '99009886', '99018030', '99039586', '99014616', '99018619', '99046975') and stat_code < '90';
select * from lpn_lock where tc_lpn_id in ('99003255', '99009886', '99018030', '99039586', '99014616', '99018619', '99046975');
select * from DM.ALLOC_INVN_DTL where Carton_NBR in ('00000197181809257798') and stat_code < '90';
select * from DM.TASK_DTL where Carton_NBR in ('00000197181358398140','00000197181358258772') and stat_code < '90'; ----101144098--50
select tc_order_id,tc_lpn_id, lpn_facility_status from lpn where tc_order_id in ('71575625');
select allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id in ('40559301') and item_id='2299357';
select TC_LPN_ID,ON_HAND_QTY,WM_ALLOCATED_QTY,TO_BE_FILLED_QTY from wm_inventory where tc_lpn_id in ('970100014783', '970100013424', '970100010415', '970100012899', '970100015698', '970100017513', '970100018387', '970100011505', '970100018305', '970100016320', '970100013570', '970100013063', '970100017958', '970100012608', '970100017656', '970100009812') and item_id='2299357';

select * from lpn where tc_lpn_id in ('00000156740070777942', '00000156740071099074', '00000156740071949010', '00000156740071949119', '00000156740072916707', '970097235773', '970097274339');----970100013628
select * from DM.ALLOC_INVN_DTL where cntr_nbr in ('99003255', '99009886', '99018030', '99039586', '99014616', '99018619', '99046975') and stat_code < '90';
select * from DM.TASK_DTL where cntr_nbr in ('99003255', '99009886', '99018030', '99039586', '99014616', '99018619', '99046975') and stat_code < '90';
select * from item_cbo where item_id in ('2682548');--36062231 HE 8


------------------------------------------------------------------------------------------------------------------------------------------------
select * from lpn_detail where lpn_id in ('121200880');--326955565
select * from wm_inventory where tc_lpn_id in ('970100018939', '970100012992', '970100016160', '970100009726');
select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source, MANIFEST_NBR, tc_shipment_id, TRACKING_NBR from lpn where tc_order_id in ('1236779087');----BCAR41741580_1
select tc_lpn_id,lpn_id,tc_order_id,tc_lpn_id, lpn_facility_status, ship_via from lpn where tc_order_id in ('1236779087');
select tc_order_id,do_status,order_type,order_id, tc_shipment_id from orders where tc_order_id in ('RCAR11132156_1','RCAR11110526_2','RCAR11132845_1');--79776829
select ORDER_ID,LINE_ITEM_ID, DO_DTL_STATUS from DM.ORDER_LINE_ITEM where ORDER_ID in ('80833730') and do_dtl_status < 200;----735598608

select * from orders where tc_order_id in ('1236779087');---CS48749133

select Manifest_ from lpn where tc_lpn_id in ('00000197181801329592');
select DO_STATUS,ORDER_TYPE,TC_ORDER_ID,ORDER_ID,LAST_UPDATED_SOURCE,LINE_HAUL_SHIP_VIA from orders where D_STATE_PROV in ('VI'); 

select do_status,order_id,order_type,tc_order_id,SHIPMENT_ID,TC_SHIPMENT_ID,D_ADDRESS_1,D_ADDRESS_2,D_ADDRESS_3,
D_CITY,D_STATE_PROV,D_POSTAL_CODE,D_COUNTRY_CODE,BILL_TO_EMAIL,D_NAME  from orders where tc_order_id in ('CAR45009080_1');

select * from POSTAL_CODE where postal_code in ('11532');---11532,07005,10704

select * from shipment where TC_SHIPMENT_ID in('CS49681816');---FEGR

select * from lpn where tc_order_id in ('1235174532');

select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);
------------------------------------------------------------------------------------------------------------------------------------------------------
select tc_lpn_id,lpn_facility_status,tc_order_id,LAST_UPDATED_SOURCE,TC_SHIPMENT_ID,SHIPMENT_ID,MANIFEST_NBR from lpn where tc_lpn_id in ('00000197181767801545');
--00000197181767801545	90	CAR41838931_1	kundus			USPS0015491
select BILL_ACCT_NBR from orders where tc_order_id='1218708623';
select distinct(tc_order_id), bill_acct_nbr from orders where bill_acct_nbr ='185-4X0';

select * from lpn where manifest_nbr in ('USPS0015491');---- CS45142157 

select do_status from orders where tc_order_id in ('BCAR44828077_1');-----00000197181767801545

select * from lpn where tc_order_id in ('CAR41838931_1');

select * from lpn where tc_SHIPMENT_ID in ('CS45142157');

select * from task_dtl where task_id in ('97047514') and stat_code < '90';----201902120072
select * from task_hdr where task_id in ('97047514');
select * from item_cbo where ITEM_ID in ('2627096');----2673000----16519211 DM 12M

select stat_code from task_hdr where task_id in ('94187499', '94233332', '94189629', '94143672', '94143671', '94185644', '94185643', '94185642', '94185641', '94185637', '94185635', '94185634', '94185631', '94185630', '94185629', '94185628', '94185627', '94185626', '94185624', '94185623', '94185622', '94185621', '94185620', '94185619', '94185618', '94185617', '94185616', '94185615', '94185614', '94185613', '94185611', '94185610', '94185609', '94185607', '94185604', '94185603', '94185602', '94185600', '94185595', '94185594', '94185588', '94185587', '94185586', '94185579', '94185573', '94185571', '94185568', '94185557', '94185553', '94185550', '94185547', '94185545', '94185543', '94185538', '94185531', '94185526', '94185511', '94185510', '94185508', '94185501', '94185497', '94185490', '94185479', '94185464', '94185460', '94185457', '94185454', '94185453',
 '94185451', '94185450', '94185443', '94185441', '94185439', '94185438', '94185437', '94185434', '94185433', '94185432', '94185431', '94185430', '94185429', '94185428', '94185427', '94185426', '94185425', '94185424', '94185423', '94185422', '94185421', '94185420', '94185418', '94185417', '94185416', '94185414', '94185413', '94185412', '94185411', '94185410', '94185408', '94185405', '94185404', '94185403', '94185401', '94185399', '94185397', '94185392', '94185391', '94185390', '94185388', '94185387', '94185381', '94185379', '94185377', '94185375', '94185371', '94185370', '94185369', '94185368', '94185366', '94185365', '94185364', '94185363', '94185357', '94185352', '94185342', '94185341', '94185340', '94185647', '94185646', '94185645', '94185384', '94185337', '94185335', '94185332', '94185331', '94184912', '94184848', '94184808', '94184777', '94184721');

select * from alloc_invn_dtl where CARTON_NBR in ('00000197181332438282','00000197181332202036') and stat_code<'90';
select * from task_dtl where cntr_nbr in ('970059456184','970059467904','970059468090','970059467905','970059468093') and stat_code<'90';
-----------------------------------------------------------------------------------------------------------------------------------------------
select shipment_status,SHIPMENT_CLOSED_INDICATOR,LPN_ASSIGNMENT_STOPPED,WMS_STATUS_CODE,last_updated_source,LAST_UPDATED_DTTM from shipment where tc_shipment_id='CS20714649';


select tc_lpn_id,lpn_facility_status,tc_order_id, Manifest_nbr from lpn where TC_LPN_ID in ('00000197181747835348');

----vishwa---order error---------
select distinct lane_name from orders;
select trunc(od.created_dttm) BRIDGE_DATE,
DECODE(LANE_NAME,'2ND DAY','Expedited','OVERNIGHT','Expedited', 'Standard','SAVER') SERV_LVL,
do_status, od.tc_order_id,  sum(oli.order_qty)
from orders od, order_line_item oli, lpn l
where od.order_id = oli.order_id
and od.tc_order_id=l.tc_order_id
and od.is_original_order = 1
and trunc(od.created_dttm) = '07-MAY-21'
and od.do_status = 140
--and od.tc_order_id in ('CAR35748366_1')
and od.order_type = 'EC' --and od.created_dttm >= trunc(sysdate) - 1
group by od.tc_order_id,od.created_dttm,LANE_NAME,do_status,oli.order_qty order by od.created_dttm asc; 


--------Justin Query-------------------------

SELECT o.tc_order_id, ds.description "Order Status", o.lane_name, to_char(o.created_dttm, 'DD-MON-YY HH24:MI:SS') "Create Date",
    listagg(l.tc_lpn_id, ', ') within group (order by l.tc_lpn_id) "oLPNs"
FROM orders o 
LEFT JOIN lpn l ON o.tc_order_id = l.tc_order_id
JOIN do_status ds ON o.do_status = ds.order_status
where o.order_type = 'EC'
and to_char(trunc(o.created_dttm),'MON-DD-YYYY') = 'APR-17-2021'
--and trunc(o.created_dttm) = trunc(sysdate) - 4
and o.do_status in ('130')
--and nvl(o.o_phone_number,'P') <> 'B'
--and o.lane_name in ('2ND DAY','OVERNIGHT')
GROUP BY o.tc_order_id, ds.description, o.lane_name, o.created_dttm
ORDER BY o.created_dttm;


select do_status, order_id from orders where tc_order_id = 'CAR69736160_1';

select do_dtl_status from order_line_item where order_id = '115023558';

select tc_lpn_id, lpn_facility_status from lpn where order_id = '115023558';

-----vishwa query for orphaned
Select aid.CARTON_NBR, aid.CNTR_NBR, aid.INVN_NEED_TYPE, ic.ITEM_NAME, aid.stat_code, aid.QTY_ALLOC, aid.QTY_PULLD,
ic.ITEM_BAR_CODE, aid.MOD_DATE_TIME, aid.USER_ID
from DM.ALLOC_INVN_DTL aid, item_cbo ic where aid.CARTON_NBR in ('00000197181766528344') and aid.item_id=ic.item_id;


select * from wave where wave_id in ('201901280046');

lpn for manifest_nbr----vishwa
select ml.tc_lpn_id,ml.status,ml.LAST_UPDATED_SOURCE,mh.tc_manifest_id from manifested_lpn ml, manifest_hdr mh where ml.manifest_id = mh.manifest_id 
and mh.tc_manifest_id = 'FXGD000018575' and exists (select 1 from lpn l where l.tc_lpn_id = ml.tc_lpn_id 
and l.lpn_Facility_status < 90);

lpn for order -----vishwa
select tc_order_id,tc_lpn_id,tc_reference_lpn_id,lpn_facility_status,tc_shipment_id,ship_via,LAST_UPDATED_SOURCE from lpn 
where tc_order_id in ('BCAR41717294_1');

---------jonathan query for cancel lpn
select unique(cntr_nbr) from alloc_invn_dtl aid where carton_nbr = '00000197181732680632'
  and exists (select 1 from arch_lpn al where al.tc_lpn_id = aid.cntr_nbr)
  and not exists (select 1 from lpn l where l.tc_lpn_id = aid.cntr_nbr)
  and aid.cntr_nbr is not null
  and aid.invn_need_type = 52;----EXC_281018_000605569

select *  from dm.lpn where TC_LPN_ID in ('00000197181358134960');

select lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty from wm_inventory where TC_LPN_ID in ('00000197181358134960');

select * from wm_inventory where wm_inventory_id = '34082252';

select * from order_line_item where order_id = '80001735' and do_dtl_status < 190;

select do_status, order_id from orders where tc_order_id = 'CAR69736160_1';

select do_dtl_status from order_line_item where order_id = '115023558';

select tc_lpn_id, lpn_facility_status from lpn where order_id = '115023558';

select * from orders where tc_order_id = 'BCAR44828077_1';
select * from sys_code where code_type in ('CCF');

select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id, initial_qty, size_value, item_name from lpn_detail where lpn_id = '114268263';---114268263----246775619

select wm_inventory_id,lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty from wm_inventory where TC_LPN_ID   = '00000156741226719113';

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,order_id,total_lpn_qty,last_updated_source from lpn where tc_lpn_id in ('00000197181783224656') ; 

select owner, job_name, enabled, state, failure_count, max_failures, to_char(last_start_date,'mm/dd/yyyy hh:mi:ss AM') last_start, 
         to_char(trunc(sysdate) + last_run_duration,'hh24:mi:ss') last_duration, to_char(next_run_date,'mm/dd/yyyy hh:mi:ss AM') next_run, run_count 
from  dba_scheduler_jobs where owner = 'DM';

select * from ship_via where ship_via in ('FDEG');
select * from sys_code where code_type in ('CCF');


select * from lpn where lpn_id='116409378' and tc_lpn_id='00000156741226950738';
select lpn_id from wm_inventory where tc_lpn_id='00000156741226952497' and wm_inventory_id='173771089';

select do_status,order_type,tc_order_id,SHIPMENT_ID,TC_SHIPMENT_ID,D_ADDRESS_1,D_ADDRESS_2,D_ADDRESS_3,
D_CITY,D_STATE_PROV,D_POSTAL_CODE,D_COUNTRY_CODE,BILL_TO_EMAIL,D_NAME  from orders where tc_order_id in ('1236168487');




select do_status,tc_order_id,order_id,REF_FIELD_3 from dm.orders where ext_purchase_order in ('233743');   ---115399089

select * from order_note where order_id in ('115941019');

select vas_process_type,price_tkt_type from order_line_item;  where order_id in(select order_id from orders where ref_field_3 = 'RP' and 
do_status = '110' and tc_order_id in ('1273356819'));

select lpn_cubing_indic,pre_pack_flag,LAST_UPDATED_DTTM from orders where TC_ORDER_ID in ('1273356819');


select lpn_cubing_indic,pre_pack_flag,LAST_UPDATED_DTTM from orders where TC_ORDER_ID in ('1273356819');
