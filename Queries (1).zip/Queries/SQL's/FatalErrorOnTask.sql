alter session SET Current_schema=DM;

select * from task_dtl where cntr_nbr in ('00006644541260657790');

select unique task_id from DM.PROD_TRKG_TRAN where cntr_nbr in ('00006644541260657790'); 

----------------------------**********--------------------
select task_id, cntr_nbr, task_cmpl_ref_nbr, stat_code, invn_need_type 
from task_dtl
where cntr_nbr = '00006644541260657790'
and stat_code < 90;


select ic.item_id,ic.item_name,ic.item_bar_code,pt.cntr_nbr,pt.task_id,pt.MOD_DATE_TIME
from prod_trkg_tran pt
join item_cbo ic on ic.item_id=pt.item_id
where cntr_nbr in ('00006644541260657790') order by MOD_DATE_TIME desc; 


select td.task_id "Task ID",td.task_seq_nbr "Task Sequence", td.task_genrtn_ref_nbr "Wave Number", 
             td.invn_need_type "Need Type", lh.dsp_locn "Need Location", im.item_name "Need Item", td.qty_alloc "Qty Alloc", lh.locn_brcd, im.item_bar_code
from task_dtl td, wm_inventory wi, item_cbo im, locn_hdr lh
where td.pull_locn_id = wi.location_id(+)
and td.item_id = wi.item_id(+)  
and td.pull_locn_id = lh.locn_id(+)
and td.item_id = im.item_id(+)
and (wi.location_id is null or wi.item_id is null)
and td.stat_code =0 and td.invn_need_type in (3,51)
and td.create_date_time > sysdate - 10;

-------------Veal Thomas query-----------

SELECT
    td.task_id               "Task ID",
    td.task_seq_nbr          "Task Sequence",
    td.task_genrtn_ref_nbr   "Wave Number",
    td.cntr_nbr              "Tote",
    td.invn_need_type        "Need Type",
    lh.dsp_locn              "Need Location",
    im.item_name             "Need Item",
    td.qty_alloc             "Qty Alloc",
    lh.locn_brcd,
    im.item_bar_code,
    td.batch_nbr,
    td.*
FROM
    task_dtl td,
    wm_inventory wi,
    item_cbo im,
    locn_hdr lh
WHERE
    td.pull_locn_id = wi.location_id (+)
    AND td.item_id = wi.item_id (+)
    AND td.pull_locn_id = lh.locn_id (+)
    AND td.item_id = im.item_id (+)
    AND ( wi.location_id IS NULL
          OR wi.item_id IS NULL )
    AND td.stat_code = 0
    AND td.create_date_time > SYSDATE - 1
    AND td.invn_need_type = '3';

--Fletcher Query----100127691
select * from task_dtl where task_id = '13732838' and TASK_SEQ_NBR not in (
select td.TASK_SEQ_NBR
from task_dtl td, item_cbo ic, locn_hdr lh, wm_inventory wi
where td.item_id = ic.item_id
and td.pull_LOCN_ID = lh.locn_id
and td.PULL_LOCN_ID = wi.location_id
and td.item_id = wi.item_id
and td.task_id = '16758135'
)
order by TASK_SEQ_NBR;

select stat_code FROM task_hdr where task_id in ('95307115') and stat_code<'90';
2365036--620496320

SELECT
    td.task_id,
    td.cntr_nbr,
    lh.dsp_locn,
    td.item_id
FROM
    task_dtl   td,
    locn_hdr   lh
WHERE
    lh.locn_id (+) = td.pull_locn_id
    AND td.task_id = '42815593'
    AND td.stat_code <> '99';

select * from locn_hdr where locn_id in ('620496320');--PE17304B01--

select * from item_cbo where item_id in ('2365036');
select * FROM task_dtl where task_id in ('13742433') and stat_code<'90';

select tc_lpn_id,lpn_facility_status from lpn where tc_lpn_id in ('00000197181519802806', '00000197181519803179', '00000197181519803186', '00000197181519803667');

select * from lpn where  tc_asn_id = '249947001' and lpn_facility_status='1';


select * from task_dtl where cntr_nbr in ('970100011312') and stat_code<90;




select * from task_dtl where task_id = '19420991' and task_seq_nbr  in ('10') and cntr_Nbr is null; 



-----------------No destination----------------------
--FIND THE STATIC ROUTE BY CARTON NUMBER
SELECT l.tc_lpn_id, o.assigned_static_route_id, l.shipment_id, l.tc_shipment_id, l.tracking_nbr, o.last_updated_source
FROM orders o
JOIN lpn l
ON o.tc_order_id = l.tc_order_id
WHERE tc_lpn_id IN (
'00000197181372680955', '00000197181372658145', '00000197181372676781', '00000197181372696789', '00000197181372695256', '00000197181372696307', '00000197181372690992', '00000197181372558926', '00000197181372667581', '00000197181372230051', '00000197181372665464', '00000197181372674640', '00000197181372696710', '00000197181372696772'
)
order by o.assigned_static_route_id;
 
