alter session SET Current_schema=DM;

select /*+rule */
       ses.process,
       ses.sid as sid,
       ses.serial# as serial_num,
       ses.username as db_username,
       pro.spid     as host_pid,
       ses.machine  as machine,
       substr(ses.program,1,60) as program,
       substr(obj.object_name,1,20) as object_name,
       loc.lock_type as lock_type,
       loc.mode_held as mode_held,
       loc.mode_requested as mode_req,
       loc.last_convert as Seconds_n_Stale,
       loc.blocking_others as is_blocking
  from v$session ses,
       v$process pro,
       dba_lock loc,
       dba_objects obj
where ses.sid      = loc.session_id
   and ses.paddr    = pro.addr
   and loc.lock_id1 = obj.object_id
   and ses.username is not null
   and object_name not in ('PROC_LOCK') and object_name not like '%TMP%' and object_name not like '%$%'
   and loc.last_convert > 30
--order by ses.process, ses.sid, ses.serial#
order by Seconds_n_Stale desc;


SELECT
c.status,
OS_USER_NAME "Terminal",
a.PROCESS "UNIX proccess",
substr(ORACLE_USERNAME,1,10) "Locker",
substr(PROGRAM,1,99) "Program",
NVL(lockwait,'ACTIVE') "Wait",
substr(DECODE(LOCKED_MODE,2,'ROW SHARE',3, 'ROW EXCLUSIVE',4, 'SHARE',5,
'SHARE ROW EXCLUSIVE',6, 'EXCLUSIVE', 'UNKNOWN'),1,12) "Lockmode",
OBJECT_TYPE "Object Type",
object_name "Object Name",
SESSION_ID "Session ID",
"SERIAL#" "Serial",
substr(c.SID,1,6) "SID",
c.sql_id,
logon_time, seconds_in_wait
FROM SYS.V_$LOCKED_OBJECT A, SYS.ALL_OBJECTS B, SYS.V_$SESSION c
WHERE A.OBJECT_ID = B.OBJECT_ID
and object_name not in ('PROC_LOCK','LABOR_MSG') and object_name not like '%TMP%' and object_name not like '%$%'
and c.program like 'Pk%'
AND C.SID = A.SESSION_ID and seconds_in_wait > 300;