alter session SET Current_schema=DM;

select * from lpn where manifest_nbr='UPS000015564';
1Z52159R0302303098
1Z52159RYW02368717
1Z52159RYW02370142
1Z52159RYW02370400
1Z52159RYW02370740
1Z52159RYW02369832
1Z52159RYW02369823
1Z52159RYW02370008
1Z52159RYW02382782
1Z52159RYW02382880
1Z52159RYW02372720
1Z52159RYW02372819
1Z52159RYW02373023
1Z52159RYW02372926
1Z52159RYW02373229

select * from lpn where 

select * from lpn where manifest_nbr='UMI000007118';
select * from lpn where manifest_nbr='UPS000013625';
select * from lpn where manifest_nbr='UPS000013469';
select * from lpn where manifest_nbr='UPS000013437';
select * from lpn where manifest_nbr='UPS000013476';

--Fatal Error Query--
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000015564';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013119';
Select ep.epc "Returns Tracking", l.tracking_nbr "Outbound Tracking" from epc_track ep, lpn l where ep.carton_nbr = l.tc_lpn_id and l.manifest_nbr = 'UPS000013084';


1Z869V6R9058331618
1Z869V6R9058326606
1Z869V6R9058321629
1Z869V6R9057685202
1Z869V6R9058320139
1Z869V6R9058321932
1Z869V6R9058320237
1Z869V6R9058319847
1Z869V6R9058320193
1Z869V6R9058319918
-------------
1Z52159R0307535936
1Z52159RYW07531085
1Z52159R0306919354
1Z52159RYW07529687
1Z52159RYW07531343
1Z52159RYW07529776
1Z52159RYW07529436
1Z52159RYW07529749
1Z52159RYW07529490
1Z52159R0307449833
1Z52159R0307491671
1Z52159RYW07529203
1Z52159RYW07529785
1Z52159RYW07529589
1Z52159RYW07532502
1Z52159RYW07532404
1Z52159RYW07533261
1Z52159RYW07538337
1Z52159RYW07532093
1Z52159RYW07533350
1Z52159R0307534722
1Z52159RYW07537427

select tc_lpn_id,lpn_facility_status,lpn_id,tc_order_id,total_lpn_qty, ship_via from lpn where tc_lpn_id in ('00000156741230644135');

select * from lpn_detail where lpn_id in ('54393166') and lpn_detail_status<'90';
select do_status, order_id,order_type from orders where tc_order_id in ('1209102019');
select * from picking_short_item where tc_lpn_id in ('00000156741230644135');
select * from lpn_lock where tc_lpn_id in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224');
select count(*) from alloc_invn_dtl where cntr_nbr in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224') and stat_code<'90';
select * from alloc_invn_dtl where cntr_nbr in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224') and stat_code<'90';
select * from task_dtl where cntr_nbr in ('00000197181507197471', '00000197181507201758', '00000197181507202007', '00000197181507202021', '00000197181507207422', '00000197181507209327', '00000197181507209662', '00000197181507210286', '00000197181507215274', '00000197181507215441', '00000197181507235944', '00000197181507265224') and stat_code<'90';
select do_dtl_status,allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id='38944881' and do_dtl_status<'150';

--BOSS Carton Close
select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);

select tc_lpn_id,lpn_facility_status,lpn_id,tc_order_id,total_lpn_qty, last_updated_source from lpn where tc_lpn_id in ('00000197181365077571');
select * from lpn_detail where lpn_id in ('60149689') and lpn_detail_status <'90';
select order_type,do_status,order_id from orders where tc_order_id in ('BCAR51794414_1');
select * from picking_short_item where tc_lpn_id in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select * from alloc_invn_dtl where cntr_nbr in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select * from task_dtl where cntr_nbr in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select * from lpn_lock where tc_lpn_id in ('00000197181507176957', '00000197181507178159', '00000197181507178791', '00000197181507181333', '00000197181507239140');
select do_dtl_status from order_line_item where order_id in ('39183159') and do_dtl_status < '150';
select allocated_qty,orig_order_qty,order_qty,units_pakd from order_line_item where order_id in ('39182751') and do_dtl_status < '150';
select tc_lpn_id,tc_order_id,lpn_facility_status from lpn where tc_order_id in ('CAR23481517_1','CAR23481667_1','CAR23481789_1','CAR23482276_1');


--2285355,2285067

select * from wm_inventory where tc_lpn_id ='00000197181505060531' and item_id in ('2285355','2285067');

select * from lpn where tc_lpn_id in ('EXC_231216_000007457','EXC_231216_000007456');

--BOSS PTS Failed
select cle.name, to_char(cleq.msg_id) MSG_ID, l.tc_lpn_id, o.tc_order_id, when_queued, cleq.status, REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 14) USER_ID
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l, orders o
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and l.order_id = o.order_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 6)  = l.tc_lpn_id 
and o.order_type = 'EC'
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_PickConfirm') 
and error_count > 1;

select tc_lpn_id,lpn_facility_status,lpn_id,tc_order_id from lpn where tc_lpn_id in ('00000197181327430345'),'00000197181503711374','00000197181503711350');
select tc_order_id,do_status,order_type,order_id from orders where tc_order_id in ('CAR23211387_1','1217700550');--38792649,38622291
select do_dtl_status,allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id ='38792649' and item_id in ('2290435','2289923');
select * from lpn_detail where lpn_id in ('59482391','59482383');--2290435,2289923
select * from wm_inventory where item_id in ('2290435','2289923') and tc_lpn_id in ('00000197181502285401','00000197181503711374','00000197181503711350');

select * from lpn where tc_shipment_id ='CS19807110';
select * from lpn where tc_shipment_id ='CS19807708';
select * from lpn where tc_shipment_id ='CS19807104';

------------------------------------------------------------------------
select tc_lpn_id,lpn_facility_status,tc_order_id,tc_shipment_id,ship_via,manifest_nbr,last_updated_source from lpn where tc_lpn_id in ('00000197181941833911');
select * from orders where tc_order_id='CAR56197799_1';
select do_status,order_type from orders where tc_order_id in ('1244890998');
select tc_lpn_id,lpn_facility_status,tc_order_id from lpn where tc_order_id in ('BCAR24015918_1','BCAR24015950_1','BCAR24019637_1');
select * from lpn where tc_shipment_id='CS20409742';
select * from ship_via where ship_via='UEGD';--UPS Ground Ecom
select * from shipment where tc_shipment_id='CS20409742';
select do_dtl_status from order_line_item where order_id='98436975';

select 'ECOM' CHANNEL, manif_nbr MANIFEST, shpr_id ACCT, max(create_date_time) UPLOAD_DATE
from ups_emt_upload_rpt_hist where rpt_type = '1' 
and create_date_time > sysdate - 1
and shpr_id in ('869V6R', '015104')
group by manif_nbr, shpr_id
having count(*) = 1 
UNION ALL
select DECODE(SHIPPER_AC_NUM,'882W15','RETAIL','WHOLESALE') CHANNEL, mh.tc_manifest_id MANIFEST, shipper_ac_num ACCT, close_date UPLOAD_DATE
from manifest_hdr mh where close_date > sysdate - 1 and shipper_ac_num in ('882W15','A596Y8') and ups_pld_upload_indic is null and manifest_status_id = 90
and exists (select 1 from lpn l where l.manifest_nbr = mh.tc_manifest_id and l.lpn_facility_status = 90) 
order by MANIFEST;

---------------------Could not load ship_via---------------
--- to check different lane_name
Select distinct lane_name from orders;
----to check order_id from Lane name
Select tc_order_id, lane_name, do_status from orders where lane_name in('PREMIUM') and do_status in ('150');


--- to check ship_via
Select ship_via, tc_lpn_id, tc_order_id from LPN where tc_order_id in ('CAR72197564_1');

Select * from ship_via where ship_via in ('UESP');

select ship_via from lpn where tc_lpn_id in ('00000197180113411919');

