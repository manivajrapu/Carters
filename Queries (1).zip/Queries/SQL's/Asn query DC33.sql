
select * from inpt_asn_hdr where SHPMT_NBR='208447001';---SHPMT_NBR u will get it from UI

select * from ASN_HDR where SHPMT_NBR='208447001' ;

select PROC_STAT_CODE, ERROR_SEQ_NBR from inpt_asn_hdr;

select * from msg_log where REF_VALUE_1='176499957';--take from UI if it is not in db
--Invalid Vendor 11567_CODE bridged for Case 00006644549816006771 
select * from CASE_HDR where CASE_NBR='00006644549816006771';

select * from VENDOR_MASTER where VENDOR_ID='11567';
