alter session SET Current_schema=DM;

select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status <= 180 and lpn_facility_status < 40 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status > 60);


select * from shipment where tc_shipment_id in ('CS48710846');--CAR42931218_1--CS48710846

select * from shipment where tc_shipment_id in ('CS46418872');---Assigned_Carrier_code--fxsp
select Assigned_Carrier_code  from shipment where tc_shipment_id in ('CS48854603');

select TC_LPN_ID, LpN_facility_status,MANIFEST_NBR, ship_via, tc_shipment_id, TC_ORDER_ID from lpn where TC_SHIPMENT_ID in('CS46758302') and TC_LPN_ID in('00000197181783516027');
select TC_LPN_ID, LpN_facility_status,MANIFEST_NBR, ship_via, tc_shipment_id, TC_ORDER_ID from lpn where TC_ORDER_ID in('CAR42931218_1');--00000197181783716625

select tc_order_id,do_status, order_id,order_type, tc_shipment_id, ext_purchase_order,order_type from orders where tc_order_id in ('CAR42931218_1');
select tc_lpn_id,tc_shipment_id,tc_order_id,lpn_facility_status,ship_via,last_updated_source from lpn where tc_lpn_id='00000197181799644912';---CS48854603
select * from orders where tc_order_id='1218458584';
select * from lpn where tc_order_id='1218458584';
select * from ship_via where ship_via='HJBI';

select * from POSTAL_CODE where postal_code='10033';
select * from ship_wave_parm where ship_wave_nbr='201702050053';



select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;



select * from manifest_hdr where tc_manifest_id='UPS000013020';
select * from lpn where manifest_nbr='UPS000013020';
select * from order_line_item where order_id='32506883';
select do_status,order_type, ext_purchase_order from orders where tc_order_id='1217772330';
select tc_order_id, tc_shipment_id, lpn_facility_status,ship_via from lpn where tc_lpn_id in ('00000197181506459778','00000197181506459594');
select * from ship_via where ship_via='UPSN';
select * from lpn where tc_order_id ='BCAR21431321_1';

--201611080049
select * from ship_wave_parm where ship_wave_nbr='201705220040';

select tc_lpn_id, tc_shipment_id, lpn_facility_status, ship_via, tc_order_id, shipment_id, manifest_nbr, last_updated_source from lpn where tc_lpn_id in ('00000197181473449895'),'00000197181471873395','00000197181472267223');

select description from ship_via where ship_via='HJBI';

select * from ship_wave_parm where ship_wave_nbr='201609270056';
is 201609270056

select * from lpn where tc_lpn_id='00000197181453451276';

select * from task_dtl where task_genrtn_ref_nbr='201608080002' and stat_code<'90';

select * from alloc_invn_dtl where task_genrtn_ref_nbr='201608080002' and stat_code<'90';--100338384, 100338123 100338137

select * from locn_hdr where locn_id in ('100338384','100338123','100338137');
-- 00000156741217782867 477721670
-- 2239756
-- 20625583  312243763
select * from lpn where tc_lpn_id = '00000197181765034594';

select * from item_cbo where item_id='2239756';

select * from pkt_dtl where pkt_ctrl_nbr = '20625583' and pkt_seq_nbr = '312243763';
select tc_order_id,lpn_facility_status, tracking_nbr from lpn where tc_lpn_id = '00000197181325269671';
select * from lpn_detail where lpn_id = '49604465' and lpn_detail_id = '477721670';
select do_status from orders where tc_order_id ='BCAR26042655_1';

PDF0320B05 -DSP location
31734610 DM 4 item name


select tc_lpn_id,lpn_facility_status,tc_order_id,tc_shipment_id from lpn where tc_lpn_id in ('EXC_060217_000008308');
select * from alloc_invn_dtl where cntr_nbr='EXC_060217_000008308' and stat_code < '90';

 select TC_LPN_ID, ship_via from lpn where TC_LPN_ID in ('00000197181761799145', '00000197181761799152', '00000197181761799138', '00000197181761799169');

select * from postal_code where postal_code in ('28398');
