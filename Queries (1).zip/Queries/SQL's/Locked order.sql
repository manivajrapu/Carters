alter session SET Current_schema=DM;

select trunc(od.created_dttm) BRIDGE_DATE, 
--DECODE(LANE_NAME,'2ND DAY','Expedited','OVERNIGHT','Expedited', 'BOSS','STS','Standard') SERV_LVL,
DECODE(LANE_NAME,'2ND DAY','Expedited','OVERNIGHT','Expedited','BOSS','STS','STANDARD','Standard','SAVER','Standard','POBOX','Standard','USPS','Standard','STOREPICKUP','Standard','249380','Standard','NOROUTE','Standard','CALL','Standard','JCP','Standard','GROUND','Standard','PREMIUM','Standard',NULL,'Standard') SERV_LVL,
od.CREATED_DTTM,do_status, od.tc_order_id,  oli.order_qty  
from orders od, order_line_item oli
where od.order_id = oli.order_id
and od.is_original_order = 1
and od.do_status = 170
and od.order_type = 'EC'
and od.serv_lvl = 'Expedited'
and oli.bridge_date = '26-JUN-19';
