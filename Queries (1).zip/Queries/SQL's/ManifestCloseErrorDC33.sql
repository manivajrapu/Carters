Select * from manif_parcl_hdr where manif_nbr in ('UPS330011309');

Select stat_code, carton_nbr from manif_parcl_carton where manif_nbr in ('UPS330011309') and stat_code < '90';

select distinct(ship_via) from carton_hdr where manif_nbr='UPS330011309' and stat_code < '40';

select distinct(carton_nbr) from carton_hdr where manif_nbr='UPS330011309';

select * from carton_lock where carton_nbr in ('00000197183470897433',
'00000197183470927345',
'00000197183470782838');


select * from carton_lock where carton_nbr in ('00000197183469641351',
'00000197183974398191',
'00000197183974398061');

select * from carton_hdr where carton_nbr ='00000197183974218369';
select * from carton_dtl where carton_nbr ='00000197183974218369';

select * from carton_lock where carton_nbr in (select carton_nbr from carton_hdr where carton_nbr ='00000197183974218369');

select * from Carton_hdr where parcl_shpmt_nbr='335962654';

select unique(user_id) from Carton_hdr where manif_nbr in ('UPS330010624') 

and stat_code<40;

select * from carton_dtl where manif_nbr in ('UPS330007763');



Select * from manif_parcl_carton where manif_nbr in ('UPS330007763') and stat_code<'90';

Select * from manif_parcl_carton where carton_nbr = '00000197183953631936';

select * from outpt_carton_hdr where manif_nbr='UPS330007763';

select * from outpt_pkt_hdr where manif_nbr='UPS330007763';



