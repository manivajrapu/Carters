alter session set current_schema=wmprod33;

select count(*)
from wmprod33.store_distro sd
where po_nbr in ('10594422', '10594423', '10594454', '10594458', '10594459', '1059571s', '10595716', '10595743', '10595766', '10595782', '10595783', '10595816', '10595833', '10595852') order by po_nbr;

select 'update store_distro set store_dept= '||''''|| spl_instr_code_3 ||''''||' where po_nbr = '||''''|| po_nbr||''''||' and distro_nbr = '||''''||distro_nbr||''''||' and sku_id= '||''''||sd.sku_id||''''||';' stmt
from wmprod33.store_distro sd
join wmprod33.item_master im on im.sku_id=sd.sku_id
where spl_instr_code_3<>'99' and po_nbr in ('10594422', '10594423', '10594454', '10594458', '10594459', '1059571s', '10595716', '10595743', '10595766', '10595782', '10595783', '10595816', '10595833', '10595852');

