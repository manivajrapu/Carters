alter session SET Current_schema=DM;

--'00000197181439574289','00000197181439592665','00000197181439592283','00000197181439663938','00000197181439278521'

select * from lpn_lock where tc_lpn_id in ('00000197181444582026', '00000197181444507258', '00000197181444503762', '00000197181444506220', '00000197181444492257', '00000197181443993793', '00000197181443993472', '00000197181444239364', '00000197181443993786', '00000197181444124141', '00000197181444238343');

select * from vas_carton where carton_nbr in ('00000197181444507258', '00000197181444503762', '00000197181444506220', '00000197181444492257', '00000197181444239364', '00000197181444238343');

select * from vas_carton where carton_nbr in ('00000197181443993793', '00000197181443993472', '00000197181443993786', '00000197181444124141');

select * from lpn_lock where tc_lpn_id in ('00000197181443993793', '00000197181443993472', '00000197181443993786', '00000197181444124141');

--Today's
select * from lpn_lock where tc_lpn_id in ('00000197181448207932', '00000197181448171905', '00000197181448198209');

select * from vas_carton where carton_nbr in ('00000197181448207932', '00000197181448171905', '00000197181448198209');



select DISTINCT(reqd_qty) from vas_carton where carton_nbr in ('00000197181443930439', '00000197181443882547', '00000197181443924599', '00000197181443885791', '00000197181443922779', '00000197181443933430', '00000197181443896834', '00000197181443958136', '00000197181443957092', '00000197181443963291', '00000197181443962799');

select * from lpn_lock where tc_lpn_id in ('00000197181443898210','00000197181443924223','00000197181443927798');



--00000197181439760477 

select * from lpn_lock where tc_lpn_id='00000197181456068761'; --new

select * from lpn_lock where tc_lpn_id='00000197181442442469';

select carton_nbr,stat_code, reqd_qty, cmpl_qty from vas_carton where carton_nbr='00000197181456068761';

select carton_nbr,stat_code, reqd_qty, cmpl_qty from vas_carton where carton_nbr='00000197181442442469';

select carton_nbr,stat_code, reqd_qty, cmpl_qty from vas_carton where carton_nbr='00000197181442430428';

select * from lpn_lock where tc_lpn_id='00000197181442430428';

-- These are retail cartons for PTS (Put to Store)

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and d_facility_alias_id is not null 
and TC_LPN_ID in ('00000197181341006885');

--These are STS(Ship to Store) cartons (BOSS- Buy Online Ship to Store)

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and misc_instr_code_3 > 0 and d_facility_alias_id is  null
and TC_LPN_ID in ('00000197181341006885');
















