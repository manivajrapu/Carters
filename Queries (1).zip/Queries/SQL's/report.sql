select DD "Download Date",OQ "Order Qty",WQ "Waved Qty",PQ "Packed Qty", SQ  "Shipped Qty",CQ "Cancelled Qty",addr_code,(OQ-PQ) "To Pack",(OQ-SQ) "To Ship"
from
(select to_char(trunc(sd.CREATE_DATE_TIME), 'MM/DD/YYYY') DD,  sum(nvl(sd.REQD_QTY,0)) OQ, 
sum(nvl(sd.ALLOC_QTY,0)) WQ, sum(nvl(pd.UNITS_PAKD,0)) PQ, sum(nvl(opd.SHPD_QTY,0)) SQ, sum(nvl(pd.CANCEL_QTY,0)) CQ, ph.ADDR_CODE 
from outpt_pkt_dtl opd,pkt_dtl pd,store_distro sd,pkt_hdr ph
where  opd.PKT_CTRL_NBR=pd.PKT_CTRL_NBR and pd.PKT_CTRL_NBR =sd.PKT_CTRL_NBR and sd.pkt_ctrl_nbr=ph.pkt_ctrl_nbr
and sd.CREATE_DATE_TIME >= trunc(sysdate) -20
and pd.stat_code<99
group by to_char(trunc(sd.CREATE_DATE_TIME), 'MM/DD/YYYY'),ph.addr_code
)
order by 1;

DESC store_distro;
