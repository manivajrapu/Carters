alter session set current_schema=DM;

select do_status, orders.* from orders where tc_order_id like 'TST%' and LAST_UPDATED_SOURCE = 'preprocessor'; 
select do_status, orders.* from orders where tc_order_id = 'TST00000004_1';

select * from item_cbo where item_id = '2794462';

select * from pix_tran where ref_field_1 = 'TST00000004_1';
select * from outpt_lpn where tc_lpn_id = '00000197181929674734';

select * from task_hdr where task_id = '23872746';

select * from task_dtl where task_id = '23872746';

select * from WM_INVENTORY where LOCATION_ID = '100442272' and ITEM_ID = '2794462';

select * from TASK_GRP_ELGBLTY where invn_need_type = '50';

select * from task_dtl where task_genrtn_ref_nbr = '202010080001001';
select * from alloc_invn_dtl where task_genrtn_ref_nbr = '202010080001001';

select * from lpn where tc_lpn_id in ('00000197181978380655');

select * from LOCN_HDR where locn_id = '100442272';


select * from orders where tc_oder_id = '';
SELECT * from order_line_item where tc_order_id = '';
select lpn_facility_status from lpn where tc_lpn_id = '00000197181929674734';
select * from lpn_detail where tc_lpn_id = '';