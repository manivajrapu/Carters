alter session set current_schema = DM;

select tc_lpn_id, lpn_facility_status,lpn_id,total_lpn_qty ,tc_order_id,last_updated_source,manifest_nbr from dm.lpn
where tc_lpn_id in ('970066535382','970066664406','970066877344','970066890096');
00000970066535382
00000970066664406
00000970066877344
00000970066890096


select lpn_facility_status from lpn where tc_lpn_id='00000197181342428716';
select count(*) from lpn_lock where tc_lpn_id in ('00000197181332844755');
select TC_ORDER_ID from dm.lpn where tc_lpn_id in ('00000197181556377558');
select * from DM.LPN_DETAIL where lpn_id = '65470958' and lpn_detail_status < '90'; 
select order_id,do_status,order_type from orders where tc_order_id = '1220906387';

select * from DM.PICKING_SHORT_ITEM where tc_lpn_id in ('00000197181342428716') ;
select * from lpn_lock where tc_lpn_id in ('00000197181342428716');
select * from DM.ALLOC_INVN_DTL where carton_nbr in('00000197181342428716') and stat_code<90;
select * from DM.TASK_DTL where carton_nbr in ('00000197181342428716') and stat_code<90;

select * from DM.TASK_DTL where ALLOC_INVN_DTL_ID='627604805';
select do_dtl_status from order_line_item where order_id='40335454' and do_dtl_status<150;
select * from lpn_detail where lpn_id='62039633';
select * from task_hdr where TASK_GENRTN_REF_NBR='201702070016001';

select * from task_hdr where TASK_CMPL_REF_NBR='201702070016001';

select tc_order_id, store_nbr, d_facility_alias_id, major_order_grp_attr, dc_ctr_nbr, created_dttm, last_updated_dttm, do_status
from orders where do_status < 190 and store_nbr != substr(d_facility_alias_id, -4) and order_type = 'SD';


select * from alloc_invn_dtl where cntr_nbr in ('970059456184','970059467904','970059468090','970059467905','970059468093') and stat_code < 90; 

select * from DM.ALLOC_INVN_DTL where cntr_nbr in  ('970063094195', '00000156740033897793', '970063135964', '970063135965', '970063202801')  and stat_code<90;


select * from alloc_invn_dtl where cntr_nbr in ('970063094195', '00000156740033897793', '970063135964', '970063135965', '970063202801') and stat_code < '90';
select * from TASK_DTL where cntr_nbr in ('970063094195', '00000156740033897793', '970063135964', '970063135965', '970063202801') and stat_code < '90';

select * from lpn where tc_lpn_id='00000197181557703899' and inbound_outbound_indicator='I'; 
