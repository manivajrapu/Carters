alter session SET Current_schema=DM;

select * from task_dtl where cntr_nbr = '00000197180058412330' and stat_code<90;
select * from alloc_invn_dtl where cntr_nbr = '00000197180058412330' and stat_code<90;

select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS, total_lpn_qty from lpn where TC_LPN_ID in ('00000197180058412330');

select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id, initial_qty, size_value, item_id, item_name from lpn_detail where lpn_id in ('165294246');

select wm_inventory_id,lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty from wm_inventory where TC_LPN_ID in ('00000197180058412330');

select allocatable, tc_lpn_id, INBOUND_OUTBOUND_INDICATOR,WM_INVENTORY_ID,LPN_ID,ON_HAND_QTY,lpn_detail_id
from wm_inventory where tc_lpn_id in ('00000197180011940665') and inbound_outbound_indicator = 'I';

select tc_lpn_id, single_line_lpn from lpn where TC_LPN_ID in ('00000197180006526065') and inbound_outbound_indicator = 'I';

select allocatable, tc_lpn_id, INBOUND_OUTBOUND_INDICATOR 
from wm_inventory where tc_lpn_id = '00000156741227411986' and inbound_outbound_indicator = 'I';

Update wm_inventory set allocatable = 'Y' where tc_lpn_id = '00000156741227411986' and inbound_outbound_indicator = 'I';

select allocatable, tc_lpn_id, INBOUND_OUTBOUND_INDICATOR 
from wm_inventory where tc_lpn_id = '00000156741227411986' and inbound_outbound_indicator = 'I'; 

Select * from alloc_invn_dtl where cntr_nbr = '00000156740078382797' and stat_code<90;

Select lpn_id, curr_sub_locn_id, tc_lpn_id, lpn_status, lpn_facility_status, total_lpn_qty from LPN where TC_LPN_ID = '00000197181861427634';

Select lpn_id, lpn_detail_status, lpn_detail_id, initial_qty, size_value, item_name from lpn_detail where lpn_id = '131542871';

select TC_LPN_ID, lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty,WM_INVENTORY_ID from wm_inventory where TC_LPN_ID = '00000197181861427634';


select * from LPN where tc_lpn_id = '00000197181800274107' and inbound_outbound_indicator = 'I';



select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS, total_lpn_qty from lpn where TC_LPN_ID = '00000197181860545902';

select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id, initial_qty, size_value, item_name from lpn_detail where lpn_id = '131359026';

select wm_inventory_id,lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty from wm_inventory where TC_LPN_ID   = '00000197181860545902';


select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS, total_lpn_qty from lpn where TC_LPN_ID = '00000156741227273041';

select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id, initial_qty, size_value, item_name from lpn_detail where lpn_id = '119404564';

select wm_inventory_id,lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty from wm_inventory where wm_inventory_id in ('205790649');

select allocatable, tc_lpn_id, INBOUND_OUTBOUND_INDICATOR 
from wm_inventory where tc_lpn_id = '00000156741227411054' and inbound_outbound_indicator = 'I';

select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS, total_lpn_qty from lpn where TC_LPN_ID = '00000156741227272471';

select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id, initial_qty, size_value, item_name from lpn_detail where lpn_id = '119404524';

select wm_inventory_id,lpn_id, LPN_DETAIL_ID, location_id, on_hand_qty, wm_allocated_qty from wm_inventory where TC_LPN_ID   = '00000156741227272518';


select l.tc_Lpn_id, l.last_updated_dttm, l.lpn_facility_status, im.item_name, ld.size_value
from lpn l, lpn_detail ld, wm_inventory wm, item_cbo im 
  where im.item_id = wm.item_id and ld.lpn_detail_id = wm.lpn_detail_id and l.lpn_id = ld.lpn_id
     and l.lpn_facility_status = 99 and l.inbound_outbound_indicator = 'I' and ld.size_value > 0 and l.last_updated_dttm > sysdate - 30
     and not exists (select 1 from asn a where a.tc_asn_id = l.tc_asn_id and a.asn_status = '60' );
     
     
     
     
     
     SELECT * FROM 
---------------------------WMOS OPEN ORDER STATUS REPORT V2
(
select * from
-----10/29 changes---adding PO percent download to report
(SELECT * FROM 
(SELECT dept,substr(TO_CHAR(START_SHIP_DATE,'MM/DD/YYYY'),7,10) as start_year,substr(TO_CHAR(download_DATE,'MM/DD/YYYY'),7,10) as download_year,substr(TO_CHAR(STOP_SHIP_DATE,'MM/DD/YYYY'),7,10) as stop_year,nvl(fcp_type,'No') as fcp_type,whse,
CASE when whse = '19' then 'OshKosh' WHEN nvl(terr_code,'001') = '001' then 'Carters' 
WHEN nvl(terr_code,'001') = '002' then 'OshKosh' when SUBSTR(substr(PICK_WAVE_NBR,14,100),1,1) = 'O' THEN 'OshKosh' else 'Carters' end as Division,
SUM(NVL(CARTONS,0)) AS CARTONS,NVL(MERCH_CLASS,'NO MERCH CLASS') MERCH_CLASS,
substr(PICK_WAVE_NBR,1,12) AS WAVE_NBR,SOLDTO,SOLDTO_NAME,
NVL(FREIGHT_TERMS,'None') as freight_terms,SUM(nvl(UNPACKED_QTY,0))/12 AS UNPACKED_QTY,SUM(nvl(PACKED_QTY,0))/12 AS PACKED_QTY,
SUM(nvl(STAGED_QTY,0))/12 AS STAGED_QTY,SUM(nvl(LOADED_MANF_QTY,0))/12 AS LOADED_MANF_QTY,
SUM(nvl(TOTAL_QTY,0))/12 AS TOTAL_QTY,nvl(TO_CHAR(SHIP_DATE,'MM/DD/YYYY'),'None') AS SHIP_DATE,
nvl(SHIP_DATE,sysdate) AS SHIP_DATE_TIME,
SUM(NVL(UNPACKED_DOLLAR,0)) AS UNPACKED_DOLLAR,SUM(NVL(PACKED_DOLLAR,0)) AS PACKED_DOLLAR,
SUM(NVL(STAGED_DOLLAR,0)) AS STAGED_DOLLAR,SUM(NVL(LOADED_MANF_DOLLAR,0)) AS LOADED_MANF_DOLLAR,
SUM(NVL(TOTAL_DOLLAR,0)) AS TOTAL_DOLLAR,NVL(CARTON_STATUS,0) AS CARTON_STATUS,NVL(LOAD_NBR,'No Load Nbr') AS LOAD_NBR,nvl(SHIP_VIA_DESC,'No Carrier Assigned') as ship_via_desc,nvl(curr_plt_id,' ') as curr_plt_id,
TO_CHAR(START_SHIP_DATE,'MM/DD/YYYY') AS START_SHIP_DATE,TO_CHAR(download_date,'MM/DD/YYYY') AS download_date,
TO_CHAR(nvl(STOP_SHIP_DATE,start_ship_date),'MM/DD/YYYY') AS STOP_SHIP_DATE,SHIPTO,PO_NBR,substr(PICK_WAVE_NBR,14,100) as wave_desc,
prod_group
FROM
(
-------------------waved orders
select dept,
	 case when ch.carton_nbr in (select carton_nbr from task_dtl where stat_code < 99 and invn_need_type = 2)
then 'FCP' else 'No' end as fcp_type,ph.whse,COUNT(DISTINCT(CH.CARTON_NBR)) AS CARTONS,NVL(ph.merch_class, 'RT') MERCH_CLASS, 
phi.PICK_WAVE_NBR||' '||wp.wave_desc PICK_WAVE_NBR, 
decode(merch_class,null,'249380','CR','249380',ph.SOLDTO) SOLDTO,
CASE WHEN NVL(PH.SHIP_VIA,'ZZZ') = 'DCB' AND NVL(spl_instr_2,'001') = '001' THEN 'CARTER RETAIL DCB'
WHEN NVL(PH.SHIP_VIA,'ZZZ') = 'DCB' AND NVL(spl_instr_2,'001') = '002' then 'OSHKOSH RETAIL DCB'  
WHEN NVL(spl_instr_2,'001') = '001' THEN  decode(merch_class,null,'CARTER RETAIL','CR','CARTERS E-COMMERCE',ph.SOLDTO_NAME)
WHEN NVL(spl_instr_2,'001') = '002' THEN  decode(merch_class,null,'OSHKOSH RETAIL','CR','OSHKOSH E-COMMERCE',ph.SOLDTO_NAME)
ELSE SOLDTO_NAME END AS SOLDTO_NAME, 
decode(merch_class,null,'PICK PACK',decode(intl_goods_desc,null,ph.CUST_PO_NBR,'Master PO - '||intl_goods_desc)) PO_NBR, 
ph.FREIGHT_TERMS, 
sum(case when ch.STAT_CODE < 20 then cd.TO_BE_PAKD_UNITS - cd.UNITS_PAKD else 0 end) UNPACKED_QTY, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is null then cd.UNITS_PAKD else 0 end) PACKED_QTY, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is not null then cd.UNITS_PAKD else 0 end) STAGED_QTY, 
sum(case when ch.STAT_CODE >= 40 then cd.UNITS_PAKD else 0 end) LOADED_MANF_QTY, 
sum(case when ch.STAT_CODE < 20 then cd.TO_BE_PAKD_UNITS else cd.UNITS_PAKD end) TOTAL_QTY, 
sum(case when ch.STAT_CODE < 20 then (cd.TO_BE_PAKD_UNITS - cd.UNITS_PAKD)*PRICE else 0 end) UNPACKED_DOLLAR, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is null then cd.UNITS_PAKD*PRICE else 0 end) PACKED_DOLLAR, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is not null then cd.UNITS_PAKD*PRICE else 0 end) STAGED_DOLLAR, 
sum(case when ch.STAT_CODE >= 40 then cd.UNITS_PAKD*PRICE else 0 end) LOADED_MANF_DOLLAR, 
sum(case when ch.STAT_CODE < 20 then cd.TO_BE_PAKD_UNITS*PRICE else cd.UNITS_PAKD*PRICE end) TOTAL_DOLLAR,
case when ch.stat_code = 10 then 'Printed'
when ch.stat_code = 15 then 'In Packing'
when ch.stat_code = 20 and curr_locn_id is not null then 'Staged'
when ch.stat_code = 20 then 'Packed'
when ch.stat_code = 30 and curr_locn_id is not null then 'Staged'
when ch.stat_code = 30 then 'Weighed'
when ch.stat_code = 40 then 'LOADED_MANF'
when ch.stat_code = 50 then 'LOADED_MANF' 
when ch.stat_code = 90 then 'Shipped'
else 'Other Status' end as Carton_status,nvl(ch.load_nbr,'No Load Nbr') as load_nbr,ship_via_desc,curr_plt_id,
ph.start_ship_date,ph.create_date_time as download_date,nvl(ph.stop_ship_date,ph.start_ship_date) as stop_ship_date,shipto,ol.xpct_start_date_time as ship_date,prod_group,NVL(TERR_CODE,'001') AS TERR_CODE
from pkt_hdr ph, pkt_hdr_intrnl phi, carton_hdr ch, carton_dtl cd, pkt_dtl pd, wave_parm wp,
OUTBD_LOAD OL, item_master im,ship_via sv,
-----------------
(SELECT        /*+ all_rows index(aid alloc_invn_dtl_ind_5) index(lh pk_locn_hdr) */
          -- added hint alw 11/04/08
          DISTINCT
          aid.carton_nbr,
          CASE
  when instr(locn_brcd,'B005') > 0 and instr(wave_desc,'NDC')> 0 then ' EXTERNAL NDC'
  when instr(locn_brcd,'B005') > 0 and instr(wave_desc,'3PL')> 0 then ' EXTERNAL 3PL'
  when CH.WHSE <> 22 AND instr(locn_brcd,'B002') > 0 and (instr(LOCN_BRCD,'G')> 0 OR 
  instr(LOCN_BRCD,'H')> 0 OR instr(LOCN_BRCD,'I')> 0) and (instr(wave_desc,'PC') > 0 or
  instr(wave_desc,'PD') > 0) THEN 
  'PICK MOD 1'
WHEN (instr(locn_brcd,'RT37') > 0 OR instr(locn_brcd,'RT38') > 0 OR instr(locn_brcd,'RT39') > 0 OR instr(locn_brcd,'RT40') > 0) 
-- Added OSV CRT RETAIL Department
             THEN 'OSV CRT RETAIL'
             WHEN (instr(locn_brcd,'RT35') > 0 OR instr(locn_brcd,'RT36') > 0)                                                                                                    -- Added OSV OBG Retail Department 
             THEN 'OSV OBG RETAIL'
             WHEN CODE_ID = 'B0'
             THEN
                code_DESC || ' ' || SUBSTR (aisle, 4, 1)
             WHEN CODE_ID = 'BB'
             THEN
                code_DESC || ' ' || SUBSTR (aisle, 4, 1)
             ELSE
                code_desc
          END
             AS dept,
          aid.carton_seq_nbr,
          aid.pkt_ctrl_nbr,
          aid.pkt_seq_nbr
   FROM   alloc_invn_dtl aid,
          carton_hdr ch,WAVE_PARM WP,
          locn_hdr lh,
          (SELECT   code_id, code_desc
             FROM   sys_code
            WHERE   code_type = 'DPT' AND rec_type = 'C') SC
  WHERE       invn_need_type IN (2, 50, 54, 503)
          AND aid.stat_code < 99
          AND aid.carton_nbr = ch.carton_nbr
		  AND CH.WAVE_NBR = WP.WAVE_NBR(+)
          AND ch.stat_code < 90
          AND aid.pull_locn_id = lh.locn_id
          AND SUBSTR (lh.locn_brcd, 1, 2) = SC.CODE_ID(+);




-----------------------Unallocatable inventory--------------------------

------------------------------------------------------
select allocatable from wm_inventory where tc_lpn_id in ('00000156741229325977', '00000156741229291845', '00000156741229348938', '00000156741229370939', '00000156741229372988', '00000156741229373183', '00000156741229367113', '00000156741229373022', '00000156741229372360') and inbound_outbound_indicator = 'I';

---------wm_inventory
select allocatable, tc_lpn_id, INBOUND_OUTBOUND_INDICATOR,WM_INVENTORY_ID,LPN_ID,ON_HAND_QTY,lpn_detail_id
from wm_inventory where tc_lpn_id in ('00000156741229389368') and inbound_outbound_indicator = 'I';

-------lpn_detail

select lpn_id, LPN_DETAIL_STATUS, lpn_detail_id, initial_qty, size_value, item_name from lpn_detail where lpn_id = '143375070';

--------lpn
select lpn_id, CURR_SUB_LOCN_ID, TC_LPN_ID, LPN_STATUS, LPN_FACILITY_STATUS, total_lpn_qty from lpn where TC_LPN_ID in ('00000156741229389368');