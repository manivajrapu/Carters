alter session SET Current_schema=DM;

select invc_batch_nbr, count(*) ORDERS from dm.outpt_orders where proc_stat_code < 90 and created_dttm < sysdate - 1/24 group by invc_batch_nbr;

Select batch_ctrl_nbr, proc_stat_code, tc_order_id from outpt_orders where batch_ctrl_nbr in ('122046715');---121556465,121556466

Select * from outpt_orders where batch_ctrl_nbr in ('122046715');

Select * from outpt_order_line_item where batch_ctrl_nbr in ('122046715');---7997

select invc_batch_nbr,tc_lpn_id,proc_stat_code, tc_order_id, last_updated_dttm from outpt_lpn where invc_batch_nbr in ('122046715');---945

select * from outpt_lpn_detail where invc_batch_nbr in ('121556465');--7942

select tc_order_id from outpt_orders oo where invc_batch_nbr = '121556465' and not exists 
(select 1 from outpt_order_line_item oli where oo.INVC_BATCH_NBR = oli.invc_batch_nbr and oo.tc_order_id = oli.tc_order_id);-----CAR45246693_1

select do_status, tc_order_id from orders where tc_order_id in ('CAR42972489_1');
select * from lpn where tc_lpn_id in ('00000197183967410510', '00000197183967410350', '00000197183967410572', '00000197183967410466', '00000197183967410435', '00000197183967410558', '00000197183967410589', '00000197183967410381', '00000197183967410411', '00000197183967410398', '00000197183967410541', '00000197183967410343', '00000197183967410596', '00000197183967410367', '00000197183967410442', '00000197183967410374', '00000197183967410473', '00000197183967410527', '00000197183967410503', '00000197183967410480', '00000197183967410428');

---------------Checks
Select acct_rcvbl_acct_nbr, ext_purchase_order, proc_stat_code,batch_ctrl_nbr,created_dttm,created_source,tc_order_id from outpt_orders where batch_ctrl_nbr = '120686445';
Select proc_stat_code,batch_ctrl_nbr,created_dttm,created_source, invc_batch_nbr from outpt_order_line_item where batch_ctrl_nbr = '120686445';
select proc_stat_code,tc_lpn_id,tc_order_id from outpt_lpn where invc_batch_nbr='120686445';
select proc_stat_code, invc_batch_nbr, created_dttm, lpn_detail_id from outpt_lpn_detail where invc_batch_nbr='120686445';
select lpn_facility_status, last_updated_source, tc_order_id from lpn where tc_lpn_id in ('00000197181484335965','00000197181484337068','00000197181484287547','00000197181484288445','00000197181484292213');
select do_status from orders where tc_order_id in ('CAR21803912_1','CAR21806827_1','CAR21802936_1','CAR21799933_1','ICAR21803101_1');


Select acct_rcvbl_acct_nbr, ext_purchase_order,do_status created_dttm,created_source,tc_order_id from orders where invc_batch_nbr = '120686445';
Select proc_stat_code,batch_ctrl_nbr,created_dttm,created_source, invc_batch_nbr from order_line_item where batch_ctrl_nbr = '120686445';
select proc_stat_code,tc_lpn_id,tc_order_id from lpn where invc_batch_nbr='120686445';
select proc_stat_code, invc_batch_nbr, created_dttm, lpn_detail_id from lpn_detail where invc_batch_nbr='120686445';


select * from lpn where tc_lpn_id in ('00000197181555033516','00000197181555033622','00000197181555033691','00000197181555033769','00000197181555033783','00000197181555033813','00000197181555033844','00000197181555033875');

select * from manifest_hdr where tc_manifest_id in ('FXEX000003784','FXEX000003785');

select invc_batch_nbr, count(*) ORDERS from dm.outpt_orders where proc_stat_code < 90 and created_dttm < sysdate - 1/24 group by invc_batch_nbr;

select tc_order_id from outpt_orders oo where invc_batch_nbr = '121871991' 
and not exists (select 1 from outpt_order_line_item oli where oo.invc_batch_nbr = oli.invc_batch_nbr and oo.tc_order_id = oli.tc_order_id);

select * from outpt_orders where tc_order_id='BCAR42996749_1' and batch_ctrl_nbr='121464214';

select * from outpt_lpn where tc_order_id='BCAR42996749_1' and invc_batch_nbr='121464214';

select * from outpt_lpn_detail where minor_po_nbr='BCAR42996749_1' and invc_batch_nbr='121464214';

select * from DM.OUTPT_ORDER_LINE_ITEM where tc_order_id='BCAR42996749_1' and invc_batch_nbr='121464214';

select * from sys_code where code_type in ('CCF');

select invc_batch_nbr, count(*) ORDERS from dm.outpt_orders where proc_stat_code < 90 and created_dttm < sysdate - 1/24 group by invc_batch_nbr;

select * from outpt_orders where batch_ctrl_nbr='121871991'; -------1
select * from DM.OUTPT_ORDER_LINE_ITEM where invc_batch_nbr='121871991'; --------3
select * from outpt_lpn where invc_batch_nbr='121871991'; ---------2
select * from outpt_lpn_detail where invc_batch_nbr='121871991'; ---------4  



-------------------------------------------------------------------------------------------

SELECT * FROM 
---------------------------WMOS OPEN ORDER STATUS REPORT V2
(
select * from
-----10/29 changes---adding PO percent download to report
(SELECT * FROM 
(SELECT dept,substr(TO_CHAR(START_SHIP_DATE,'MM/DD/YYYY'),7,10) as start_year,substr(TO_CHAR(download_DATE,'MM/DD/YYYY'),7,10) as download_year,substr(TO_CHAR(STOP_SHIP_DATE,'MM/DD/YYYY'),7,10) as stop_year,nvl(fcp_type,'No') as fcp_type,whse,
CASE when whse = '19' then 'OshKosh' WHEN nvl(terr_code,'001') = '001' then 'Carters' 
WHEN nvl(terr_code,'001') = '002' then 'OshKosh' when SUBSTR(substr(PICK_WAVE_NBR,14,100),1,1) = 'O' THEN 'OshKosh' else 'Carters' end as Division,
SUM(NVL(CARTONS,0)) AS CARTONS,NVL(MERCH_CLASS,'NO MERCH CLASS') MERCH_CLASS,
substr(PICK_WAVE_NBR,1,12) AS WAVE_NBR,SOLDTO,SOLDTO_NAME,
NVL(FREIGHT_TERMS,'None') as freight_terms,SUM(nvl(UNPACKED_QTY,0))/12 AS UNPACKED_QTY,SUM(nvl(PACKED_QTY,0))/12 AS PACKED_QTY,
SUM(nvl(STAGED_QTY,0))/12 AS STAGED_QTY,SUM(nvl(LOADED_MANF_QTY,0))/12 AS LOADED_MANF_QTY,
SUM(nvl(TOTAL_QTY,0))/12 AS TOTAL_QTY,nvl(TO_CHAR(SHIP_DATE,'MM/DD/YYYY'),'None') AS SHIP_DATE,
nvl(SHIP_DATE,sysdate) AS SHIP_DATE_TIME,
SUM(NVL(UNPACKED_DOLLAR,0)) AS UNPACKED_DOLLAR,SUM(NVL(PACKED_DOLLAR,0)) AS PACKED_DOLLAR,
SUM(NVL(STAGED_DOLLAR,0)) AS STAGED_DOLLAR,SUM(NVL(LOADED_MANF_DOLLAR,0)) AS LOADED_MANF_DOLLAR,
SUM(NVL(TOTAL_DOLLAR,0)) AS TOTAL_DOLLAR,NVL(CARTON_STATUS,0) AS CARTON_STATUS,NVL(LOAD_NBR,'No Load Nbr') AS LOAD_NBR,nvl(SHIP_VIA_DESC,'No Carrier Assigned') as ship_via_desc,nvl(curr_plt_id,' ') as curr_plt_id,
TO_CHAR(START_SHIP_DATE,'MM/DD/YYYY') AS START_SHIP_DATE,TO_CHAR(download_date,'MM/DD/YYYY') AS download_date,
TO_CHAR(nvl(STOP_SHIP_DATE,start_ship_date),'MM/DD/YYYY') AS STOP_SHIP_DATE,SHIPTO,PO_NBR,substr(PICK_WAVE_NBR,14,100) as wave_desc,
prod_group
FROM
(
-------------------waved orders
select dept,
	 case when ch.carton_nbr in (select carton_nbr from task_dtl where stat_code < 99 and invn_need_type = 2)
then 'FCP' else 'No' end as fcp_type,ph.whse,COUNT(DISTINCT(CH.CARTON_NBR)) AS CARTONS,NVL(ph.merch_class, 'RT') MERCH_CLASS, 
phi.PICK_WAVE_NBR||' '||wp.wave_desc PICK_WAVE_NBR, 
decode(merch_class,null,'249380','CR','249380',ph.SOLDTO) SOLDTO,
CASE WHEN NVL(PH.SHIP_VIA,'ZZZ') = 'DCB' AND NVL(spl_instr_2,'001') = '001' THEN 'CARTER RETAIL DCB'
WHEN NVL(PH.SHIP_VIA,'ZZZ') = 'DCB' AND NVL(spl_instr_2,'001') = '002' then 'OSHKOSH RETAIL DCB'  
WHEN NVL(spl_instr_2,'001') = '001' THEN  decode(merch_class,null,'CARTER RETAIL','CR','CARTERS E-COMMERCE',ph.SOLDTO_NAME)
WHEN NVL(spl_instr_2,'001') = '002' THEN  decode(merch_class,null,'OSHKOSH RETAIL','CR','OSHKOSH E-COMMERCE',ph.SOLDTO_NAME)
ELSE SOLDTO_NAME END AS SOLDTO_NAME, 
decode(merch_class,null,'PICK PACK',decode(intl_goods_desc,null,ph.CUST_PO_NBR,'Master PO - '||intl_goods_desc)) PO_NBR, 
ph.FREIGHT_TERMS, 
sum(case when ch.STAT_CODE < 20 then cd.TO_BE_PAKD_UNITS - cd.UNITS_PAKD else 0 end) UNPACKED_QTY, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is null then cd.UNITS_PAKD else 0 end) PACKED_QTY, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is not null then cd.UNITS_PAKD else 0 end) STAGED_QTY, 
sum(case when ch.STAT_CODE >= 40 then cd.UNITS_PAKD else 0 end) LOADED_MANF_QTY, 
sum(case when ch.STAT_CODE < 20 then cd.TO_BE_PAKD_UNITS else cd.UNITS_PAKD end) TOTAL_QTY, 
sum(case when ch.STAT_CODE < 20 then (cd.TO_BE_PAKD_UNITS - cd.UNITS_PAKD)*PRICE else 0 end) UNPACKED_DOLLAR, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is null then cd.UNITS_PAKD*PRICE else 0 end) PACKED_DOLLAR, 
sum(case when ch.STAT_CODE < 40 and curr_locn_id is not null then cd.UNITS_PAKD*PRICE else 0 end) STAGED_DOLLAR, 
sum(case when ch.STAT_CODE >= 40 then cd.UNITS_PAKD*PRICE else 0 end) LOADED_MANF_DOLLAR, 
sum(case when ch.STAT_CODE < 20 then cd.TO_BE_PAKD_UNITS*PRICE else cd.UNITS_PAKD*PRICE end) TOTAL_DOLLAR,
case when ch.stat_code = 10 then 'Printed'
when ch.stat_code = 15 then 'In Packing'
when ch.stat_code = 20 and curr_locn_id is not null then 'Staged'
when ch.stat_code = 20 then 'Packed'
when ch.stat_code = 30 and curr_locn_id is not null then 'Staged'
when ch.stat_code = 30 then 'Weighed'
when ch.stat_code = 40 then 'LOADED_MANF'
when ch.stat_code = 50 then 'LOADED_MANF' 
when ch.stat_code = 90 then 'Shipped'
else 'Other Status' end as Carton_status,nvl(ch.load_nbr,'No Load Nbr') as load_nbr,ship_via_desc,curr_plt_id,
ph.start_ship_date,ph.create_date_time as download_date,nvl(ph.stop_ship_date,ph.start_ship_date) as stop_ship_date,shipto,ol.xpct_start_date_time as ship_date,prod_group,NVL(TERR_CODE,'001') AS TERR_CODE
from pkt_hdr ph, pkt_hdr_intrnl phi, carton_hdr ch, carton_dtl cd, pkt_dtl pd, wave_parm wp,
OUTBD_LOAD OL, item_master im,ship_via sv,
-----------------
(SELECT        /*+ all_rows index(aid alloc_invn_dtl_ind_5) index(lh pk_locn_hdr) */
          -- added hint alw 11/04/08
          DISTINCT
          aid.carton_nbr,
          CASE
  when instr(locn_brcd,'B005') > 0 and instr(wave_desc,'NDC')> 0 then ' EXTERNAL NDC'
  when instr(locn_brcd,'B005') > 0 and instr(wave_desc,'3PL')> 0 then ' EXTERNAL 3PL'
  when CH.WHSE <> 22 AND instr(locn_brcd,'B002') > 0 and (instr(LOCN_BRCD,'G')> 0 OR 
  instr(LOCN_BRCD,'H')> 0 OR instr(LOCN_BRCD,'I')> 0) and (instr(wave_desc,'PC') > 0 or
  instr(wave_desc,'PD') > 0) THEN 
  'PICK MOD 1'
WHEN (instr(locn_brcd,'RT37') > 0 OR instr(locn_brcd,'RT38') > 0 OR instr(locn_brcd,'RT39') > 0 OR instr(locn_brcd,'RT40') > 0) 
-- Added OSV CRT RETAIL Department
             THEN 'OSV CRT RETAIL'
             WHEN (instr(locn_brcd,'RT35') > 0 OR instr(locn_brcd,'RT36') > 0)                                                                                                    -- Added OSV OBG Retail Department 
             THEN 'OSV OBG RETAIL'
             WHEN CODE_ID = 'B0'
             THEN
                code_DESC || ' ' || SUBSTR (aisle, 4, 1)
             WHEN CODE_ID = 'BB'
             THEN
                code_DESC || ' ' || SUBSTR (aisle, 4, 1)
             ELSE
                code_desc
          END
             AS dept,
          aid.carton_seq_nbr,
          aid.pkt_ctrl_nbr,
          aid.pkt_seq_nbr
   FROM   alloc_invn_dtl aid,
          carton_hdr ch,WAVE_PARM WP,
          locn_hdr lh,
          (SELECT   code_id, code_desc
             FROM   sys_code
            WHERE   code_type = 'DPT' AND rec_type = 'C') SC
  WHERE       invn_need_type IN (2, 50, 54, 503)
          AND aid.stat_code < 99
          AND aid.carton_nbr = ch.carton_nbr
		  AND CH.WAVE_NBR = WP.WAVE_NBR(+)
          AND ch.stat_code < 90
          AND aid.pull_locn_id = lh.locn_id
          AND SUBSTR (lh.locn_brcd, 1, 2) = SC.CODE_ID(+)