select i.WHSECODE, sum(i.ONHANDQTY), SUM(ABS(a.OHQTYVARIANCE)), SUM(ABS(a.NAQTYVARIANCE)), (Select count(*) AS SKUCOUNT

From(

select distinct prodcode, sizedesc from WM_INBOUND_PIX605_AGED
)
) AS SKU

from INVWHSUM i INNER JOIN WM_INBOUND_PIX605_AGED a

on i.PRODCODE = a.PRODCODE 

WHERE a.warehouse=i.WHSECODE

AND i.WHSECODE in ('12','33','44','60','70','72','74')

GROUP BY i.WHSECODE

NATURAL JOIN

Select count(*) AS SKUCOUNT,warehouse

From(

select distinct prodcode, sizedesc, warehouse from WM_INBOUND_PIX605_AGED
)group by warehouse

having warehouse in ('12','33','44','60','70','72','74');



-----------------------------------------------------------------------------------------------


select * from TRAN_LOG where MSG_TYPE = 'ASN';

select * from TRAN_LOG_MESSAGE where TRAN_LOG_ID = '609476084';

select * from ASN where tc_asn_id = 'OFSTESTING3';

select * from ASN_DETAIL where ASN_ID = '641291';

select LPN_FACILITY_STATUS, lpn.* from LPN where TC_ASN_ID = 'OFSTESTING3';

select * from LPN_DETAIL where LPN_id in (select lpn_id from LPN where TC_ASN_ID = 'OFSTESTING3');

select * from dock_door where DOCK_DOOR_NAME = 'DCKDR112A';


