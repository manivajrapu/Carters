---Please ship confirm
alter session SET Current_schema=DM;
--Kal Query--

select manifest_nbr, substr(tc_shipment_id,10,1) "SHIPMENT_ENDING", lpn_facility_status, count(*) 
from lpn where manifest_nbr = 'UPS000013132' 
and lpn_facility_status < 99 group by manifest_nbr, substr(tc_shipment_id,10,1), lpn_facility_status;

select manifest_nbr, substr(tc_shipment_id,10,1) "SHIPMENT_ENDING", lpn_facility_status, count(*) 
from lpn where manifest_nbr = 'UPS000013128' 
and lpn_facility_status < 99 group by manifest_nbr, substr(tc_shipment_id,10,1), lpn_facility_status;

select * from lpn where manifest_nbr in ('UPS000013128','UPS000013132') and lpn_facility_status<'90';
select * from lpn where manifest_nbr in ('UPS000013128','UPS000013132') and tracking_nbr is null;
select * from manifest_hdr where tc_manifest_id in ('UPS000013128','UPS000013132');--38547,38551
select * from manifested_lpn where manifest_id in ('38547','38551') and status < '40';

--Fletcher Query
select l.tc_lpn_id, l.manifest_nbr, mh2.tc_manifest_id, mh2.manifest_id, ml.tc_lpn_id, ml.manifest_id, mh.manifest_id, mh.tc_manifest_id
from lpn l, manifested_lpn ml, manifest_hdr mh, manifest_hdr mh2 where l.tc_lpn_id = ml.tc_lpn_id and ml.manifest_id = mh.manifest_id and l.manifest_nbr = mh2.tc_manifest_id
and l.lpn_facility_status < 90
and (mh2.tc_manifest_id <> mh.tc_manifest_id or mh2.manifest_id <> ml.manifest_id);































select distinct(tc_order_id) from dm.lpn where manifest_nbr in ('UPS000008898','UPS000008899') and lpn_facility_status='90';

select * from dm.orders where tc_order_id='27606474';

select * from dm.outpt_orders where ext_purchase_order='10255656';

select * from dm.outpt_order_line_item where invc_batch_nbr='120578498' and proc_stat_code<'90';

select * from outpt_lpn where invc_batch_nbr='120578498' and proc_stat_code<'90';

Select * from dm.outpt_lpn_detail where invc_batch_nbr ='120578498' and proc_stat_code<'90';

Select tran_log.tran_log_id, sequence_number, msg_line_number, tran_log.created_dttm, msg_line_text
from tran_log, tran_log_message
where tran_log.tran_log_id = tran_log_message.tran_log_id
      and msg_line_text like '%120578498%'
and tran_log.created_dttm >= to_date('3/28/2016','mm/dd/yyyy') and tran_log.created_dttm < to_date('2/19/2017','mm/dd/yyyy')
and tran_log.msg_type = 'ShipConfirm';

Select * from pix_tran where ref_field_1 = 'CAR17590564_1';

select * from dm.manifest_hdr where tc_manifest_id in ('UPS000008898','UPS000008899');








Select unique oo.tc_order_id, oo.invc_batch_nbr, oo.created_dttm, ool.item_name, ool.batch_nbr, ool.shipped_qty, ool.user_canceled_qty, oo.proc_stat_code
from outpt_orders oo join outpt_order_line_item ool  on oo.tc_order_id = ool.tc_order_id and oo.invc_batch_nbr = ool.invc_batch_nbr
and (oo.tc_order_id = '10248816' );




select * from manifest_hdr where tc_manifest_id in ('UPS000008898','UPS000008899');