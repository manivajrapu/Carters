select proc_stat_code, error_seq_nbr from inpt_store_master where proc_stat_code=10;
180968049
180968050
180968051
180968036

select * from msg_log where ref_value_1='180968036';
select distinct error_seq_nbr,proc_stat_code from inpt_store_master;
--update inpt_store_master set proc_stat_code= 0 ,error_seq_nbr=0 where proc_stat_code=10;

rollback;
--commit;

select * from INPT_STORE_MASTER;


select * from asn_hdr where po_nbr='160754016';
select * from asn_dtl where po_nbr='160754016';

select * from asn_hdr;
SELECT proc_stat_code,stat_code,error_seq_nbr FROM INPT_ASN_HDR;--210923003
select * from ASN_HDR where SHPMT_NBR='214642001';
select * from CASE_HDR where ORIG_SHPMT_NBR='214642001';--212889001,213265002
select * from inpt_asn_hdr;
select * from msg_log where REF_VALUE_1='178971417';--331913151
select PROC_STAT_CODE,ERROR_SEQ_NBR from INPT_IMMD_NEEDS;--331913201--211957001
select * from INPT_IMMD_NEEDS;
select * from IMMD_NEEDS where IMMD_NEED_ID='331913201';--116949587--331913201
select* from item_master where STYLE='OF170740' and STYLE_SFX='AST' and SEC_DIM is null and SIZE_DESC='12';
SELECT PROC_STAT_CODE,ERROR_SEQ_NBR,SHPMT_NBR,STAT_CODE FROM INPT_ASN_HDR;
select * from msg_log where ref_value_1 in('180856401');--Invalid Vendor 11567_CODE bridged for Case 00006644549816006771
select * from inpt_immd_needs where proc_stat_code >0;

select * from wave_parm where wave_nbr = '201704100093'; 
select * from orders where TC_ORDER_ID = 'ICAR26082134';
select * from orders where ext_purchase_order= 'ICAR26082134';
select do_status from orders where tc_order_id='ICAR26082134_1';

alter session set current_schema = DM;



Select item_name,item_bar_code from item_cbo where item_style='96204';
Select item_name,item_bar_code from dm.item_cbo where item_name='96204 MULTI 1224';



select /*+rule */ 
       ses.sid                      as sid, 
       ses.serial#                  as serial_num, 
       ses.process                  as process, 
       ses.sql_id                   as sql_id,
       ses.username                 as db_username, 
       pro.spid                     as host_pid, 
       ses.machine                  as machine, 
       substr(ses.program,1,60)     as program, 
       substr(obj.object_name,1,20) as object_name, 
       loc.lock_type                as lock_type, 
       ses.status                   as status, 
       loc.mode_held                as mode_held, 
       loc.mode_requested as mode_req, 
       to_char(trunc(sysdate) + loc.last_convert/(24*3600), 'HH24:MI:SS') as ctime, 
       loc.blocking_others          as is_blocking 
       from v$session ses, 
       v$process pro, 
       dba_lock loc, 
       dba_objects obj 
       where ses.sid      = loc.session_id 
              and ses.paddr    = pro.addr 
             and loc.lock_id1 = obj.object_id 
             and ses.username is not null 
           --  and substr(ses.program,1,60) Like 'PkShipWaveS%' --PkShipWaveS RF Activity Functionality
            order by ses.sid, ses.serial#, ses.process, ses.username;

