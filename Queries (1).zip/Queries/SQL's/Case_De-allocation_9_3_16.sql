select stat_code from case_hdr where case_nbr in ('00006644543313043086','00006644543313102202');

select actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in ('00006644543313043086','00006644543313102202');

select * from alloc_invn_dtl where cntr_nbr in ('00006644543313043086','00006644543313102202') and stat_code<'90';

select td.*
from  task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
   and aid.stat_code = '0'
  and aid.cntr_nbr='00006644543313043086'
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id
   and td.stat_code < '99'; 
 
select *
from task_hdr
where task_id in (select td.task_id
from task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
and aid.stat_code = '00'
and aid.cntr_nbr='00006644543313043086'
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id)
   and stat_code <'99';


select * from alloc_invn_dtl where cntr_nbr='00007160412305173103';

select * from alloc_invn_dtl where cntr_nbr='000000113618';