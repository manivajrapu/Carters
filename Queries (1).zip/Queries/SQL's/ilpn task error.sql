alter session SET Current_schema=DM;

select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;

---vishwa query for cntr_nbr----
select ic.item_id,ic.item_name,ic.item_bar_code,pt.cntr_nbr,pt.task_id,pt.MOD_DATE_TIME
from prod_trkg_tran pt 
join item_cbo ic on ic.item_id=pt.item_id
where task_id in ('41749453') order by MOD_DATE_TIME desc;
select * from task_dtl where task_id in ('19100316');




select task_id, task_seq_nbr, cntr_nbr, create_date_time, mod_date_time, user_id,item_id, stat_code from task_dtl where task_id ='29217495'
and stat_code = '40' and cntr_nbr is null order by mod_date_time desc;

select cntr_nbr from task_dtl where task_id = '29217495' and stat_code = 40 and cntr_Nbr is null;

select * from v$session where sql_id = 'csm9s82psthrr';

select * from task_dtl where task_id = '19100316' and task_seq_nbr = '32';_
--96407960
--970100014128


select task_id, cntr_nbr, create_date_time, mod_date_time, user_id,item_id from task_dtl where task_id ='19100316'
and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc; 

select td.task_id, td.cntr_nbr, im.item_name, im.item_bar_code, td.batch_nbr, td.qty_alloc, td.stat_code, td.user_id, td.mod_date_time,
        (select max(cntr_nbr) ||', '||min(cntr_nbr) from task_dtl td2 where td2.task_id = td.task_id and td2.cntr_nbr is not null and td2.stat_code = 40) "EXPECTED TOTE NBR"
from task_hdr th, task_dtl td, item_cbo im where th.task_id = td.task_id and td.item_id = im.item_id
and th.task_type = '93' and td.stat_code = 40 and td.invn_need_type = 3 and td.cntr_nbr is null;
--57148176
--970057148176, 970057148176

-----if there are two different container numbers-------------------------------------------------------
select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl 
where task_id ='18204860' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc;

select task_id, cntr_nbr, create_date_time, mod_date_time, user_id, task_seq_nbr from task_dtl 
where task_id ='10151320' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc;

select task_id,task_seq_nbr,cntr_nbr,invn_need_type,stat_code,task_type,user_id, qty_pulld from task_dtl 
where task_id ='10151320' and task_seq_nbr in ('1','2','3','4');
--------------------------------------------------------------------------------------------------------
SELECT L.TRAN_NBR "Transaction #",L.LOGIN_USER_ID "Login ID",U.USER_LAST_NAME "Last Name",U.USER_FIRST_NAME "First Name",L.ACT_NAME "Activity",D.DESCRIPTION "Department",S.DESCRIPTION "Shift",L.SCHED_START_DATE "Break Start", 
        L.ACTUAL_END_TIME "Break End",((L.ACTUAL_END_TIME - L.SCHED_START_DATE)*60)*24 "Total Time",U2.USER_NAME "Supervisor", J.DESCRIPTION "Job Function"
FROM E_EMP_DTL E
JOIN E_DEPT D ON E.DEPT_ID = D.DEPT_ID
JOIN E_SHIFT S ON S.SHIFT_ID = E.SHIFT_ID
JOIN UCL_USER U ON E.EMP_ID = U.UCL_USER_ID
JOIN UCL_USER U2 ON E.SPVSR_EMP_ID = U2.UCL_USER_ID
JOIN LABOR_MSG L ON U.USER_NAME = L.LOGIN_USER_ID
JOIN E_JOB_FUNCTION J ON J.JOB_FUNC_ID = E.JOB_FUNC_ID
WHERE L.SCHED_START_DATE > '26-MAR-17'
AND L.SCHED_START_DATE < '1-APR-17'
AND L.ACT_NAME = 'UNPAIDBRK';



Select DISTINCT(l.tc_lpn_id) from lpn l, lpn_detail ld, item_cbo im where l.lpn_id = ld.lpn_id and ld.item_id = im.item_id and im.item_bar_code in ('700140969778', '888737449503') and ld.batch_nbr = 'EC002'
and ld.size_value = 1 and l.lpn_facility_status = 64 and l.inbound_outbound_indicator = 'I';

select item_id from item_cbo where item_bar_code in ('190796063836', '190795039511');
select item_id,task_id, cntr_nbr, old_stat_code, new_stat_code,user_id, create_date_time, mod_date_time from prod_trkg_tran where item_id in ('2304695','2303379') and task_id='60216505';
select task_id, cntr_nbr, create_date_time, mod_date_time, user_id from task_dtl where task_id ='60216505' and stat_code = '40' and cntr_nbr is not null order by mod_date_time desc;
select * from task_dtl where task_id ='60216505' and stat_code = '40' and cntr_nbr is not null;
select * from task_dtl where task_id ='56196097' and stat_code = '40' and cntr_nbr is null;
select * from task_dtl where task_id ='55711291' and stat_code = '40' and cntr_nbr is null;

select * from lpn where tc_lpn_id ='00000156741227359868';
select * from alloc_invn_dtl where carton_nbr ='00000156741227359868' and stat_code<'90';
select l.tc_shipment_id, l.tc_order_id, l.tc_lpn_id
from lpn l, orders o where o.order_id = l.order_id and l.inbound_outbound_indicator = 'O' and o.do_status < 190 and lpn_facility_status = 90 and l.lpn_type = 1
and exists (select 1 from shipment s where s.tc_shipment_id = l.tc_shipment_id and s.shipment_status < 80 );

-----Orphaned

select aid.cntr_nbr, im.item_name, im.item_bar_code, aid.batch_nbr, aid.carton_nbr, aid.qty_alloc, aid.mod_date_time
from alloc_invn_dtl aid, lpn l, orders o, item_cbo im where l.tc_lpn_id = aid.cntr_nbr and aid.tc_order_id = o.tc_order_id and aid.item_id = im.item_id 
            and aid.invn_need_type = 52 and aid.stat_code = 0
and l.lpn_facility_status <> 64 and o.order_type = 'EC';

select * from lpn_detail where lpn_id='57391095';
select * from task_hdr where task_id='98014946';
select * from task_dtl where item_id in ('2731106') and task_id in ('96944349');
select distinct(cntr_nbr) from alloc_invn_dtl where item_id in ('2560358');
select * from lpn where wave_nbr='201611210027';
select * from lpn where tc_lpn_id in ('970100942558');

select * from DM.ITEM_CBO where ITEM_NAME in ('283G733 N 7');--2731106--100370093
select * from locn_hdr where pull_locn in ('100370093');

---vishwa query for cntr_nbr----
select ic.item_id,ic.item_name,ic.item_bar_code,pt.cntr_nbr,pt.task_id,pt.MOD_DATE_TIME
from prod_trkg_tran pt 
join item_cbo ic on ic.item_id=pt.item_id
where task_id in ('41749453') order by MOD_DATE_TIME desc;

-------------------Orders in planned status but lpns have null shipment number-------------- 
select tc_order_id, ext_purchase_order "PURCHASE_ORDER", bill_to_name "CUSTOMER", 
        addr_code "DIV", rte_to "ROUTE_TO", lane_name "LANE", tc_shipment_id "ORDERS_SHIPMENT_ID", count(*) "TOTAL_ORDERS"
from orders o where order_type not in ('EC','SD') and order_status = 10 and do_status < 190
and exists (select 1 from lpn l where l.order_id = o.order_id and l.lpn_Facility_status < 90 and tc_shipment_Id is null and inbound_outbound_Indicator = 'O')
group by  ext_purchase_order, bill_to_name, addr_code, rte_to, lane_name, tc_shipment_id, tc_order_id;

select tc_lpn_id,lpn_facility_status from lpn where tc_order_id in ('1246471148');

-------------------Duplicate tracking-----------------
 select l.tc_lpn_id,
    l.lpn_status,
    l.lpn_facility_status,
    l.tracking_nbr,
    l.manifest_nbr,
    l.tc_shipment_id,
    l.shipment_id,
    l.ship_via,
    l.tc_order_id,
    l.pack_wave_nbr,
    l.wave_nbr,
    o.bill_to_name,
    o.d_name,
    o.d_address_1,
    o.d_address_2,
    o.d_city,
    o.d_state_prov,
    o.d_postal_code,
    o.bill_to_phone_number,
    o.bill_to_email
FROM
    dm.lpn l,
    dm.orders o
WHERE
    l.lpn_facility_status = 90
    AND   l.tc_order_id = o.tc_order_id
    AND   o.has_split = 0
    AND   l.tracking_nbr IN (
        SELECT
            tracking_nbr
        FROM
            dm.lpn
        WHERE
            trunc(created_dttm) = trunc(SYSDATE)
        GROUP BY
            tracking_nbr
        HAVING
            COUNT(tracking_nbr) > 1
    )
ORDER BY
    l.tracking_nbr;
select DO_STATUS from orders tc_order_id in ('BCAR51532749', 'BCAR51579419', 'BCAR51586168', 'BCAR51586176', 'BCAR51586218', 'BCAR51586453', 'BCAR51586504', 'BCAR51586530', 'BCAR51586535', 'BCAR51586640', 'BCAR51586759', 'BCAR51586909', 'BCAR51586964', 'BCAR51586978', 'BCAR51587024', 'BCAR51587041', 'BCAR51587224', 'BCAR51587230', 'BCAR51587328', 'BCAR51587459', 'BCAR51587502', 'BCAR51587547', 'BCAR51587572', 'BCAR51588014', 'BCAR51588037', 'BCAR51588076', 'BCAR51588177', 'BCAR51588231', 'BCAR51588282', 'BCAR51588385', 'BCAR51588426', 'BCAR51588520', 'BCAR51588589', 'BCAR51588665', 'BCAR51588732', 'BCAR51588810', 'BCAR51588986', 'BCAR51589053', 'BCAR51589055', 'BCAR51589114', 'BCAR51589122', 'BCAR51589192', 'BCAR51589230', 'BCAR51589293', 'BCAR51589327', 'BCAR51589330', 'BCAR51589339', 'BCAR51589380', 'BCAR51589405', 'BCAR51589542', 'BCAR51589596', 'BCAR51589652', 'BCAR51589712', 'BCAR51589723', 'BCAR51589795', 'BCAR51589900', 'BCAR51589909', 'BCAR51589957', 'BCAR51589962', 'BCAR51590028', 'BCAR51590124', 'BCAR51590132', 'BCAR51590141', 'BCAR51590163', 'BCAR51590206', 'BCAR51590286', 'BCAR51590287', 'BCAR51590400', 'BCAR51590442', 'BCAR51590494', 'BCAR51590567', 'BCAR51590629', 'BCAR51590672', 'BCAR51590707', 'BCAR51590795', 'BCAR51590835', 'BCAR51590867', 'BCAR51590876', 'BCAR51590899', 'BCAR51590957', 'BCAR51591016', 'BCAR51591033', 'BCAR51591201', 'BCAR51591227', 'BCAR51591286', 'BCAR51591394', 'BCAR51591396', 'BCAR51591403', 'BCAR51591654', 'BCAR51591681', 'BCAR51591697', 'BCAR51591713', 'BCAR51591728', 'BCAR51591837', 'BCAR51591942', 'BCAR51591967', 'BCAR51592137', 'BCAR51592200', 'BCAR51592217', 'BCAR51592270', 'BCAR51592394', 'BCAR51592428', 'BCAR51592434', 'BCAR51592490', 'BCAR51592511', 'BCAR51592526', 'BCAR51592656', 'BCAR51592711', 'BCAR51592730', 'BCAR51592747', 'BCAR51592769', 'BCAR51592785', 'BCAR51592820', 'BCAR51592856', 'BCAR51592870', 'BCAR51592895', 'BCAR51592917', 'BCAR51592933', 'BCAR51592991', 'BCAR51593053', 'BCAR51593060', 'BCAR51593109', 'BCAR51593191', 'BCAR52069771', 'BCAR52080784', 'BCAR52081017', 'BCAR52081064', 'BCAR52083644', 'BCAR52176094', 'BCAR52234624', 'BCAR52329742', 'BCAR52342880', 'BCAR52344513', 'CAR51369440 ', 'CAR51370516 ', 'CAR51373338 ', 'CAR51376161 ', 'CAR51377768 ', 'CAR51378113 ', 'CAR51379113 ', 'CAR51390007 ', 'CAR51390093 ', 'CAR51392475 ', 'CAR51392689 ', 'CAR51393613 ', 'CAR51393997 ', 'CAR51403371 ', 'CAR51403545 ', 'CAR51405760 ', 'CAR51405914 ', 'CAR51406170 ', 'CAR51409557 ', 'CAR51413708 ', 'CAR51568740 ', 'CAR51585963 ', 'CAR51586029 ', 'CAR51586200 ', 'CAR51586221 ', 'CAR51586275 ', 'CAR51586306 ', 'CAR51586358 ', 'CAR51586373 ', 'CAR51586389 ', 'CAR51586408 ', 'CAR51586413 ', 'CAR51586441 ', 'CAR51586454 ', 'CAR51586455 ', 'CAR51586465 ', 'CAR51586472 ', 'CAR51586507 ', 'CAR51586525 ', 'CAR51586546 ', 'CAR51586586 ', 'CAR51586639 ', 'CAR51586657 ', 'CAR51586675 ', 'CAR51586703 ', 'CAR51586711 ', 'CAR51586717 ', 'CAR51586722 ', 'CAR51586736 ', 'CAR51586768 ', 'CAR51586793 ', 'CAR51586815 ', 'CAR51586839 ', 'CAR51586856 ', 'CAR51586871 ', 'CAR51586892 ', 'CAR51586896 ', 'CAR51586900 ', 'CAR51586915 ', 'CAR51586944 ', 'CAR51587045 ', 'CAR51587068 ', 'CAR51587086 ', 'CAR51587093 ', 'CAR51587094 ', 'CAR51587099 ', 'CAR51587155 ', 'CAR51587163 ', 'CAR51587171 ', 'CAR51587190 ', 'CAR51587205 ', 'CAR51587256 ', 'CAR51587257 ', 'CAR51587280 ', 'CAR51587295 ', 'CAR51587347 ', 'CAR51587380 ', 'CAR51587383 ', 'CAR51587405 ', 'CAR51587409 ', 'CAR51587446 ', 'CAR51587457 ', 'CAR51587479 ', 'CAR51587517 ', 'CAR51587538 ', 'CAR51587549 ', 'CAR51587563 ', 'CAR51587609 ', 'CAR51587621 ', 'CAR51587629 ', 'CAR51587654 ', 'CAR51587668 ', 'CAR51587676 ', 'CAR51587677 ', 'CAR51587686 ', 'CAR51587698 ', 'CAR51587705 ', 'CAR51587727 ', 'CAR51587737 ', 'CAR51587770 ', 'CAR51587789 ', 'CAR51587849 ', 'CAR51587889 ', 'CAR51587897 ', 'CAR51587959 ', 'CAR51587962 ', 'CAR51587984 ', 'CAR51588019 ', 'CAR51588049 ', 'CAR51588072 ', 'CAR51588084 ', 'CAR51588095 ', 'CAR51588100 ', 'CAR51588110 ', 'CAR51588133 ', 'CAR51588193 ', 'CAR51588197 ', 'CAR51588212 ', 'CAR51588233 ', 'CAR51588241 ', 'CAR51588269 ', 'CAR51588306 ', 'CAR51588337 ', 'CAR51588355 ', 'CAR51588369 ', 'CAR51588376 ', 'CAR51588377 ', 'CAR51588404 ', 'CAR51588448 ', 'CAR51588461 ', 'CAR51588462 ', 'CAR51588525 ', 'CAR51588529 ', 'CAR51588571 ', 'CAR51588575 ', 'CAR51588631 ', 'CAR51588634 ', 'CAR51588641 ', 'CAR51588644 ', 'CAR51588661 ', 'CAR51588662 ', 'CAR51588718 ', 'CAR51588733 ', 'CAR51588778 ', 'CAR51588799 ', 'CAR51588808 ', 'CAR51588818 ', 'CAR51588843 ', 'CAR51588876 ', 'CAR51588902 ', 'CAR51588908 ', 'CAR51588923 ', 'CAR51588942 ', 'CAR51588944 ', 'CAR51588950 ', 'CAR51588970 ', 'CAR51588980 ', 'CAR51588983 ', 'CAR51588997 ', 'CAR51589005 ', 'CAR51589020 ', 'CAR51589024 ', 'CAR51589066 ', 'CAR51589069 ', 'CAR51589099 ', 'CAR51589174 ', 'CAR51589188 ', 'CAR51589190 ', 'CAR51589193 ', 'CAR51589198 ', 'CAR51589205 ', 'CAR51589215 ', 'CAR51589229 ', 'CAR51589238 ', 'CAR51589266 ', 'CAR51589268 ', 'CAR51589297 ', 'CAR51589308 ', 'CAR51589322 ', 'CAR51589351 ', 'CAR51589353 ', 'CAR51589372 ', 'CAR51589381 ', 'CAR51589401 ', 'CAR51589406 ', 'CAR51589532 ', 'CAR51589543 ', 'CAR51589555 ', 'CAR51589557 ', 'CAR51589628 ', 'CAR51589651 ', 'CAR51589667 ', 'CAR51589682 ', 'CAR51589707 ', 'CAR51589740 ', 'CAR51589752 ', 'CAR51589767 ', 'CAR51589788 ', 'CAR51589847 ', 'CAR51589864 ', 'CAR51589884 ', 'CAR51589890 ', 'CAR51589902 ', 'CAR51589922 ', 'CAR51589959 ', 'CAR51589973 ', 'CAR51589981 ', 'CAR51590002 ', 'CAR51590026 ', 'CAR51590037 ', 'CAR51590078 ', 'CAR51590084 ', 'CAR51590088 ', 'CAR51590097 ', 'CAR51590110 ', 'CAR51590123 ', 'CAR51590176 ', 'CAR51590187 ', 'CAR51590189 ', 'CAR51590223 ', 'CAR51590226 ', 'CAR51590255 ', 'CAR51590297 ', 'CAR51590321 ', 'CAR51590327 ', 'CAR51590329 ', 'CAR51590337 ', 'CAR51590363 ', 'CAR51590381 ', 'CAR51590388 ', 'CAR51590398 ', 'CAR51590404 ', 'CAR51590408 ', 'CAR51590423 ', 'CAR51590430 ', 'CAR51590433 ', 'CAR51590438 ', 'CAR51590465 ', 'CAR51590493 ', 'CAR51590530 ', 'CAR51590558 ', 'CAR51590575 ', 'CAR51590587 ', 'CAR51590617 ', 'CAR51590623 ', 'CAR51590632 ', 'CAR51590635 ', 'CAR51590650 ', 'CAR51590656 ', 'CAR51590667 ', 'CAR51590682 ', 'CAR51590703 ', 'CAR51590720 ', 'CAR51590734 ', 'CAR51590749 ', 'CAR51590764 ', 'CAR51590773 ', 'CAR51590788 ', 'CAR51590801 ', 'CAR51590809 ', 'CAR51590844 ', 'CAR51590877 ', 'CAR51590879 ', 'CAR51590883 ', 'CAR51590908 ', 'CAR51590909 ', 'CAR51590923 ', 'CAR51590948 ', 'CAR51590953 ', 'CAR51590989 ', 'CAR51590994 ', 'CAR51591079 ', 'CAR51591111 ', 'CAR51591125 ', 'CAR51591127 ', 'CAR51591131 ', 'CAR51591151 ', 'CAR51591198 ', 'CAR51591211 ', 'CAR51591231 ', 'CAR51591255 ', 'CAR51591283 ', 'CAR51591311 ', 'CAR51591336 ', 'CAR51591338 ', 'CAR51591345 ', 'CAR51591413 ', 'CAR51591423 ', 'CAR51591451 ', 'CAR51591462 ', 'CAR51591468 ', 'CAR51591481 ', 'CAR51591496 ', 'CAR51591510 ', 'CAR51591520 ', 'CAR51591561 ', 'CAR51591631 ', 'CAR51591658 ', 'CAR51591714 ', 'CAR51591745 ', 'CAR51591777 ', 'CAR51591797 ', 'CAR51591805 ', 'CAR51591811 ', 'CAR51591821 ', 'CAR51591827 ', 'CAR51591867 ', 'CAR51591896 ', 'CAR51591908 ', 'CAR51591929 ', 'CAR51591932 ', 'CAR51592022 ', 'CAR51592025 ', 'CAR51592060 ', 'CAR51592071 ', 'CAR51592151 ', 'CAR51592155 ', 'CAR51592159 ', 'CAR51592191 ', 'CAR51592236 ', 'CAR51592241 ', 'CAR51592246 ', 'CAR51592247 ', 'CAR51592251 ', 'CAR51592265 ', 'CAR51592271 ', 'CAR51592306 ', 'CAR51592367 ', 'CAR51592370 ', 'CAR51592417 ', 'CAR51592431 ', 'CAR51592443 ', 'CAR51592453 ', 'CAR51592486 ', 'CAR51592505 ', 'CAR51592541 ', 'CAR51592543 ', 'CAR51592592 ', 'CAR51592634 ', 'CAR51592642 ', 'CAR51592648 ', 'CAR51592660 ', 'CAR51592693 ', 'CAR51592694 ', 'CAR51592700 ', 'CAR51592770 ', 'CAR51592787 ', 'CAR51592788 ', 'CAR51592803 ', 'CAR51592810 ', 'CAR51592825 ', 'CAR51592859 ', 'CAR51592860 ', 'CAR51592902 ', 'CAR51592922 ', 'CAR51592960 ', 'CAR51592978 ', 'CAR51592999 ', 'CAR51593026 ', 'CAR51593056 ', 'CAR51593089 ', 'CAR51593152 ', 'CAR51593166 ', 'CAR51593184 ', 'CAR51593229 ', 'CAR51593530 ', 'CAR51594139 ', 'CAR51594316 ', 'CAR51596145 ', 'CAR51617107 ', 'CAR51653432 ', 'CAR51684104 ', 'CAR51817222 ', 'CAR51930183 ', 'CAR52012590 ', 'CAR52034789 ', 'CAR52066825 ', 'CAR52070816 ', 'CAR52080458 ', 'CAR52080482 ', 'CAR52080509 ', 'CAR52080596 ', 'CAR52080865 ', 'CAR52080877 ', 'CAR52081092 ', 'CAR52081157 ', 'CAR52081356 ', 'CAR52081529 ', 'CAR52081668 ', 'CAR52081679 ', 'CAR52081831 ', 'CAR52082919 ', 'CAR52083048 ', 'CAR52083233 ', 'CAR52083350 ', 'CAR52083418 ', 'CAR52083446 ', 'CAR52083510 ', 'CAR52083653 ', 'CAR52084342 ', 'CAR52084426 ', 'CAR52084702 ', 'CAR52084766 ', 'CAR52084850 ', 'CAR52113741 ', 'CAR52114299 ', 'CAR52135255 ', 'CAR52218629 ', 'CAR52218789 ', 'CAR52218890 ', 'CAR52218946 ', 'CAR52219038 ', 'CAR52219055 ', 'CAR52219664 ', 'CAR52220421 ', 'CAR52221007 ', 'CAR52221335 ', 'CAR52317375 ', 'CAR52320593 ', 'CAR52321254 ', 'CAR52323748 ', 'CAR52336947 ', 'CAR52345199 ', 'JCAR52090029', 'JCAR52091806', 'JCAR52221201', 'RCAR11520984', 'RCAR11521044', 'RCAR11521249', 'RCAR11521362', 'RCAR11521624', 'RCAR11522303', 'RCAR11522304', 'RCAR11522339', 'RCAR11522346', 'RCAR11522359', 'RCAR11522373', 'RCAR11522375', 'RCAR11522377', 'RCAR11522379', 'RCAR11522394', 'RCAR11522427', 'RCAR11522428', 'RCAR11522444', 'RCAR11522471', 'RCAR11522481', 'RCAR11522483', 'RCAR11522491', 'RCAR11522501', 'RCAR11522502', 'RCAR11522510', 'RCAR11522528', 'RCAR11522531', 'RCAR11522546', 'RCAR11522548', 'RCAR11522562', 'RCAR11522570', 'RCAR11522571', 'RCAR11522581', 'RCAR11522583', 'RCAR11522598', 'RCAR11522610', 'RCAR11522611', 'RCAR11522617', 'RCAR11522623', 'RCAR11522627', 'RCAR11531531', 'RCAR11532342', 'RCAR11532374');

-----------------------iNVOICE BATCH HAS NOT PROCESSED----------------------------------
select * from outpt_orders where tc_order_id='RCAR10572866_1' and batch_ctrl_nbr='121192534'; -------1
select * from DM.OUTPT_ORDER_LINE_ITEM where tc_order_id='RCAR10572866_1' and invc_batch_nbr='121192534'; --------3
select * from outpt_lpn where tc_order_id='RCAR10572866_1' and invc_batch_nbr='121192534'; ---------2
select * from outpt_lpn_detail where minor_po_nbr='RCAR10572866_1' and invc_batch_nbr='121192534'; ---------4 
select tc_order_id,PROC_STAT_CODE from outpt_lpn where invc_batch_nbr in ('122605672'); 

select * from outpt_orders where batch_ctrl_nbr='122605672'; -------1
select * from DM.OUTPT_ORDER_LINE_ITEM where invc_batch_nbr='122605672'; --------3
select * from outpt_lpn where invc_batch_nbr='122605672'; ---------2
select * from outpt_lpn_detail where invc_batch_nbr='122605672'; ---------4  

select * from order_line_item where line_item_id = '949875295';
select do_status from order_line_item where line_item_id = '949875295';
select * from ORDER_LINE_ITEM where order_id in ('108925686') and do_dtl_status <'190';