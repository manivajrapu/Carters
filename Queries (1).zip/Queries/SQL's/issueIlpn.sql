alter session SET Current_schema=DM;

--lpn status must be 45 or 50----
Select * from lpn where tc_lpn_id in ('99041731');--99041731

Select lpn_facility_status,tc_lpn_id from lpn where tc_lpn_id in ('EXC_070318_000419293','00007160415960642205');

--for open alloc--
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('EXC_070318_000419293','00007160415960642205') and stat_code < '90';

00007160410828279357