select unique(manifest_nbr), tc_order_id from lpn where manifest_nbr in ('UMI000006690','UMI000006692');

select * from lpn where manifest_nbr in ('UMI000006690','UMI000006692');

select lpn_facility_status, manifest_nbr, tc_order_id from lpn where manifest_nbr='UMI000006692' and lpn_facility_status<'90';

select lpn_facility_status, manifest_nbr, tc_order_id from lpn where manifest_nbr='UMI000006690' --and lpn_facility_status<'90';

select unique(invc_batch_nbr), manifest_nbr, proc_stat_code from outpt_lpn where manifest_nbr = 'UMI000006690' --and proc_stat_code<'90';

select unique(invc_batch_nbr), manifest_nbr, proc_stat_code from outpt_lpn where manifest_nbr = 'UMI000006692' --and proc_stat_code<'90';

select do_status from orders where tc_order_id in ('CAR19217738_1','CAR19206067_1','CAR19212979_1','CAR19221159_1');--Manifest UMI000006690

select do_status from orders where tc_order_id in ('CAR19221505_1','CAR19215362_1','CAR19219915_1','CAR19228300_1');--Manifest UMI000006692

select proc_stat_code from outpt_orders where tc_order_id in ('CAR19217738_1','CAR19206067_1','CAR19212979_1','CAR19221159_1');--Manifest UMI000006690

select proc_stat_code from outpt_orders where tc_order_id in ('CAR19221505_1','CAR19215362_1','CAR19219915_1','CAR19228300_1');--Manifest UMI000006692

select tran_log.tran_log_id, sequence_number, msg_line_number, tran_log.created_dttm, msg_line_text
from tran_log, tran_log_message
where tran_log.tran_log_id = tran_log_message.tran_log_id
and msg_line_text like '1206177%'
and tran_log.created_dttm >= to_date('6/14/2016','mm/dd/yyyy') and tran_log.created_dttm < to_date('2/19/2017','mm/dd/yyyy')
and tran_log.msg_type = 'ShipConfirm';

select ext_purchase_order "PURCHASE_ORDER", bill_to_name "CUSTOMER", 
        addr_code "DIV", rte_to "ROUTE_TO", lane_name "LANE", tc_shipment_id "ORDERS_SHIPMENT_ID", count(*) "TOTAL_ORDERS"
from orders o where order_type not in ('EC','SD') and order_status = 10 and do_status < 190
and exists (select 1 from lpn l where l.order_id = o.order_id and l.lpn_Facility_status < 90 and tc_shipment_Id is null and inbound_outbound_Indicator = 'O')
group by  ext_purchase_order, bill_to_name, addr_code, rte_to, lane_name, tc_shipment_id
