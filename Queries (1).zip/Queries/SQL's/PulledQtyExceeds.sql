alter session set current_schema=wmprod33;

select stat_code,case_nbr
from  CASE_HDR
where case_nbr in ('00006644540474688361', '00006644540474687104', '00006644543322536784', '00006644540474687036');

select cntry_of_orgn
from  CArton_dtl
where carton_nbr in ('00000197183504435570');

select * from alloc_invn_dtl where cntr_nbr in ('00006644540474688361', '00006644540474687104', '00006644543322536784', '00006644540474687036') and stat_code < 90; 
select cntr_nbr,carton_nbr,qty_alloc,
qty_pulld,stat_code,batch_nbr,invn_need_type 
from ALLOC_INVN_DTL 
where carton_nbr in ('00000197184073785097') 
and stat_code < '90';

select actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in('00006644549817933960');

select * from task_dtl where TASK_GENRTN_REF_NBR in('201812210026') and stat_code<'90';
-------------------------------------------------------------------------------------------------------------------------------------------------
,'00006644549910051691','00006644549910051707',
'00006644549910051721','00006644549910051820','00006644549910051851','00006644549910051905','00006644549910051936');

select *
from task_hdr
where task_id in (select td.task_id
from task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
and aid.stat_code = '00'
and aid.cntr_nbr in ('00007160417269069639')
and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id)
and stat_code <'99';

Select stat_code, ship_wave_nbr from ship_wave_parm where pick_wave_nbr='PT3493418';



select case_nbr,stat_code from case_hdr where case_nbr in ('00006644549971221286');

select * from case_dtl where case_nbr in ('00006644549971221286');
select * from task_dtl where cntr_nbr in('00006644543315742642');
select * from locn_hdr; where cntr_nbr=('00006644549834157257');
select * from alloc_parm;
select * from alloc_invn_dtl where cntr_nbr='00007160412307680807' and stat_code<90;

select task_id, task_genrtn_ref_nbr, user_id, mod_date_time, sku_id  from task_dtl where cntr_nbr in ('00006644543315768062');

select  task_genrtn_ref_nbr, user_id, mod_date_time, sku_id, invn_need_type  from alloc_invn_dtl where cntr_nbr in ('00006644543315768062');
--task id,wave number

select locn_id, locn_class from locn_hdr where user_id='RFTEMP389';

select * from locn_hdr;

select carton_nbr, sku_id, mod_date_time from alloc_invn_dtl where cntr_nbr='00006644543315768062'; 

select carton_nbr, stat_code from carton_hdr where carton_nbr in ('00000197183985458730', '00000197183985463260', '00000197183985467091', '00000197183985483763', '00000197183985491249');


select stat_code,CARTON_NBR,pkt_ctrl_nbr
from  CARTON_HDR
where CARTON_NBR in ('000000197184074767122', '000000197184074767184', '000000197184074767320', '000000197184074767351', '000000197184074767542', '000000197184074773260', '000000197184074773284', '000000197184074774311', '000000197184074774519', '000000197184074775882', '000000197184074779170'); 

select * from task_hdr where carton_nbr in ('000000197184074767122', '000000197184074767184', '000000197184074767320', '000000197184074767351', '000000197184074767542', '000000197184074773260', '000000197184074773284', '000000197184074774311', '000000197184074774519', '000000197184074775882', '000000197184074779170'); 

select * from alloc_invn_dtl where carton_nbr in ('000000197184074767122', '000000197184074767184', '000000197184074767320', '000000197184074767351', '000000197184074767542', '000000197184074773260', '000000197184074773284', '000000197184074774311', '000000197184074774519', '000000197184074775882', '000000197184074779170'); 
select * from alloc_invn_dtl where CARTON_NBR in ('00000197184065075830') and stat_code< 90;

select stat_code from pkt_dtl where pkt_ctrl_nbr in ('3400000237');



select stat_code,CARTON_NBR,pkt_ctrl_nbr from carton_hdr where carton_nbr = '00000197183473224465';
select * from carton_dtl where carton_nbr = '00000197183473224465';
select * from pkt_hdr where pkt_ctrl_nbr in ('3365035517', '3365035565', '3365184963', '3365184960', '3365185014') and pkt_seq_nbr in (select pkt_seq_nbr from carton_dtl where carton_nbr = '00000197183473224465');
select * from CARTON_LOCK where carton_nbr = '00000197183473224465';

select load_nbr, shpmt_nbr, bol, master_bol, carton_nbr, stat_code, ship_via from carton_hdr where carton_nbr in ('00000197184045346943', '00000197184021568185', '00000197184034140149', '00000197184034140422', '00000197184037206286', '00000197184037277538', '00000197184037282051', '00000197184037287735', '00000197184037319115', '00000197184037319207', '00000197184047501425', '00000197184047510526', '00000197184047505324', '00000197184047511790', '00000197184047513114', '00000197184047861031', '00000197184047869358', '00000197184047873539', '00000197184047875595', '00000197184047884320', '00000197184047891328', '00000197184047892936', '00000197184047900624', '00000197184047895753', '00000197184047967313', '00000197184047980947', '00000197184048403452', '00000197184048436849', '00000197184048436887', '00000197184048442048', '00000197184048449764', '00000197184048571762', '00000197184048573582', '00000197184049613973', '00000197184049651784', '00000197184049739666', '00000197184049751965', '00000197184049761773', '00000197184049767546', '00000197184049870956', '00000197184051180524', '00000197184051593119', '00000197184052558292', '00000197184053371159', '00000197183499048854', '00000197183499051656');


select LABEL_PRT_REQD, MOD_DATE_TIME, USER_ID, CARTON_TYPE, CARTON_SIZE, MANIF_NBR, LABEL_TYPE, REPRT_CNT 
from CARTON_HDR
where carton_nbr in ('00001921700259870065');

select count(*) from alloc_invn_dtl
    where invn_need_type='60'
    and stat_code='0'
     and cntr_nbr in ('00006644540136769193', '00006644540136842032', '00006644540136868223', '00006644540211923311', '00006644540540012755', '00006644543320917301', '00006644543321071644', '00006644543321240972', '00006644549708025026', '00006644549736838230', '00006644549736847607', '00006644549759126314', '00007160410738303937', '00007160419283375567');
    
-----Wave queries------ 
select * from alloc_invn_dtl where TASK_GENRTN_REF_NBR in ('201708280014') and stat_code<'90';

select * from alloc_invn_dtl where TASK_GENRTN_REF_NBR in ('258449214');
select task_id, stat_code from task_hdr where task_id in ('114422337');
select task_id, stat_code from task_dtl where task_id in ('114422337') and stat_code<'90';
 select * from pkt_dtl where wave_nbr in ('201812210026') and stat_code<90;
 select task_id from WAVE_PARM where wave_nbr in ('201905180010');----------201708280014
 
 select wave_nbr,pkt_qty,pkt_ctrl_nbr,pkt_seq_nbr,sku_id from pkt_dtl where pkt_ctrl_nbr = '3400000112' 
    and pkt_seq_nbr = '216436' 
    and sku_id = '117273418';

select carton_nbr, stat_code, total_qty, User_id from carton_hdr where carton_nbr in ('00000197184073785097');--15--3364337399
select case_nbr, stat_code,  User_id from case_hdr where case_nbr in ('00006644549817933960');--95
select * from carton_dtl where carton_nbr in ('00000197184074767122', '00000197184074767184', '00000197184074767320', '00000197184074767351', '00000197184074767542', '00000197184074773260', '00000197184074773284', '00000197184074774311', '00000197184074774519', '00000197184074775882', '00000197184074779170');--119032538 --sku
select trkg_nbr, manif_nbr, parcl_shpmt_nbr from carton_hdr 
where carton_nbr in ('00000197183503728925');

select * from case_hdr 
where case_nbr in ('000000197184074767122', '000000197184074767184', '000000197184074767320', '000000197184074767351', '000000197184074767542', '000000197184074773260', '000000197184074773284', '000000197184074774311', '000000197184074774519', '000000197184074775882', '000000197184074779170'); 

select task_id, task_seq_nbr, cntr_nbr, carton_nbr, pull_locn_id, invn_need_type, qty_alloc, qty_pulld, alloc_invn_dtl_id from task_dtl where carton_nbr in ('00000197184074767122', '00000197184074767184', '00000197184074767320', '00000197184074767351', '00000197184074767542', '00000197184074773260', '00000197184074773284', '00000197184074774311', '00000197184074774519', '00000197184074775882', '00000197184074779170') and stat_code < 90;
select * from task_hdr where task_id in ('115154325') and stat_code < '90'; 

select task_id, task_seq_nbr, cntr_nbr, carton_nbr, pull_locn_id, invn_need_type, qty_alloc, qty_pulld, alloc_invn_dtl_id from task_dtl where task_genrtn_ref_nbr in ('201905180010') and carton_nbr in ('000000197184074767122', '000000197184074767184', '000000197184074767320', '000000197184074767351', '000000197184074767542', '000000197184074773260', '000000197184074773284', '000000197184074774311', '000000197184074774519', '000000197184074775882', '000000197184074779170'); 


select   invn_lock_code from resv_locn_hdr  where locn_id in (select locn_id from locn_hdr where aisle between 'R013' and 'R017' and posn between 'A64' and 'E104' and whse = '33');