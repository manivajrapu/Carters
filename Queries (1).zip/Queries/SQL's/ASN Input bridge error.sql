alter session set current_schema=wmprod33;

----------------------------
select * from inpt_asn_hdr;
select distinct ERROR_SEQ_NBR from inpt_case_hdr where ORIG_SHPMT_NBR in ('269053001', '269055002');
select * from msg_log where ref_value_1 in ('0', '244296030', '244296031'); 
select * from case_hdr where case_nbr in ('00006644540476950060', '0000664540512451773', '00006644540502139902');
 

select distinct shpmt_nbr from inpt_asn_hdr;
--271945001
--273123001
select distinct error_seq_nbr,proc_stat_code from inpt_case_hdr;
select distinct error_seq_nbr,proc_stat_code from inpt_asn_hdr;
select distinct error_seq_nbr,proc_stat_code from inpt_item_master;

select * from msg_log where ref_value_1 in ('243325764', '243325765', '243325766', '243325767'); 
 

--------------------------------------------

select SHPMT_NBR, error_seq_nbr,proc_stat_code from inpt_asn_hdr;

select * from msg_log where ref_value_1 in ('224591793', '224591794', '224591795', '224591796', '224591797', '224591798', '224591799', '224612023', '224612024', '224612025', '224612026', '224612027', '224640185', '224640186');

select * from asn_hdr where SHPMT_NBR='224287001';
--506:cas_shpd 12144:units_shpd           506:cases           12144:units_rcvd
select * from inpt_CASE_HDR where ORIG_SHPMT_NBR='233722004';--506
select * from CASE_DTL where CASE_NBR in (select CASE_NBR from CASE_HDR where ORIG_SHPMT_NBR='224287001');
select * from inpt_asn_hdr where SHPMT_NBR in('233722004');
select * from WMPROD33.CASE_HDR where CASE_NBR in('00007160417183938554');

select * from inpt_case_hdr where shp;
--inpt_case_dtl,inpt_case_hdr,inpt_asn_hdr

select * from EISPROD33.CL_ENDPOINT;--227415807
select * from EISPROD33.CL_ENDPOINT_QUEUE where endpoint_id = '16' and status = 6;
select * from EISPROD33.CL_ENDPOINT_QUEUE where endpoint_id = '16' and ENDPOINT_QUEUE_ID='';


select * from inpt_case_dtl where CASE_NBR in ('00006644540101864335');
select * from WMPROD33.ASN_HDR where SHPMT_NBR in('236695001');
select * from WMPROD33.INPT_ASN_HDR where SHPMT_NBR in('236695001');
select DISTINCT CASE_NBR from WMPROD33.INPT_CASE_HDR where ORIG_SHPMT_NBR in('236695001');--146
select * from case_dtl where CASE_NBR in ('00006644540101868081');


Select * from inpt_item_master;
Select * from inpt_xref;
Select * from inpt_bom_hdr;
Select * from inpt_bom_dtl;
