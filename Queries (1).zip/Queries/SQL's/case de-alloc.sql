select case_nbr,stat_code from case_hdr where case_nbr in ('00006644540081542162','00006644543313208980');

select actl_qty,orig_qty,total_alloc_qty from case_dtl where case_nbr in ('00006644540081542162','00006644543313208980');

select * from alloc_invn_dtl where cntr_nbr in ('00006644540081542162','00006644543313208980') and stat_code<'90';

select td.*
from  task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
   and aid.stat_code = '0'
  and aid.cntr_nbr in ('00006644540081542162','00006644543313208980')
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id
   and td.stat_code < '99'; 
 
select *
from task_hdr
where task_id in (select td.task_id
from task_dtl td,alloc_invn_dtl aid
where aid.invn_need_type = '60'
and aid.stat_code = '00'
and aid.cntr_nbr in ('00006644540081542162','00006644543313208980')
  and td.alloc_invn_dtl_id = aid.alloc_invn_dtl_id)
   and stat_code <'99';


-------------------------- Programming assert-----------------------------

select load_nbr, shpmt_nbr, bol, master_bol, carton_nbr, stat_code, ship_via 
from carton_hdr 
where carton_nbr in ('00000197183508174321');

update carton_hdr
set ship_via = 'FXGR',
user_id = '#',
mod_date_time = sysdate
where carton_nbr in ('#�);



   