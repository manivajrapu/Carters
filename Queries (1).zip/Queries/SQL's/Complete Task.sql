alter session SET Current_schema=DM;

select task_id,stat_code from task_hdr where task_id in ('36100637', '36178163', '36381886', '36381888', '36384063', '36384062', '36391589', '36391591', '36391588', '36399738');---it can be in 10, 13 or 40-- after completing = 90


 UPDATE TASK_DTL SET QTY_ALLOC = '0', QTY_PULLD = '0', STAT_CODE = '99',MOD_DATE_TIME = SYSDATE
                WHERE TASK_ID =  #### AND STAT_CODE < 90;
               UPDATE TASK_HDR SET STAT_CODE = '90'', MOD_DATE_TIME = SYSDATE WHERE TASK_ID = ###; 