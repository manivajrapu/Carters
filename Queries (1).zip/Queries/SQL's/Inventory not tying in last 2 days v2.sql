---- 605 Quantities by Day 
alter session set current_schema = DM;

with snap_qty (SKU, SNAP_DATE, OH_QTY, NA_QTY) as (
select SKU, SNAP_DATE, sum(AV_QTY)+sum(NA_QTY) OH_QTY, sum(NA_QTY) NA_QTY
from (
    select 
        p.STYLE || '_' || p.COLOR|| '_' || p.SIZE_DESC || case when p.STYLE_SFX is not null then '_' || p.STYLE_SFX when p.BATCH_NBR='DFLT' then '' else '_'|| p.BATCH_NBR end SKU, 
        to_char(trunc(create_date_time),'YYYY-MM-DD') snap_date, 
        case when tran_code='97' then invn_adjmt_qty else 0 end AV_QTY,
        case when tran_code='98' then invn_adjmt_qty else 0 end NA_QTY
    from dm.PIX_TRAN p
    where 
--        item_name='212530 MC NS'
--        and batch_nbr='EC002'      
        TRAN_TYPE='605'
--        and p.style || '_' || p.color || '_' || p.size_desc || case when p.style_sfx is not null then '_' || p.style_sfx when p.batch_nbr = 'DFLT' then '' else '_' || p.batch_nbr end in 
--        (
--            '210206_960_NS_EC002'
--        )
--        and create_date_time between to_date('2018-10-01','YYYY-MM-DD') and to_date('2018-11-30','YYYY-MM-DD')
        and create_date_time >= trunc(sysdate - 2)
    order by create_date_time
    )
group by SKU, SNAP_DATE
order by 2),

---- Shipments for a SKU

ship_qty (SHIP_DATE, SKU, SHIP_QTY) as (
select 
    to_char(ld.created_dttm - 4.5/24,'YYYY-MM-DD') ship_date, 
--    ld.invc_batch_nbr,
    ld.ITEM_STYLE || '_' || ld.ITEM_COLOR || '_' || ld.ITEM_SIZE_DESC || case when ld.ITEM_STYLE_SFX is not null then '_' || ld.ITEM_STYLE_SFX when ld.BATCH_NBR='DFLT' then '' else '_'|| ld.BATCH_NBR end SKU,
    sum(-ld.size_value) ship_qty
from dm.OUTPT_LPN_DETAIL ld
inner join dm.OUTPT_ORDER_LINE_ITEM oli
    on oli.line_item_id = ld.distribution_order_dtl_id and ld.invc_batch_nbr = oli.invc_batch_nbr
inner join dm.ITEM_CBO ic
    on ic.item_id = ld.item_id
where 
--    ic.item_name='212530 MC NS'
--    and ld.batch_nbr='EC002'
--    ld.created_dttm between to_date('2018-10-01','YYYY-MM-DD') and to_date('2018-11-30','YYYY-MM-DD')
    ld.created_dttm >= trunc(sysdate - 2)
--    and ld.item_style || '_' || ld.item_color || '_' || ld.item_size_desc || case when ld.item_style_sfx is not null then '_' || ld.item_style_sfx when ld.batch_nbr = 'DFLT' then '' else '_' || ld.batch_nbr end in
--    (
--        '210206_960_NS_EC002'
--    )
group by
    to_char(ld.created_dttm - 4.5/24,'YYYY-MM-DD'), 
--    ld.invc_batch_nbr,
    ld.ITEM_STYLE || '_' || ld.ITEM_COLOR || '_' || ld.ITEM_SIZE_DESC || case when ld.ITEM_STYLE_SFX is not null then '_' || ld.ITEM_STYLE_SFX when ld.BATCH_NBR='DFLT' then '' else '_'|| ld.BATCH_NBR end
order by 1
),

---- PIX adjustments for a SKU

pix_adj (PIX_DATE, SKU, PIX_OH_QTY, PIX_NA_QTY) as (
    select
        PIX_DATE,
        SKU,
        sum(OH_QTY) OH_QTY,
        sum(NA_QTY) NA_QTY
    from (
        select 
            to_char(trunc(pt.create_date_time - 4.5/24),'YYYY-MM-DD') pix_date,
            pt.tran_nbr,
            pt.pix_seq_nbr,
            pt.STYLE || '_' || pt.COLOR|| '_' || pt.SIZE_DESC || case when pt.STYLE_SFX is not null then '_' || pt.STYLE_SFX when pt.BATCH_NBR='DFLT' then '' else '_'|| pt.BATCH_NBR end SKU,
            pt.tran_type, 
            pt.tran_code, 
            pt.actn_code,
            ptc.pix_desc,
            case 
            when pt.TRAN_TYPE ='300' then
                case
                    when upper(ptc.pix_desc) like '%UNLOCK%' then 0
                    when upper(ptc.pix_desc) like '%LOCK%' then 0
                    when upper(ptc.pix_desc) like '%TRANSFER% TI%' then 0
                    when upper(ptc.pix_desc) like '%CREATE%TRANSITIONAL%' then 0
                    else 
                    case
                        when INVN_ADJMT_TYPE='S' then -invn_adjmt_qty
                        else invn_adjmt_qty
                    end
                end
            else
                case
                    when upper(ptc.pix_desc) like '%UNLOCK%' then 0
                    when upper(ptc.pix_desc) like '%LOCK%' then 0
                    when upper(ptc.pix_desc) like '%CREATE%TRANSITIONAL%' then 0
                    else 
                    case
                        when INVN_ADJMT_TYPE='S' then -invn_adjmt_qty
                        else invn_adjmt_qty
                    end
                end
            end
            OH_QTY,
            case 
            when pt.TRAN_TYPE ='300' then 0
            else
                case
                    when upper(ptc.pix_desc) like '%UNLOCK%' then
                        case
                            when INVN_ADJMT_TYPE='S' then -INVN_ADJMT_QTY
                            else INVN_ADJMT_QTY
                        end
                    when upper(ptc.pix_desc) like '%LOCK%' then
                        case
                            when INVN_ADJMT_TYPE='A' then INVN_ADJMT_QTY
                            else -INVN_ADJMT_QTY
                        end
                    when upper(ptc.pix_desc) like '%TRANSFER% TI%' then
                        case
                            when INVN_ADJMT_TYPE='A' then INVN_ADJMT_QTY
                            else -INVN_ADJMT_QTY
                        end
                    else 
                    case
                        when INVN_ADJMT_TYPE='S' then -invn_adjmt_qty
                        else invn_adjmt_qty
                    end
                end
            end
            NA_QTY
            , pt.item_id
            , pt.*
        from dm.PIX_TRAN pt
        inner join dm.PIX_TRAN_CODE ptc
            on pt.tran_type = ptc.tran_type 
            and pt.tran_code = ptc.tran_code 
            and coalesce(pt.actn_code,'*') = ptc.actn_code 
            and ptc.pix_create_stat_code='10'
        where 
            pt.TRAN_TYPE not in ('605','620','601')
            and pt.tran_type || pt.tran_code || pt.actn_code not in ('3000102')
    --        and pt.item_name='212530 MC NS'
    --        and pt.batch_nbr='EC002'
--            and pt.style || '_' || pt.color || '_' || pt.size_desc || case when pt.style_sfx is not null then '_' || pt.style_sfx when pt.batch_nbr = 'DFLT' then '' else '_' || pt.batch_nbr end in 
--            (
--                '210206_960_NS_EC002'
--            )
--            and pt.create_date_time between to_date('2018-10-01','YYYY-MM-DD') and to_date('2018-11-30','YYYY-MM-DD')
            and pt.create_date_time >= trunc(sysdate - 2)
        order by 1,2,3
    )
group by 
    PIX_DATE, 
    SKU
order by 
    PIX_DATE
)

select 
    a.SKU, 
    a.snap_date, 
    a.OH_QTY, 
    a.NA_QTY, 
    nvl(b.SHIP_QTY,0) ship_qty, 
    nvl(c.PIX_OH_QTY,0) pix_oh_qty, 
    nvl(c.PIX_NA_QTY,0) pix_na_qty, 
    a.OH_QTY + nvl(c.PIX_OH_QTY,0) + nvl(b.SHIP_QTY,0)  end_of_day_oh_qty,  
    D.OH_QTY next_day_605_OH, 
    a.NA_QTY + nvl(c.PIX_NA_QTY,0) end_of_day_na_qty,
    D.NA_QTY NEXT_DAY_605_NA
from SNAP_QTY A
left outer join ship_qty B
    on A.SKU = B.SKU
    and A.SNAP_DATE = B.SHIP_DATE
left outer join pix_adj C
    on c.SKU = A.SKU
    and c.PIX_DATE = a.snap_date
inner join SNAP_QTY D
    on d.sku = a.sku
    and to_date(d.snap_date,'YYYY-MM-DD') = to_date(a.snap_date,'YYYY-MM-DD') + 1
where 
    (D.OH_QTY <> a.OH_QTY + nvl(c.PIX_OH_QTY,0) + nvl(b.SHIP_QTY,0))
    or (D.NA_QTY <> a.NA_QTY + nvl(c.PIX_NA_QTY,0))
order by A.SNAP_DATE
;