alter session SET Current_schema=DM;

with a as (
select o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, min(oli.ref_field3) ORIG
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190 and oli.do_dtl_status < 190
group by o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id
),
b as (
select o.tc_order_id, oli.item_name, oli.item_id, sum(order_qty) ORD
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190
group by o.tc_order_id, oli.item_name, oli.item_id
)
select a.bill_to_name, a.tc_order_id, a.item_name, a.orig, b.ord
from a, b
where a.tc_order_id = b.tc_order_id and a.item_id = b.item_id and b.ord > a.orig
order by 1;



select o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.ref_field3, sum(orig_order_qty) ORIG_ORD, sum(order_qty) ORD_QTY, sum(allocated_qty) ALLOC_QTY, sum(units_pakd) UNITS_PAKD
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1246928901'
group by o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, oli.ref_field3
having sum(order_qty) > oli.ref_Field3;


select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty, allocated_qty, units_pakd, do_dtl_status
from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1210837572' and oli.item_name ='1N036010 B 6M';-----832658009 , 35, 68

select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty, allocated_qty, units_pakd, do_dtl_status
  from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1210404163' and oli.item_name ='1N051610 ASST 18M';

select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty, allocated_qty, units_pakd, do_dtl_status
  from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1210404163' and oli.item_name ='1N051610 ASST 18M';
  
select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty, allocated_qty, units_pakd, do_dtl_status
  from orders o, order_line_item oli where o.order_id = oli.order_id and o.tc_order_id = '1210404163' and oli.item_name ='1N051610 ASST 18M';
  
  
select line_item_id,item_id,qty_alloc, qty_pulld, stat_code, user_id from task_dtl where line_item_id in ('936191488');---46
select qty_alloc, qty_pulld, stat_code from task_dtl where line_item_id in ('936748534');--37
select qty_alloc,qty_pulld,stat_code from task_dtl where line_item_id in ('936748536');--0
select qty_alloc, qty_pulld, stat_code from task_dtl where line_item_id in ('794454523');


select alloc_invn_dtl_id,qty_alloc,qty_pulld,stat_code,invn_need_type from alloc_invn_dtl where line_item_id in ('1089033358');--46
select alloc_invn_dtl_id,qty_alloc,qty_pulld,stat_code,invn_need_type from alloc_invn_dtl where line_item_id in ('936748534');--37
select alloc_invn_dtl_id,qty_alloc,qty_pulld,stat_code,invn_need_type from alloc_invn_dtl where line_item_id in ('936748536');--0
select alloc_invn_dtl_id,qty_alloc,qty_pulld,stat_code,invn_need_type from alloc_invn_dtl where line_item_id in ('794454524');


select lpn_detail_id,DISTRIBUTION_ORDER_DTL_ID,SIZE_VALUE,LPN_DETAIL_STATUS,LPN_DETAIL_ID from DM.LPN_DETAIL 
where DISTRIBUTION_ORDER_DTL_ID in ('1089033358');--46
select lpn_detail_id,DISTRIBUTION_ORDER_DTL_ID,SIZE_VALUE,LPN_DETAIL_STATUS,LPN_DETAIL_ID from DM.LPN_DETAIL 
where DISTRIBUTION_ORDER_DTL_ID in ('936748534');--37
select lpn_detail_id,DISTRIBUTION_ORDER_DTL_ID,SIZE_VALUE,LPN_DETAIL_STATUS,LPN_DETAIL_ID from DM.LPN_DETAIL 
where DISTRIBUTION_ORDER_DTL_ID in ('936748536');--0
select lpn_detail_id,DISTRIBUTION_ORDER_DTL_ID,SIZE_VALUE,LPN_DETAIL_STATUS,LPN_DETAIL_ID from DM.LPN_DETAIL 
where DISTRIBUTION_ORDER_DTL_ID in ('794454524');

select DISTRIBUTION_ORDER_DTL_ID,SIZE_VALUE,LPN_DETAIL_STATUS,LPN_DETAIL_ID from DM.LPN_DETAIL 
where DISTRIBUTION_ORDER_DTL_ID in ('721399836');---678936328, 682854720, 682854721

select LINE_ITEM_ID,units_pakd from DM.ORDER_LINE_ITEM where LINE_ITEM_ID in ('725288868');----726910143,726910177


select alloc_invn_dtl_id,qty_alloc,qty_pulld,stat_code,invn_need_type from alloc_invn_dtl where line_item_id in ('727903343'); 

select lpn_detail_id,DISTRIBUTION_ORDER_DTL_ID,SIZE_VALUE,LPN_DETAIL_STATUS,LPN_DETAIL_ID from DM.LPN_DETAIL 
where DISTRIBUTION_ORDER_DTL_ID in ('721427709'); 

select o.order_id, '1', 'VS', 'Rehang - VAS', '0', null, '0', oli.line_item_id, 'VR' from dm.orders o, dm.order_line_item oli where ref_field_3 = 'RP' and 
do_status = '110' and o.order_id = oli.order_id and o.tc_order_id in ('1235499263','1235499264','1235499265')
and o.order_id not in(select order_id from dm.order_note)