alter session SET Current_schema=DM;


select im.item_id, im.style, im.size_desc, im.sku_brcd, im.sku_desc, im.dsp_sku, im.unit_ht, im.unit_len, im.unit_width, im.unit_wt, im.unit_vol, im.sku_id, wi.on_hand_qty 
from item_master im, wm_inventory wi
where im.item_id = wi.item_id
and wi.on_hand_qty != '0';
with a as (select s.tc_shipment_id, s.assigned_carrier_code, ss.description SHIPMENT_STATUS, min(ship_via) LPN_SHIP_VIA , 
        sum(case when ship_via is not null then 1 else 0 end) CARTONS_SHIP_VIA, sum(case when ship_via is null then 1 else 0 end) NULL_SHIP_VIA
from lpn l, shipment s, shipment_status ss where l.tc_shipment_id = s.tc_shipment_id 
            and s.shipment_status = ss.shipment_status and s.shipment_status = 60 and l.lpn_facility_status < 90 and assigned_mot_id = 3
group by s.tc_shipment_id, assigned_carrier_code, ss.description, assigned_mot_id)
select * from a where NULL_SHIP_VIA > 0;


select count(*) from lpn where tc_shipment_id = 'CS69867125' and ship_via is null;

Select *from LPN where tc_shipment_id = �CS55945600�;

select * from lpn where tc_shipment_id = 'CS71587116' and ship_via is null;

Select tc_shipment_id, shipment_id from LPN where tc_shipment_id = 'CS71587116' and ship_via is not null;

select ship_via from lpn where tc_shipment_id = 'CS55945600';

--162
--132

--Update lpn set ship_via = 'DCB' where tc_shipment_id = 'CS22777212' and ship_via is null and lpn_facility_status < 90 and inbound_outbound_indicator = 'O';
select * from ship_via where ship_via='';

select count(*) from lpn where tc_shipment_id = 'CS18313295' and ship_via is null;
select count(*) from lpn where tc_shipment_id = 'CS18313470' and ship_via is null;
select count(*) from lpn where tc_shipment_id = 'CS18315379' and ship_via is null;
select count(*) from lpn where tc_shipment_id = 'CS18317792' and ship_via is null;
select count(*) from lpn where tc_shipment_id = 'CS18299613' and ship_via is null;
select distinct(ship_via) from lpn where tc_shipment_id = 'CS18313470' and ship_via is not null;

select count(*) from lpn where tc_shipment_id = 'CS18315379' and ship_via is not null;
select distinct(ship_via) from lpn where tc_shipment_id = 'CS18315379' and ship_via is not null;

select distinct(ship_via) from lpn where tc_shipment_id = 'CS15632721' and ship_via is not null;

select ship_via from lpn where tc_shipment_id='CS15632721' and ship_via='HJBI';

select description from ship_via where ship_via ='CARD';

select * from shipment where tc_shipment_id in ('CS15268924','CS15429297','CS15437559');

select * from task_dtl where task_id = '49519468';

select * from ship_wave_parm where ship_wave_nbr='201608150104';

select * from alloc_invn_dtl where task_genrtn_ref_nbr='201608150104' and stat_code<'90';

select * from task_dtl where task_genrtn_ref_nbr='201608150104' and stat_code<'90';

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2706778' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '8138459' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2705188' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '70315235' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '8137954' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2705314' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2705160' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '70315272' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2550758' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2550593' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2706384' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '70065918' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2706657' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '70065918' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '70065918' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '70065918' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '2550758' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = 'A117413' and l.lpn_facility_status < 40;

select o.ext_purchase_order, o.tc_order_id, l.tc_lpn_id, ship_via, l.shipment_id, l.tc_shipment_Id
from orders o, lpn l where o.order_id = l.order_id and o.ext_purchase_order = '10591744' and l.lpn_facility_status < 40;


select distinct(tc_order_id) from orders where ext_purchase_order ='43158401'; 

select ship_via, shipment_id, tc_shipment_id from lpn where tc_order_id = '1214943259' and lpn_facility_status <'40' and ship_via is null and shipment_id is null and tc_shipment_id is null

select ship_via, shipment_id, tc_shipment_id from lpn where tc_order_id='1214951962';
select ext_purchase_order "PURCHASE_ORDER", bill_to_name "CUSTOMER", 
        addr_code "DIV", rte_to "ROUTE_TO", lane_name "LANE", tc_shipment_id "ORDERS_SHIPMENT_ID", count(*) "TOTAL_ORDERS"
from orders o where order_type not in ('EC','SD') and order_status = 10 and do_status < 190
and exists (select 1 from lpn l where l.order_id = o.order_id and l.lpn_Facility_status < 90 and tc_shipment_Id is null and inbound_outbound_Indicator = 'O')
group by  ext_purchase_order, bill_to_name, addr_code, rte_to, lane_name, tc_shipment_id;

select tc_lpn_id,tc_shipment_id,ship_via,tc_order_id,lpn_facility_status,manifest_nbr from lpn where tc_lpn_id ='00000197181513399999';
select * from ship_via where ship_via='FDEC';


select * from lpn_detail where lpn_id='59004036';
select * from picking_short_item where tc_lpn_id='00000156741219490203';
select do_status,order_type,order_id from orders where tc_order_id='1217544636';
select * from lpn_lock where tc_lpn_id='00000156741219490203';
select * from wm_inventory where item_id='2300053' and tc_lpn_id='00000156741219490203';
select allocated_qty,order_qty,orig_order_qty,units_pakd from order_line_item where order_id='38399089' and item_id='2300053';



/* + NO_PARALLEL */select im.item_id, im.style, im.size_desc, im.sku_brcd, im.sku_desc, im.dsp_sku, im.unit_ht, im.unit_len, im.unit_width, im.unit_wt, im.unit_vol, im.sku_id, wi.on_hand_qty 
from item_master im, wm_inventory wi
where im.item_id = wi.item_id
and wi.on_hand_qty != '0';

select im.item_id, im.style, im.size_desc, im.sku_brcd, im.sku_desc, im.dsp_sku, im.unit_ht, im.unit_len, im.unit_width, im.unit_wt, im.unit_vol, im.sku_id, wi.on_hand_qty 
from item_master im, wm_inventory wi
where im.item_id = wi.item_id
and wi.on_hand_qty != '0'


