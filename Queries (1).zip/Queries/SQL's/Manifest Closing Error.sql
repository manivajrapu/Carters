alter session SET Current_schema=DM;

select l.manifest_nbr "Manifest Number", l.tc_lpn_id "oLPN Number", l.lpn_facility_status "oLPN Status",
            l.shipment_id "oLPN Shipment ID", ml.shipment_id "Manifested Shipment ID"
from lpn l, manifested_lpn ml
where l.lpn_id = ml.lpn_id
    and l.lpn_facility_status =40
        and l.shipment_id <> ml.shipment_id;
        
select * from lpn where tc_lpn_id = '00000197180109688738';
select * from manifested_lpn where tc_lpn_id = '00000197180109688738';
select * from shipment where tc_shipment_id = 'CS72819445';
select * from ship_via where ship_via = 'FDEC';
----------If Manifest number is null------------

select manifest_id from manifested_lpn where tc_lpn_id = '00000197180109688738';

select * from manifest_hdr where manifest_id = '157006';

---------Tracking number enetered is not consistent with form being printed---------------

select tc_lpn_id, l.tracking_nbr, fl.trkg_nbr, fedex_lpn_id from lpn l, fedex_lpn fl where l.lpn_id = fl.lpn_id and tc_lpn_id = '00000197180109688196';

485145372731750

select * from fedex_lpn where fedex_lpn_id in ('10774184', '10774185', '10774132', '10774131', '10774206') and lpn_id = '173894330';
