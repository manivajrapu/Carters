alter session SET Current_schema=DM;

select o.tc_order_id, ds.description STATUS
from dm.orders o, dm.do_status ds where o.do_status = ds.order_status and do_status = 200  and tc_order_id in 
('BCAR41859307_1', 'CAR41833509_1', 'CAR41869103_1', 'CAR41864954_1', 'CAR41866942_1', 'CAR41869041_1')
order by 1; 

Select * from sys_code where code_type in('CCF');