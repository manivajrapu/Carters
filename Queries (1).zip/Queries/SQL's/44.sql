select error_seq_nbr, proc_stat_code from inpt_item_master where error_seq_nbr>'0';
select * from inpt_item_master where error_seq_nbr>'0';

select * from item_master where style='CF161244' and style_sfx='AST' and size_desc='2';
select * from item_master where style='CS171141' and style_sfx='AST' and size_desc='5';
select * from item_master where style='GB16478' and style_sfx='AST' and size_desc='3-12';
select * from item_master where style='CS171432' and style_sfx='AST' and size_desc='3.5';
select * from item_master where style='CS171813' and style_sfx='AST' and size_desc='4.5';
select * from item_master where style='CS171192' and style_sfx='AST' and size_desc='2';
select * from item_master where style='CS171181' and style_sfx='AST' and size_desc='12';
-- 
select * from msg_log where ref_value_1 ='10511923';