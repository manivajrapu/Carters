alter session SET Current_schema=DM;

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source from lpn where tc_lpn_id in ('970063992394', '970064042538', '970064042534', '970900618787');

--IF ANY OPEN ALLOCATIONS THEN RUN CCF-----------------------
select * from alloc_invn_dtl where cntr_nbr in ('970063992394', '970064042538', '970064042534', '970900618787') and stat_code < '90';
  
select * from TASK_DTL where cntr_nbr in ('970063992394', '970064042538', '970064042534', '970900618787') and stat_code < '90';


select * from DM.MANIFEST_HDR where TC_MANIFEST_ID='USPS0004573';

SELECT TC_SHIPMENT_ID FROM LPN WHERE MANIFEST_NBR='USPS0004573';

SELECT * FROM SHIPMENT; WHERE MANIFEST_ID='USPS0004573';