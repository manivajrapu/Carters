select * from GV$SESSION where status='ACTIVE' and module='SQL Developer'; 

select sid,SERIAL#,username,status,SCHEMA#,SCHEMANAME,process,machine,PROCESS,program,type,sql_hash_value,sql_id,PREV_SQL_ID,module,BLOCKING_SESSION,BLOCKING_SESSION_STATUS
from V$SESSION where status = 'ACTIVE' and program='SQL Developer' and username='wms12q'; 
