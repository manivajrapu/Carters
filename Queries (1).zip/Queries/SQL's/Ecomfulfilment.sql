alter session SET Current_schema=DM;

select tc_order_id,do_status, order_type,order_id from orders where tc_order_id in ('CAR45270808_1'); --will be 140--76138293, 76138753

select * from orders where tc_order_id in ('CAR45270808_1'); 

select * from lpn where tc_lpn_id in ('00000197181812607023');---CAR44528302_1

SELECT TC_LPN_ID,TC_ORDER_ID,LPN_FACILITY_STATUS,TC_LPN_ID, lpn_id FROM LPN WHERE TC_LPN_ID IN('00000197181812607023');
SELECT * FROM LPN WHERE TC_ORDER_ID IN('CAR44449271_1');--CS49105744

select * from shipment where tc_shipment_id in ('CS49105744');--60

select tc_order_id,tc_lpn_id, lpn_facility_status from lpn where tc_lpn_id in ('00000197181812607023');---00000197181802950757
select order_id,LINE_ITEM_ID,allocated_qty,order_qty,orig_order_qty,units_pakd,do_dtl_status from order_line_item where order_id in ('79423106') and item_id='2141782';
select * from wm_inventory where tc_lpn_id in ('00000197181802950757') and item_id='2657190';--312284071,315356097
select * from order_line_item where order_id ='79423106' and do_dtl_status <190;
select * from lpn_detail where LPN_DETAIL_ID in ('312284071','315356097');

select * from wm_inventory where tc_lpn_id in ('00000197181802950757');--970100534668

select * from DM.ALLOC_INVN_DTL where Carton_NBR in ('00000197181802950757') and stat_code < '90';
select * from DM.TASK_DTL where Carton_NBR in ('00000197181802950757') and stat_code < '90'; 

select cntr_nbr, INVN_NEED_TYPE,CARTON_NBR, ITEM_ID, TC_ORDER_ID from DM.ALLOC_INVN_DTL where Carton_NBR in ('00000197181802950757') and stat_code < '90';


----vishwa---order error---------
select distinct lane_name from orders;
select trunc(od.created_dttm) BRIDGE_DATE,
DECODE(LANE_NAME,'2ND DAY','Expedited','OVERNIGHT','Expedited', 'Standard','SAVER') SERV_LVL,
do_status, od.tc_order_id,  sum(oli.order_qty)
from orders od, order_line_item oli, lpn l
where od.order_id = oli.order_id
and od.tc_order_id=l.tc_order_id
and od.is_original_order = 1
and trunc(od.created_dttm) = '21-MAY-19'
and od.do_status = 140
--and od.tc_order_id in ('CAR35748366_1')
and od.order_type = 'EC' --and od.created_dttm >= trunc(sysdate) - 1
group by od.tc_order_id,od.created_dttm,LANE_NAME,do_status,oli.order_qty order by od.created_dttm asc; 

-----CAR42795056_1,CAR42796249_1 

select tc_order_id,do_status,order_type,order_id from orders where tc_order_id in ('80910466');--727869564,727869568
select order_id, line_item_id, do_dtl_status from order_line_item where order_id ='80910466' and do_dtl_status <190;