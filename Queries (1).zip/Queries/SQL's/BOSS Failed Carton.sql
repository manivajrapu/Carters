alter session set current_schema = DM;

select tc_lpn_id, lpn_facility_status,lpn_id, tc_order_id,last_updated_source,manifest_nbr from dm.lpn where tc_lpn_id in ('00000156741227135691','00000197181796929999','00000197181796930537');
select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source from lpn where tc_lpn_id in ('00000156741227135691','00000197181796929999','00000197181796930537');
--to get the manifest number---------------------------------
select tc_lpn_id,tc_order_id, manifest_nbr,lpn_facility_status from lpn where tc_lpn_id in ('00000197181884270620');
UPS000015709

select manifest_nbr from lpn where tc_lpn_id ='00000197181802096257';---FXGD000020757
UPS000015313
--alert query----------------------------------------
select cle.name, to_char(cleq.msg_id) MSG_ID, l.tc_lpn_id, o.tc_order_id, when_queued, cleq.status, REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 14) USER_ID
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l, orders o
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and l.order_id = o.order_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 6)  = l.tc_lpn_id 
and o.order_type = 'EC'
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_PickConfirm') 
and error_count > 1;


select cle.name, to_char(cleq.msg_id) MSG_ID, l.tc_lpn_id, o.tc_order_id, when_queued, cleq.status, REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 14) USER_ID
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l, orders o
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and l.order_id = o.order_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 6)  = l.tc_lpn_id 
and o.order_type = 'EC'
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_PickConfirm') 
and error_count > 1;



select cle.name, to_char(cleq.msg_id) MSG_ID, l.tc_lpn_id, o.tc_order_id, when_queued, cleq.status, REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 14) USER_ID
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l, orders o
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and l.order_id = o.order_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 6)  = l.tc_lpn_id 
and o.order_type = 'EC'
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_PickConfirm') 
and error_count > 1;

select cle.name, to_char(cleq.msg_id) MSG_ID, l.tc_lpn_id, o.tc_order_id, when_queued, cleq.status, REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 14) USER_ID
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l, orders o
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and l.order_id = o.order_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 6)  = l.tc_lpn_id 
and o.order_type = 'EC'
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_PickConfirm') 
and error_count > 1;

select cle.name, cle.description, cleq.msg_id, l.tc_lpn_id, when_queued, when_status_changed, error_count, cleq.status
from cl_endpoint cle, cl_endpoint_queue cleq, cl_message cm,  lpn l
where cle.endpoint_id = cleq.endpoint_id and cleq.msg_id = cm.msg_id and REGEXP_SUBSTR(TO_CHAR(DATA), '[^/^]+', 1, 4)  = l.tc_lpn_id
and cleq.status = 6 
and cleq.when_status_changed > sysdate - 1/24
and cle.name in ('WCS_PTS_CartonClose') 
and error_count > 1
and exists (select 1 from lpn l2, orders o where l2.order_id = o.order_id and o.order_type = 'EC' and o.do_status < 190 and l2.tc_reference_lpn_id = l.tc_lpn_id);

