alter session SET Current_schema=DM;

with a as (
select o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id, min(oli.ref_field3) ORIG
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190 and oli.do_dtl_status < 190
group by o.bill_to_name, o.tc_order_id, oli.item_name, oli.item_id
),
b as (
select o.tc_order_id, oli.item_name, oli.item_id, sum(order_qty) ORD
from orders o, order_line_item oli where o.order_id = oli.order_id and o.order_type = 'PR' and o.do_status < 190
group by o.tc_order_id, oli.item_name, oli.item_id
)
select a.bill_to_name, a.tc_order_id, a.item_name, a.orig, b.ord
from a, b
where a.tc_order_id = b.tc_order_id and a.item_id = b.item_id and b.ord > a.orig
order by 1;


select o.bill_to_name, o.tc_order_id, oli.line_item_id, oli.item_name, oli.item_id, oli.ref_field3, orig_order_qty, order_qty,
allocated_qty, units_pakd, do_dtl_status, oli.batch_nbr from orders o, order_line_item oli
where o.order_id = oli.order_id and o.tc_order_id='1218037997' and oli.item_name='119G153 R 3M';



















