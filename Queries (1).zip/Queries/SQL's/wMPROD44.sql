select * from inpt_pkt_hdr where pkt_ctrl_nbr='7000023379';

select * from pkt_hdr where pkt_ctrl_nbr='7000023379';

select pkt_seq_nbr from inpt_pkt_dtl where pkt_ctrl_nbr='7000023379';

Select * from msg_log where ref_value_1=�9997927�;


select * from msg_log where ref_value_1 = '9997927';


select style,style_sfx,size_desc,sec_dim from inpt_pkt_dtl where error_seq_nbr > 0;





------------------------------------
--DC74 COMPARE
Select x.*
 from (select
    coalesce(WM.SKU, OM.SKU) SKU,
    nvl(OM.OM_OH_QTY,0) OM_OH, 
    nvl(OM.OM_DEL_INV_QTY,0) OM_DEL_INV, 
    nvl(WM.OH,0) WM_OH,
    nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0)) OH_VAR,
    nvl(OM.OM_HELD_QTY,0) OM_NA, 
    nvl(WM.NA,0) WM_NA,
    nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0) NA_VAR
from 
(
    select coalesce(oh.sku, na.sku) SKU, nvl(oh.oh_qty,0) + nvl(na.na_qty,0) as OH, nvl(na.na_qty,0) NA, coalesce(oh.dt, na.dt) dt
    from (
        select p.prodcode ||'_'|| p.planecode|| '_' || p.sizecode||decode(p.dimcode,p.planecode,null,'_'||p.dimcode) SKU, pt.tranqty oh_qty, trunc(pt.trandate) dt, pt.*
        from o2_pix_tran pt
        join prodskus p on pt.produpc=p.produpc and p.compcode='WCC'
        where pt.TRANsTYPE='605'
        and pt.transcode='97'
        and pt.whsecode='74'
        and trunc(pt.trandate) = to_date('2019-07-29','YYYY-MM-DD')) OH
    full outer join (
        select p.prodcode ||'_'|| p.planecode|| '_' || p.sizecode||decode(p.dimcode,p.planecode,null,'_'||p.dimcode)  SKU, pt.tranqty na_qty, trunc(pt.trandate) dt
        from o2_pix_tran pt
        join prodskus p on pt.produpc=p.produpc and p.compcode='WCC'
        where pt.TRANsTYPE='605'
        and pt.transcode='98'
        and pt.whsecode='74'
        and trunc(pt.trandate) = to_date('2019-07-29','YYYY-MM-DD')) NA
    on NA.SKU = OH.SKU
) WM
full outer join (
    select 
         coalesce(av.style ||'_'|| av.color ||'_'|| av.size_desc|| case when av.sec_dim = av.color then '' else '_'||av.sec_dim end , hi.style ||'_'|| hi.color || '_'|| hi.size_desc||case when hi.sec_dim = hi.color then '' else '_'||hi.sec_dim end ) as SKU, 
        coalesce(trunc(av.create_date_time), trunc(hi.create_date_time)) snap_date, 
        nvl(av.invn_adjmt_qty,0) OM_OH_QTY, nvl(di.invn_adjmt_qty,0) OM_DEL_INV_QTY, nvl(hi.invn_adjmt_qty,0) OM_HELD_QTY
    from 
        (select * from O2_INV_PIX_TRAN_DAILY where company_code='WCC' and trunc(create_date_time) = to_date('2019-07-28','YYYY-MM-DD') and invn_adjmt_qty>0 and whse='74' and tran_code='97') av
    left outer join
        (select * from O2_INV_PIX_TRAN_DAILY where company_code='WCC' and trunc(create_date_time)= to_date('2019-07-28','YYYY-MM-DD') and invn_adjmt_qty>0 and whse='74' and tran_code='96') di
    on di.style = av.style and di.color = av.color and av.size_desc = di.size_desc and di.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(di.create_date_time)
    full outer join
        (select * from O2_INV_PIX_TRAN_DAILY where company_code='WCC' and trunc(create_date_time) = to_date('2019-07-28','YYYY-MM-DD') and invn_adjmt_qty>0 and whse='74' and tran_code='98') hi
    on hi.style = av.style and hi.color = av.color and av.size_desc = hi.size_desc and hi.sec_dim = av.sec_dim and trunc(av.create_date_time) = trunc(hi.create_date_time)
) OM
    on OM.SKU=WM.SKU
where 
    (nvl(WM.OH,0) - (nvl(OM.OM_OH_QTY,0) - nvl(OM.OM_DEL_INV_QTY,0))) <> 0
    or (nvl(WM.NA,0) - nvl(OM.OM_HELD_QTY,0)) <> 0) x
order by x.sku
;

