alter session set current_schema = DM;

select wm.location_dtl_id, wm.item_id, wm.batch_nbr, count(*), min(lh.dsp_locn)
from dmmsf.locn_hdr lh, dm.wm_inventory wm, dm.item_cbo im where lh.locn_id = wm.location_id and wm.item_id = im.item_id
and lh.locn_class = 'C' 
and lh.dsp_locn like 'POSR%'
group by wm.location_dtl_id, wm.item_id, wm.batch_nbr having count(*) > 1;


select WM_INVENTORY_ID,to_be_filled_qty,lpn_id, location_id, on_hand_qty, wm_allocated_qty,LAST_UPDATED_SOURCE,ITEM_ID,BATCH_NBR 
from wm_inventory where location_id in (select locn_id from locn_hdr where dsp_locn in ('POSR20104'))
group by WM_INVENTORY_ID,to_be_filled_qty, on_hand_qty, wm_allocated_qty,LAST_UPDATED_SOURCE,ITEM_ID,BATCH_NBR, lpn_id, location_id;---POSR01226,POSR03170,POSR20614

select * from locn_hdr where locn_id in ('0039342');

select to_be_filled_qty, on_hand_qty, wm_allocated_qty,WM_INVENTORY_ID ,ITEM_ID,LAST_UPDATED_SOURCE
from wm_inventory where location_id in('620569450') and ITEM_ID in ('2763193');--2717406,2763193


SELECT * FROM WM_INVENTORY WMI
WHERE LOCATION_DTL_ID IN (
SELECT LOCATION_DTL_ID
FROM WM_INVENTORY
WHERE LOCN_CLASS IN ('A','C')
GROUP BY LOCATION_DTL_ID
HAVING COUNT(1) > 1)
AND ON_HAND_QTY = 0;
