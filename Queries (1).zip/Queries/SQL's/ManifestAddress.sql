alter session SET Current_schema=DM;

---00000197181358496631

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id, MANIFEST_NBR, tc_shipment_id, 
total_lpn_qty, LAST_UPDATED_SOURCE from lpn where tc_lpn_id in ('00000197181823322007');
select * from picking_short_item where tc_lpn_id in ('00000197181357229520', '00000197181357240105', '00000197181357252504', '00000197181357248156', '00000197181357255161', '00000197181357345824', '00000197181357240099', '00000197181357345886', '00000197181357255130', '00000197181357345770') and stat_code < '90';
select * from lpn_lock where tc_lpn_id in ('00000197181357229520', '00000197181357240105', '00000197181357252504', '00000197181357248156', '00000197181357255161', '00000197181357345824', '00000197181357240099', '00000197181357345886', '00000197181357255130', '00000197181357345770');
select * from DM.ALLOC_INVN_DTL where Carton_NBR in ('00000197181807854876', '00000197181807845331', '00000197181807875512', '00000197181807848356') and stat_code < '90';
select * from DM.TASK_DTL where Carton_NBR in ('00000197181807854876', '00000197181807845331', '00000197181807875512', '00000197181807848356') and stat_code < '90'; ----93565942, 93178936


select * from orders where tc_order_id in ('1237541182');---CAR45262492_1
select tc_order_id,do_status, order_status from orders where tc_order_id in ('1238451914');
select do_dtl_status from DM.ORDER_LINE_ITEM where order_id in ('80482348');

select Manifest_ from lpn where tc_lpn_id in ('00000197181801329592');
select DO_STATUS,ORDER_TYPE,TC_ORDER_ID,ORDER_ID,LAST_UPDATED_SOURCE,LINE_HAUL_SHIP_VIA from orders where D_STATE_PROV in ('VI'); 

select do_status,order_id,order_type,tc_order_id,SHIPMENT_ID,TC_SHIPMENT_ID,D_ADDRESS_1,D_ADDRESS_2,D_ADDRESS_3,
D_CITY,D_STATE_PROV,D_POSTAL_CODE,D_COUNTRY_CODE,BILL_TO_EMAIL,D_NAME, EXT_PURCHASE_ORDER  from orders where tc_order_id in ('1238451914');

select * from POSTAL_CODE where postal_code in ('30326');---11532,07005,10704

select * from shipment where tc_SHIPMENT_ID in('CS50954952');---CS49683516,48727643
select assigned_carrier_code from shipment where tc_SHIPMENT_ID in('CS50954952');
select * from lpn where tc_order_id in ('1235174532');

select * from ship_via where ship_via in ('FEGR');

select * from ship_via where Description like '%FedEx Ground%';
select tc_order_id, do_status, order_type from orders where tc_order_id in ('CAR45263199_1', 'CAR45269397_1', 'CAR45247859_1', 'CAR45265849_1', 'CAR45248267_1', 'CAR45254985_1', 'CAR45268302_1', 'CAR45269127_1', 'CAR45205804_1', 'CAR45265516_1', 'CAR45270967_1') and order_type in ('EC');

select l.manifest_nbr "Manifest Number", l.tc_lpn_id "oLPN Number", l.lpn_facility_status "oLPN Status",
            l.shipment_id "oLPN Shipment ID", ml.shipment_id "Manifested Shipment ID"
from lpn l, manifested_lpn ml
where l.lpn_id = ml.lpn_id
    and l.lpn_facility_status =40
        and l.shipment_id <> ml.shipment_id;
        
-----Michael K--orders--
SELECT unique(ORDERS.TC_ORDER_ID) FROM ORDERS WHERE DO_STATUS < 190 AND HAS_SPLIT = 0 AND DO_TYPE = 20
AND EXISTS (SELECT 1 FROM LPN WHERE LPN.ORDER_ID = ORDERS.ORDER_ID AND LPN_FACILITY_STATUS = 90)
AND EXISTS (SELECT 1 FROM LPN WHERE LPN.ORDER_ID = ORDERS.ORDER_ID AND LPN_FACILITY_STATUS < 90 and tc_shipment_id is null);
