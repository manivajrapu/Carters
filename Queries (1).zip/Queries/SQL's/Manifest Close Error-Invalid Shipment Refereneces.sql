alter session SET Current_schema=DM;

select manif_nbr,stat_code
from manif_parcl_hdr
where manif_nbr in ('0053225')
and stat_code < '90';

select l.manifest_nbr "Manifest Number", l.tc_lpn_id "oLPN Number", l.lpn_facility_status "oLPN Status",
            l.shipment_id "oLPN Shipment ID", ml.shipment_id "Manifested Shipment ID"
from lpn l, manifested_lpn ml
where l.lpn_id = ml.lpn_id
    and l.lpn_facility_status =40
        and l.shipment_id <> ml.shipment_id;
        
Select * from DM.PROD_TRKG_TRAN;

select tc_lpn_id, MANIFEST_NBR, tc_order_id, lpn_facility_status, SHIPMENT_ID from lpn where tc_lpn_id in ('00000156741228990602');--56662204

Select * from DM.MANIFESTED_LPN where tc_lpn_id in ('00000156741228990602');--124617--56643445
select * from DM.MANIFEST_HDR where manifest_id in('124617');--FXGD000031295
select lpn_facility_status, tc_lpn_id, tc_shipment_id, tc_order_id, ship_via, shipment_id, manifest_nbr from lpn where tc_lpn_id='00000197181546662329';
--14408198 shipment CS15372075 tc_shipment_id- Ship via is UPSC

select * from manifested_lpn where tc_lpn_id='00000197181801329592';--14408196-shipment before issue 
--After demanifest and manifest shipment id should get updated with LPN table shipment id.

select * from shipment where tc_shipment_id='CS15372075';

select do_status from orders where tc_order_id='RCAR10005108_1';

select * from ship_via where ship_via='UPSC';



--------------------manifest errors------------------------------------
select lpn_facility_status, tc_lpn_id, tc_shipment_id, tc_order_id, ship_via, shipment_id, manifest_nbr from lpn where tc_order_id='CAR26072199_1';
00000197181546043326

select do_status from orders where tc_order_id='RCAR10005108_1';
select * from lpn where tc_order_id='RCAR10005108_1';

select l.manifest_nbr "Manifest Number", l.tc_lpn_id "oLPN Number", l.lpn_facility_status "oLPN Status",
            l.shipment_id "oLPN Shipment ID", ml.shipment_id "Manifested Shipment ID"
from lpn l, manifested_lpn ml
where l.lpn_id = ml.lpn_id
    and l.lpn_facility_status =40
        and l.shipment_id <> ml.shipment_id