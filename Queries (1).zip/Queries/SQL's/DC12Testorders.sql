
select * from orders where tc_order_id in ('CAR35315092_1');
select do_status from orders where tc_order_id in ('CAR35315092_1');
select tc_order_id, order_type from orders where tc_order_id in ('CAR35315092_1');

select tc_order_id, do_status from orders where DO_STATUS in ('110') and order_type in ('EC');


select * from lpn where tc_order_id in ('CAR35314905_1');--00000197181681883481

select * from lpn where tc_lpn_id in ('00000197181681883733');

select * from ALLOC_INVN_DTL where carton_nbr in ('00000197181681883733') and stat_code < 90;--2545913

select * from Task_dtl where carton_nbr in ('00000197181681883733') and stat_code < 90;

select aid.CARTON_NBR,aid.CNTR_NBR,aid.INVN_NEED_TYPE,ic.ITEM_NAME,ic.ITEM_BAR_CODE,aid.QTY_ALLOC,aid.QTY_PULLD, aid.stat_code from ALLOC_INVN_DTL aid, item_cbo ic where aid.CARTON_NBR in ('00000197181681883733') and aid.stat_code < 90 and aid.item_id=ic.item_id;

select * from TASK_GRP_ELGBLTY where INVN_NEED_TYPE in ('51');

--Available Inventory for Wavable Orders. Change order type Ecom (EC), Wholesale (PR), Retail (SD)
select o.order_id,o.tc_order_id, o.do_status, oli.do_dtl_status, o.created_dttm, oli.item_id, oli.item_name, oli.sku_gtin, oli.order_qty, oli.unit_wt, oli.unit_vol, o.lane_name, oli.pick_locn_assign_type,
(select sum(wm.on_hand_qty-wm_allocated_qty+to_be_filled_qty) from wm_inventory wm where wm.item_id = oli.item_id and wm.batch_nbr = oli.batch_nbr and 
       wm.allocatable = 'Y' and wm.locn_class in ('A')) "AvailInv", oli.item_id, oli.order_id, oli.batch_nbr
from orders o, order_line_item oli
where o.order_id = oli.order_id 
--and o.do_status = '110'
--and oli.do_dtl_status = '110'
and order_type = 'EC'
and o.tc_order_id = any ('CAR35315092_1')
order by 1;


--Locations for waving (Retail & Wholesale) Remote packing
select * 
from locn_hdr 
where locn_class = 'C' 
and pick_detrm_zone = 'OSR' 
and not exists (select 1 from pick_locn_dtl pld where pld.locn_id = locn_hdr.locn_id);

--Locations for waving (ECOM) Remote Packing
select * 
from locn_hdr 
where locn_class = 'C' 
and sku_dedctn_type = 'T' 
and not exists (select 1 from pick_locn_dtl pld where pld.locn_id = locn_hdr.locn_id);

---PE12504D08,PE12505A01,PE12505A05,PE12505A07
