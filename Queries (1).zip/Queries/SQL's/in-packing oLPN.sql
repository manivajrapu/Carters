alter session SET Current_schema=DM;

here status will be in 15-inpacking and we have to change to 20-packed (should be =90[completed] & should not be <90-the inform user )

then check *-open task *-open allocation *-picking short item
select * from lpn;
select TRACKING_NBR,TC_ORDER_ID  from lpn where TC_ORDER_ID in ('BCAR51532749_2', 'BCAR51579419_2', 'BCAR51586168_2', 'BCAR51586176_2', 'BCAR51586218_2', 'BCAR51586453_2', 'BCAR51586504_2', 'BCAR51586530_2', 'BCAR51586535_2', 'BCAR51586640_2', 'BCAR51586759_2', 'BCAR51586909_2', 'BCAR51586964_2', 'BCAR51586978_2', 'BCAR51587024_2', 'BCAR51587041_2', 'BCAR51587224_2', 'BCAR51587230_2', 'BCAR51587328_2', 'BCAR51587459_2', 'BCAR51587502_2', 'BCAR51587547_2', 'BCAR51587572_2', 'BCAR51588014_2', 'BCAR51588037_2', 'BCAR51588076_2', 'BCAR51588177_2', 'BCAR51588231_2', 'BCAR51588282_2', 'BCAR51588385_2', 'BCAR51588426_2', 'BCAR51588520_2', 'BCAR51588589_2', 'BCAR51588665_2', 'BCAR51588732_2', 'BCAR51588810_2', 'BCAR51588986_2', 'BCAR51589053_2', 'BCAR51589055_2', 'BCAR51589114_2', 'BCAR51589122_2', 'BCAR51589192_2', 'BCAR51589230_2', 'BCAR51589293_2', 'BCAR51589327_2', 'BCAR51589330_2', 'BCAR51589339_2', 'BCAR51589380_2', 'BCAR51589405_2', 'BCAR51589542_2', 'BCAR51589596_2', 'BCAR51589652_2', 'BCAR51589712_2', 'BCAR51589723_2', 'BCAR51589795_2', 'BCAR51589900_2', 'BCAR51589909_2', 'BCAR51589957_2', 'BCAR51589962_2', 'BCAR51590028_2', 'BCAR51590124_2', 'BCAR51590132_2', 'BCAR51590141_2', 'BCAR51590163_2', 'BCAR51590206_2', 'BCAR51590286_2', 'BCAR51590287_2', 'BCAR51590400_2', 'BCAR51590442_2', 'BCAR51590494_2', 'BCAR51590567_2', 'BCAR51590629_2', 'BCAR51590672_2', 'BCAR51590707_2', 'BCAR51590795_2', 'BCAR51590835_2', 'BCAR51590867_2', 'BCAR51590876_2', 'BCAR51590899_2', 'BCAR51590957_2', 'BCAR51591016_2', 'BCAR51591033_2', 'BCAR51591201_2', 'BCAR51591227_2', 'BCAR51591286_2', 'BCAR51591394_2', 'BCAR51591396_2', 'BCAR51591403_2', 'BCAR51591654_2', 'BCAR51591681_2', 'BCAR51591697_2', 'BCAR51591713_2', 'BCAR51591728_2', 'BCAR51591837_2', 'BCAR51591942_2', 'BCAR51591967_2', 'BCAR51592137_2', 'BCAR51592200_2', 'BCAR51592217_2', 'BCAR51592270_2', 'BCAR51592394_2', 'BCAR51592428_2', 'BCAR51592434_2', 'BCAR51592490_2', 'BCAR51592511_2', 'BCAR51592526_2', 'BCAR51592656_2', 'BCAR51592711_2', 'BCAR51592730_2', 'BCAR51592747_2', 'BCAR51592769_2', 'BCAR51592785_2', 'BCAR51592820_2', 'BCAR51592856_2', 'BCAR51592870_2', 'BCAR51592895_2', 'BCAR51592917_2', 'BCAR51592933_2', 'BCAR51592991_2', 'BCAR51593053_2', 'BCAR51593060_2', 'BCAR51593109_2', 'BCAR51593191_2', 'BCAR52069771_2', 'BCAR52080784_2', 'BCAR52081017_2', 'BCAR52081064_2', 'BCAR52083644_2', 'BCAR52176094_2', 'BCAR52234624_2', 'BCAR52329742_2', 'BCAR52342880_2', 'BCAR52344513_2');
select lpn_facility_status, tc_lpn_id,lpn_id from lpn where tc_lpn_id in 
('00000197181864181021');
select * from DM.LPN_DETAIL where lpn_id in ('122629454');
select * from DM.WM_INVENTORY where TC_LPN_ID in ('00000156741227359868');
select do_status from orders where tc_order_id in ('CAR44532355_1');

select tc_lpn_id, tracking_nbr, manifest_nbr  from dm.lpn where tracking_Nbr= '9261297641993005598429';----USPS0015751
select DISTINCT stat_code from ALLOC_INVN_DTL where carton_nbr in ('00000197181758706101');

select DISTINCT stat_code from task_dtl where carton_nbr in ('00000197181753309680');

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,last_updated_source, ship_via from lpn where tc_lpn_id in ('99007121');

select DO_STATUS, tc_order_id from orders where tc_order_id in ('BCAR51532749_2', 'BCAR51579419_2', 'BCAR51586168_2', 'BCAR51586176_2', 'BCAR51586218_2', 'BCAR51586453_2', 'BCAR51586504_2', 'BCAR51586530_2', 'BCAR51586535_2', 'BCAR51586640_2', 'BCAR51586759_2', 'BCAR51586909_2', 'BCAR51586964_2', 'BCAR51586978_2', 'BCAR51587024_2', 'BCAR51587041_2', 'BCAR51587224_2', 'BCAR51587230_2', 'BCAR51587328_2', 'BCAR51587459_2', 'BCAR51587502_2', 'BCAR51587547_2', 'BCAR51587572_2', 'BCAR51588014_2', 'BCAR51588037_2', 'BCAR51588076_2', 'BCAR51588177_2', 'BCAR51588231_2', 'BCAR51588282_2', 'BCAR51588385_2', 'BCAR51588426_2', 'BCAR51588520_2', 'BCAR51588589_2', 'BCAR51588665_2', 'BCAR51588732_2', 'BCAR51588810_2', 'BCAR51588986_2', 'BCAR51589053_2', 'BCAR51589055_2', 'BCAR51589114_2', 'BCAR51589122_2', 'BCAR51589192_2', 'BCAR51589230_2', 'BCAR51589293_2', 'BCAR51589327_2', 'BCAR51589330_2', 'BCAR51589339_2', 'BCAR51589380_2', 'BCAR51589405_2', 'BCAR51589542_2', 'BCAR51589596_2', 'BCAR51589652_2', 'BCAR51589712_2', 'BCAR51589723_2', 'BCAR51589795_2', 'BCAR51589900_2', 'BCAR51589909_2', 'BCAR51589957_2', 'BCAR51589962_2', 'BCAR51590028_2', 'BCAR51590124_2', 'BCAR51590132_2', 'BCAR51590141_2', 'BCAR51590163_2', 'BCAR51590206_2', 'BCAR51590286_2', 'BCAR51590287_2', 'BCAR51590400_2', 'BCAR51590442_2', 'BCAR51590494_2', 'BCAR51590567_2', 'BCAR51590629_2', 'BCAR51590672_2', 'BCAR51590707_2', 'BCAR51590795_2', 'BCAR51590835_2', 'BCAR51590867_2', 'BCAR51590876_2', 'BCAR51590899_2', 'BCAR51590957_2', 'BCAR51591016_2', 'BCAR51591033_2', 'BCAR51591201_2', 'BCAR51591227_2', 'BCAR51591286_2', 'BCAR51591394_2', 'BCAR51591396_2', 'BCAR51591403_2', 'BCAR51591654_2', 'BCAR51591681_2', 'BCAR51591697_2', 'BCAR51591713_2', 'BCAR51591728_2', 'BCAR51591837_2', 'BCAR51591942_2', 'BCAR51591967_2', 'BCAR51592137_2', 'BCAR51592200_2', 'BCAR51592217_2', 'BCAR51592270_2', 'BCAR51592394_2', 'BCAR51592428_2', 'BCAR51592434_2', 'BCAR51592490_2', 'BCAR51592511_2', 'BCAR51592526_2', 'BCAR51592656_2', 'BCAR51592711_2', 'BCAR51592730_2', 'BCAR51592747_2', 'BCAR51592769_2', 'BCAR51592785_2', 'BCAR51592820_2', 'BCAR51592856_2', 'BCAR51592870_2', 'BCAR51592895_2', 'BCAR51592917_2', 'BCAR51592933_2', 'BCAR51592991_2', 'BCAR51593053_2', 'BCAR51593060_2', 'BCAR51593109_2', 'BCAR51593191_2', 'BCAR52069771_2', 'BCAR52080784_2', 'BCAR52081017_2', 'BCAR52081064_2', 'BCAR52083644_2', 'BCAR52176094_2', 'BCAR52234624_2', 'BCAR52329742_2', 'BCAR52342880_2', 'BCAR52344513_2');---79217973

select DO_DTL_STATUS from DM.ORDER_LINE_ITEM where order_id in ('79217973');

select lpn_facility_status,lpn_id,tc_lpn_id,manifest_nbr,tc_order_id,ship_via,last_updated_source, tc_shipment_id from lpn where tc_lpn_id in ('00000197181801203540', '00000197181801205346', '00000197181801204905', '00000197181801204806', '00000197181801204851', '00000197181801205353', '00000197181801204295', '00000197181801204479', '00000197181801205216', '00000197181801204899', '00000197181801205278', '00000197181801204165', '00000197181801204769', '00000197181801204738', '00000197181801204516', '00000197181801203861', '00000197181801204912', '00000197181801205339', '00000197181801204813');--00000197181801203861, 00000197181801205346
select lpn_facility_status,lpn_id,tc_lpn_id,manifest_nbr,tc_order_id,ship_via,last_updated_source, tc_shipment_id from lpn where manifest_nbr in ('FXGD000020711');

select INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('00001921700269723795');

select tc_shipment_id, LPN_ASSIGNMENT_STOPPED, SHIPMENT_CLOSED_INDICATOR, SHIPMENT_STATUS  from DM.SHIPMENT where tc_shipment_id in ('CS48809797','CS48809800','CS48809794');
select * from DM.LPN_DETAIL where lpn_id in ('120951563');
select do_status,order_id,order_type,tc_order_id,SHIPMENT_ID,TC_SHIPMENT_ID,D_ADDRESS_1,D_ADDRESS_2,D_ADDRESS_3,
D_CITY,D_STATE_PROV,D_POSTAL_CODE,D_COUNTRY_CODE,BILL_TO_EMAIL,D_NAME  from orders where tc_order_id in ('1236836392');
select * from lpn_detail where lpn_id in ('120896224');--323732038
select ORDER_ID,LINE_ITEM_ID, DO_DTL_STATUS from DM.ORDER_LINE_ITEM where ORDER_ID in ('79891464') and do_dtl_status < 200;

select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,tc_shipment_id,last_updated_source, TC_REFERENCE_LPN_ID, ship_via 
from lpn where tc_lpn_id in ('00000197181983378937');
select * from picking_short_item where tc_lpn_id in ('00000197181928873695')and STAT_CODE < '90';
select * from lpn_lock where tc_lpn_id in ('00000197181928873695');
select * from DM.ALLOC_INVN_DTL where carton_nbr in ('00000197181928873695') and stat_code < '90';
select * from DM.TASK_DTL where carton_nbr in ('00000197181928873695') and stat_code < '90';

select * from lpn where tc_shipment_id in ('CS54611135');
select * from lpn where TC_LPN_ID in ('99004931');---99004931
select * from DM.ALLOC_INVN_DTL where cntr_nbr in ('99027320', '99008931', '99022468') and stat_code < '90';---970100017225--60
select * from DM.TASK_DTL where cntr_nbr in ('99027320', '99008931', '99022468') and stat_code < '90';---100317664, 100268762
select * from TASK_GRP_ELGBLTY where INVN_NEED_TYPE in ('50');
select * from sys_code where code_type in ('CCF');
select * from item_cbo where item_id in ('2677177');----192135919187
select stat_code from task_hdr where task_id in ('99014144');

select * from DM.TASK_DTL where  task_id in ('101149356') and stat_code < '90';
select stat_code from task_hdr where task_id in ('99014144');

select * from DM.WM_INVENTORY where location_id = '100235383' and item_id = '2676437' and wm_allocated_qty < 0;
select * from locn_hdr where locn_id in ('100235383');

select task_id, stat_code from task_hdr where task_id in ('94992485', '94959279', '94959298', '94959301', '94959294', '94884414', '94831789', '94959292', '94959288', '94920713', '94959278', '95077191', '95077191', '95077191');
select task_id, stat_code from task_dtl where task_id in ('94992485', '94959279', '94959298', '94959301', '94959294', '94884414', '94831789', '94959292', '94959288', '94920713', '94959278', '95077191', '95077191', '95077191') and stat_code <'90';
Vishwa---
select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status,LAST_UPDATED_SOURCE,INBOUND_OUTBOUND_INDICATOR,LAST_UPDATED_SOURCE 
from lpn where lpn_facility_status <20 and inbound_outbound_indicator = 'O' and d_facility_alias_id is not null
and tc_lpn_id in ('EXC_030219_001068135'); 

--open task:
select task_id,cntr_nbr,carton_nbr, QTY_ALLOC, QTY_PULLD, stat_code,INVN_NEED_TYPE,CURR_WORK_AREA,CURR_WORK_GRP,user_id from 
task_dtl where stat_code < 90 and cntr_nbr in ('99022935'); 


--open allocations:
select * from alloc_invn_dtl 
where cntr_nbr in ('99005730') and stat_code < '90'; 

--open cartons:
----vishwa
select ic.item_bar_code, ic.item_name, aid.batch_nbr, aid.qty_alloc, aid.cntr_nbr, aid.stat_code, aid.carton_nbr, lfs.description, l.lpn_facility_status LFS, l.chute_id, aid.mod_date_time,user_id
from item_cbo ic, alloc_invn_dtl aid, lpn l, lpn_facility_status lfs
where  aid.item_id = ic.item_id and aid.carton_nbr = l.tc_lpn_id
and l.inbound_outbound_indicator = lfs.inbound_outbound_indicator and l.lpn_facility_status = lfs.lpn_facility_status
and aid.carton_nbr in ('00000156740070851666', '970094874533', '970094871949''99036505', '99049660', '99009956', '99018987', '99039252', '99022021', '99004506', '99023731', '99027360', '99012777', '99002152', '99044799', '99046676', '99030954', '99001151', '99005753', '99049341', '99027289')
and aid.stat_code < '90'
order by aid.carton_nbr asc;
---abhilaikh
select aid.STAT_CODE, aid.CNTR_NBR, aid.CARTON_NBR, aid.INVN_NEED_TYPE, aid.ALLOC_INVN_DTL_ID, lpn.tc_lpn_id, lpn.lpn_facility_status
from DM.ALLOC_INVN_DTL aid, DM.LPN 
where aid.CNTR_NBR in ('99004115') and aid.CARTON_NBR = lpn.tc_lpn_id and aid.stat_code < '90'and lpn.lpn_facility_status < '20';

--to find the master olpn
select tc_reference_lpn_id,tc_order_id,tc_lpn_id,ship_via,tracking_nbr,lpn_facility_status,NON_INVENTORY_LPN_FLAG,LAST_UPDATED_SOURCE
from lpn where ( tc_lpn_id = '00000197181798611854' or tc_reference_lpn_id = '00000197181798611854'); 

select ic.item_bar_code, ic.item_name, aid.batch_nbr, aid.qty_alloc, aid.cntr_nbr, aid.stat_code, aid.carton_nbr, lfs.description, l.lpn_facility_status LFS, l.chute_id, aid.mod_date_time,user_id
from item_cbo ic, alloc_invn_dtl aid, lpn l, lpn_facility_status lfs
where  aid.item_id = ic.item_id and aid.carton_nbr = l.tc_lpn_id
and l.inbound_outbound_indicator = lfs.inbound_outbound_indicator and l.lpn_facility_status = lfs.lpn_facility_status
and aid.cntr_nbr in ('EXC_271118_000849910')
and aid.stat_code < '90'
order by aid.carton_nbr asc;

select aid.STAT_CODE, aid.CNTR_NBR, aid.CARTON_NBR, aid.INVN_NEED_TYPE, aid.ALLOC_INVN_DTL_ID, lpn.tc_lpn_id, lpn.lpn_facility_status
from DM.ALLOC_INVN_DTL aid, DM.LPN 
where aid.CNTR_NBR in ('970097507054') and aid.CARTON_NBR = lpn.tc_lpn_id and aid.stat_code < '90'and lpn.lpn_facility_status < '20';

select * from lpn_detail where lpn_id in ('115500103');

select * from WM_INVENTORY where TC_LPN_ID in ('99038124');
select * from lpn l 
where tc_lpn_id in ('970100009057', '970100009291', '970100009315', '970100009380', '970100009667', '970100009983',
'970100010063', '970100010084', '970100010586', '970100010772', '970100010783', '970100010899', '970100010977', '970100010979',
'970100011091', '970100011198', '970100011839', '970100011917', '970100012085', '970100012269', '970100012293', '970100012486',
'970100012498', '970100012940', '970100013054', '970100013206', '970100013212', '970100013244', '970100013262', '970100013280', 
'970100013414', '970100013512', '970100013600', '970100013676', '970100013689', '970100013743', '970100014191', '970100014236', 
'970100014330', '970100014723', '970100014872', '970100015199', '970100015221', '970100015305', '970100015340', '970100015367', 
'970100015475', '970100015511', '970100015520', '970100015662', '970100015714', '970100016122', '970100016124', '970100016412', 
'970100016459', '970100016482', '970100016521', '970100017502', '970100017633', '970100017963', '970100018028', '970100018084', 
'970100018167', '970100018310', '970100018441', '970100018629', '970100018734', '970100018946')
and not exists (select tc_lpn_id from wm_inventory wm where wm.tc_lpn_id = l.tc_lpn_id)
and not exists (select lpn_id from lpn_detail ld where ld.lpn_id = l.lpn_id);

select * from sys_code where code_type in ('CCF');


-----These are retail cartons for PTS (Put to Store)

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and d_facility_alias_id is not null and tc_lpn_id in ('00000019718136366927','00000001971813636705','00000001971813636462');

----These are STS cartons (BOSS)

select tc_lpn_id, tc_order_id, misc_instr_code_3, d_facility_alias_id, lpn_facility_status from lpn 
where lpn_facility_status < 20 and inbound_outbound_indicator = 'O' and misc_instr_code_3 > 0 and d_facility_alias_id is  null and tc_lpn_id in ('00000197181365184538');

-----------------------------failed to assign----------------
select lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,tc_shipment_id,last_updated_source, TC_REFERENCE_LPN_ID, ship_via 
from lpn where tc_lpn_id in ('00000197180061663262');

select tc_order_id, tc_shipment_id from lpn where tc_lpn_id in ('00000197181928860664');

select * from orders where tc_order_id in ('CAR67680086_1'); 

select * from postal_code where postal_code in ('73065');

select * from ship_via where ship_via in ('CALL');

select * from ship_via;


select DO_STATUS from orders where tc_order_id in ('CAR55989772_1');
