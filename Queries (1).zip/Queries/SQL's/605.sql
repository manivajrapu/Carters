select * from lpn;

select dept,
	 case when l.tc_lpn_id in (select tc_lpn_id from task_dtl where stat_code < 99 and invn_need_type = 2)
then 'FCP' else 'No' end as fcp_type,o.O_facility_alias_id,COUNT(DISTINCT(l.tc_lpn_id)) AS LPNS,NVL(o.order_type, 'RT') MERCH_CLASS, 
o.PACK_WAVE_NBR||' '||wp.wave_desc PICK_WAVE_NBR, 
decode(order_type,null,'249380','CR','249380',o.D_POSTAL_CODE) SOLDTO,
CASE WHEN NVL(o.line_haul_ship_via,'ZZZ') = 'DCB' AND NVL(spl_instr_2,'001') = '001' THEN 'CARTER RETAIL DCB'
WHEN NVL(o.line_haul_ship_via,'ZZZ') = 'DCB' AND NVL(spl_instr_2,'001') = '002' then 'OSHKOSH RETAIL DCB'  
WHEN NVL(spl_instr_2,'001') = '001' THEN  decode(order_type,null,'CARTER RETAIL','CR','CARTERS E-COMMERCE',o.bill_to_name)
WHEN NVL(spl_instr_2,'001') = '002' THEN  decode(order_type,null,'OSHKOSH RETAIL','CR','OSHKOSH E-COMMERCE',o.bill_to_name)
ELSE bill_to_name END AS bill_to_name, 
decode(merch_class,null,'PICK PACK',decode(intl_goods_desc,null,o.purchase_order_number,'Master PO - '||intl_goods_desc)) PO_NBR, 
ph.FREIGHT_TERMS, 
sum(case when l.lpn_facility_status < 20 then cd.TO_BE_PAKD_UNITS - cd.UNITS_PAKD else 0 end) UNPACKED_QTY, 
sum(case when l.lpn_facility_status < 40 and curr_locn_id is null then cd.UNITS_PAKD else 0 end) PACKED_QTY, 
sum(case when l.lpn_facility_status < 40 and curr_locn_id is not null then cd.UNITS_PAKD else 0 end) STAGED_QTY, 
sum(case when l.lpn_facility_status >= 40 then cd.UNITS_PAKD else 0 end) LOADED_MANF_QTY, 
sum(case when l.lpn_facility_status < 20 then cd.TO_BE_PAKD_UNITS else cd.UNITS_PAKD end) TOTAL_QTY, 
sum(case when l.lpn_facility_status < 20 then (cd.TO_BE_PAKD_UNITS - cd.UNITS_PAKD)*PRICE else 0 end) UNPACKED_DOLLAR, 
sum(case when l.lpn_facility_status < 40 and curr_locn_id is null then cd.UNITS_PAKD*PRICE else 0 end) PACKED_DOLLAR, 
sum(case when l.lpn_facility_status < 40 and curr_locn_id is not null then cd.UNITS_PAKD*PRICE else 0 end) STAGED_DOLLAR, 
sum(case when l.lpn_facility_status >= 40 then cd.UNITS_PAKD*PRICE else 0 end) LOADED_MANF_DOLLAR, 
sum(case when l.lpn_facility_status < 20 then cd.TO_BE_PAKD_UNITS*PRICE else cd.UNITS_PAKD*PRICE end) TOTAL_DOLLAR,
case when l.lpn_facility_status = 10 then 'Printed'
when l.lpn_facility_status = 15 then 'In Packing'
when l.lpn_facility_status = 20 and curr_locn_id is not null then 'Staged'
when l.lpn_facility_status = 20 then 'Packed'
when l.lpn_facility_status   = 30 and curr_locn_id is not null then 'Staged'
when l.lpn_facility_status = 30 then 'Weighed'
when l.lpn_facility_status = 40 then 'LOADED_MANF'
when l.lpn_facility_status = 50 then 'LOADED_MANF' 
when l.lpn_facility_status = 90 then 'Shipped'
else 'Other Status' end as Carton_status,nvl(ch.load_nbr,'No Load Nbr') as load_nbr,ship_via_desc,curr_plt_id,
ph.start_ship_date,ph.create_date_time as download_date,nvl(ph.stop_ship_date,ph.start_ship_date) as stop_ship_date,shipto,ol.xpct_start_date_time as ship_date,prod_group,NVL(TERR_CODE,'001') AS TERR_CODE
from orders o, orders o, lpn l, lpn_detail ld, order_line_item ol, wave_parm wp,
OUTBD_LOAD OL, item_master im,ship_via sv,
