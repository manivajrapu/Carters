alter session set current_schema=wmprod33;

select * from manif_parcl_hdr mph where mph.manif_nbr in (select mpc.manif_nbr from manif_parcl_carton mpc where mpc.parcl_shpmt_nbr in ('0046920','FXEX330004952')); --Returns an error manifest �0044747� in a 90 status and 'FXEX330004856' which is in an error status.
select * from manif_parcl_carton where manif_nbr in ('0049940','0049938','0049939','FXEX330005055','FXEX330005058','FXEX330005059'); -- All cartons are in a 9

select manif_nbr,stat_code
from manif_parcl_hdr
where manif_nbr in ('0052992','0052993','0052994')
and stat_code < '90';


select * from inpt_pkt_dtl;


select
    ph.pkt_ctrl_nbr,
    ph.create_date_time,
    ph.mod_date_time,
    ph.shipto_name,
    ph.store_nbr,
    ph.ship_via,
    phi.stat_code,
    ch.carton_nbr,
    ch.ship_via
FROM
    pkt_hdr ph,
    pkt_hdr_intrnl phi,
    carton_hdr ch
WHERE
    ph.store_nbr IN (
        SELECT
            sm.store_nbr
        FROM
            store_master sm
        where
            sm.ship_via = 'CARD'
         and sm.whse = 33
    )
    and   ph.pkt_ctrl_nbr = phi.pkt_ctrl_nbr
    and   phi.pkt_ctrl_nbr = ch.pkt_ctrl_nbr
    and   phi.stat_code < '90';

select * from alloc_invn_dtl where TASK_GENRTN_REF_NBR in ('201902040043') and stat_code < 90; 
select * from task_dtl where TASK_GENRTN_REF_NBR in ('201902040043') and stat_code < 90;

SELECT CNTR_NBR, (select dsp_locn from locn_hdr, case_hdr where locn_hdr.locn_id = case_hdr.locn_id and case_nbr = cntr_nbr) as location

, dsp_sku, INVN_NEED_TYPE, SUM(QTY_ALLOC), alloc_invn_dtl.STAT_CODE 

FROM ALLOC_INVN_DTL, PKT_DTL, item_master, case_hdr ch

WHERE INVN_NEED_TYPE = 60 

AND alloc_invn_dtl.STAT_CODE < 90 

and alloc_invn_dtl.sku_id = item_master.sku_id

AND alloc_invn_dtl.pkt_ctrl_nbr = pkt_dtl.pkt_ctrl_nbr 

and alloc_invn_dtl.CNTR_NBR = ch.case_nbr

and alloc_invn_dtl.pkt_seq_nbr = pkt_dtl.pkt_seq_nbr 

and pkt_dtl.wave_nbr = '201902040043'

GROUP BY CNTR_NBR, ch.locn_id, dsp_sku, INVN_NEED_TYPE, ALLOC_INVN_DTL.STAT_CODE;
