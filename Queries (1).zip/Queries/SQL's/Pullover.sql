alter session SET Current_schema=DM;

select l.tc_order_id, o.order_id, o.order_status, o.do_status, l.tc_lpn_id, l.lpn_facility_status, l.tc_shipment_id, l.shipment_id, l.ship_via, 
o.ship_group_id, l.order_split_id, o.bill_to_name, o.acct_rcvbl_acct_nbr, l.created_dttm, l.voco_intrn_reverse_pallet_id
from dm.orders o, dm.lpn l where o.order_id = l.order_id and (o.ship_group_id = upper('MIDDLETWN 11/06') or 
o.ship_group_id = upper('MIDDLETWN 11/06') ) and l.lpn_facility_status < 50 and l.shipment_id is null order by 1;


select l.tc_order_id, o.order_id, o.order_status, o.do_status, l.tc_lpn_id, l.lpn_facility_status, l.tc_shipment_id, l.shipment_id, l.ship_via, 
o.ship_group_id, l.order_split_id, o.bill_to_name, o.acct_rcvbl_acct_nbr, l.created_dttm,l.LAST_UPDATED_DTTM ,l.voco_intrn_reverse_pallet_id
from dm.orders o, dm.lpn l where o.order_id = l.order_id and (o.ship_group_id = upper('MIDDLETWN 11/06') or 
o.ship_group_id = upper('MIDDLETWN 11/06') ) and l.lpn_facility_status < 50 and l.shipment_id is NOT null order by 1;


select distinct l.tc_shipment_id,l.shipment_id, l.ship_via
from dm.orders o, dm.lpn l where o.order_id = l.order_id and (o.ship_group_id = upper('MIDDLETWN 11/06') or 
o.ship_group_id = upper('MIDDLETWN 11/06') ) and l.lpn_facility_status < 50 order by 1;

select * from task_dtl where task_id in ('92634974', '92634779', '92634770', '92634696', '92634585', '92634532') and stat_code<90;

select * from shipment where tc_shipment_id in ('CS48216623');---47260541--SWIF

select * from lpn where shipment_id in ('47260541');--CS48216623

select * from lpn where tc_lpn_id in ('00000197181793233310', '00000197181793233303', '00000197181793233297', '00000197181793233280', '00000197181793233365', 
'00000197181793233334', '00000197181793233341', '00000197181793233358', '00000197181793233327', '00000197181793233136', '00000197181793233129', '00000197181793233112', '00000197181793233105', 
'00000197181793233143', '00000197181793233167', '00000197181793233150', '00000197181793233211', '00000197181793233228', '00000197181793233235', '00000197181793233242', '00000197181793233259', 
'00000197181793233266', '00000197181793233273', '00000197181793233174', '00000197181793233204', '00000197181793233198', '00000197181793233181');
