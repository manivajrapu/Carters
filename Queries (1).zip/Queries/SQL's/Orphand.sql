alter session set current_schema=DM;

select aid.cntr_nbr, im.item_name, im.item_bar_code, aid.batch_nbr, aid.carton_nbr, aid.qty_alloc, aid.mod_date_time
from alloc_invn_dtl aid, lpn l, orders o, item_cbo im where l.tc_lpn_id = aid.cntr_nbr and aid.tc_order_id = o.tc_order_id and aid.item_id = im.item_id 
            and aid.invn_need_type = 52 and aid.stat_code = 0
and l.lpn_facility_status <> 64 and o.order_type = 'EC';


select * from lpn where tc_lpn_id='00000156740070575432' and inbound_outbound_indicator='I'; --95   970016894712,970900824163

select tc_lpn_id,lpn_facility_status,lpn_id,TOTAL_LPN_QTY,item_id  from lpn where tc_lpn_id in('00000197181732680632');

select tc_lpn_id,lpn_facility_status,lpn_id,TOTAL_LPN_QTY,item_id  from lpn where tc_lpn_id in('00000156740070574404', '00000156740070574039', '00000156740070574336','00000156740070574312','00000156740070574947','00000156740070575005','00000156740070574930');

select * from DM.ALLOC_INVN_DTL where CNTR_NBR='970901361075' and STAT_CODE<90;

select * from item_cbo where item_id in ('2556457');

select * from DM.PIX_TRAN where CASE_NBR='970074744567';

--If it is in 95 status recreate the ilpn in RF

select * from lpn where tc_lpn_id='00000197181614264035' and inbound_outbound_indicator='O'; --15

select * from lpn where tc_lpn_id='970072827031' and inbound_outbound_indicator='I'; --95

select aid.cntr_nbr, im.item_bar_code, im.item_name, im.item_id, aid.orig_reqmt, aid.invn_need_type, aid.dest_locn_id, aid.batch_nbr, aid.qty_alloc, aid.qty_pulld, aid.carton_nbr, aid.stat_code, aid.pull_locn_id, aid.user_id, aid.create_date_time, aid.mod_date_time, tc_order_id from alloc_invn_dtl aid, item_cbo im  where aid.item_id = im.item_id and aid.cntr_nbr in (
'00000197181614264035'
) and stat_code  < 90;-----------------kal


select lpn_detail_status,batch_nbr, initial_qty, item_name from lpn_detail where lpn_id='77940761'; --initial_qty should match with alert SCI.77940254

-------------------------------------------------------------------------------------------SKU missing

select aid.cntr_nbr, im.item_bar_code, im.item_name, im.item_id, aid.orig_reqmt,
aid.invn_need_type, aid.dest_locn_id, aid.batch_nbr, aid.qty_alloc, aid.qty_pulld, 
aid.carton_nbr, aid.stat_code, aid.pull_locn_id, aid.user_id, aid.create_date_time, 
aid.mod_date_time, tc_order_id from alloc_invn_dtl aid, item_cbo im  where aid.item_id = im.item_id and aid.cntr_nbr in (
'970900808791'
) and stat_code < 90;


select * from lpn where tc_lpn_id='970900808791' and inbound_outbound_indicator='I';  
  
select * from lpn where tc_lpn_id='00000197181586581338' and inbound_outbound_indicator='O';

select lpn_detail_status,batch_nbr, initial_qty, item_name from lpn_detail where lpn_id='76889771';

select unique(cntr_nbr) from alloc_invn_dtl aid where carton_nbr = '00000197181732680632'
  and exists (select 1 from arch_lpn al where al.tc_lpn_id = aid.cntr_nbr)
  and not exists (select 1 from lpn l where l.tc_lpn_id = aid.cntr_nbr)
  and aid.cntr_nbr is not null
  and aid.invn_need_type = 52;----EXC_281018_000605569
		  
  