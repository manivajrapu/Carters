alter session SET Current_schema=wmprod33;

select * from outbd_load where load_nbr in ('3300122443');
select * from manif_parcl_carton where manif_nbr='FXGD330058367' and stat_code<40;
select * from carton_hdr where load_nbr in ('3300122443') and stat_code<90;
select carton_nbr, pkt_ctrl_nbr, stat_code, load_nbr from carton_hdr where carton_nbr in ('00000197183469005955','00000197183468710232');
select * from carton_lock where carton_nbr in ('00000197183469005955','00000197183468710232');
 
select * from outpt_outbd_load where load_nbr in ('3300122443');
select invc_batch_nbr from outpt_carton_hdr where pkt_ctrl_nbr in ('3406744593','3402373127','3400000131');
select * from pkt_hdr_intrnl where pkt_ctrl_nbr in ('3406744593','3402373127','3400000131');
 
select distinct(proc_stat_code), invc_batch_nbr from outpt_pkt_dtl where pkt_ctrl_nbr in (select pkt_ctrl_nbr from carton_hdr where load_nbr ='3300122154');
 
select distinct(proc_stat_code) from outpt_carton_dtl where carton_nbr in (select carton_nbr from carton_hdr where  load_nbr ='3300098942');---330480991
select distinct(proc_stat_code)  from outpt_carton_hdr where invc_batch_nbr in('330416340');
select stat_code  from pkt_hdr_intrnl where pkt_ctrl_nbr in (select pkt_ctrl_nbr from carton_hdr where load_nbr = ('3300098942'));
 
select distinct(proc_stat_code)from outpt_pkt_hdr where pkt_ctrl_nbr in(select pkt_ctrl_nbr from carton_hdr where load_nbr ='3300122154');
 
select load_nbr,stat_code, count(*)
from carton_hdr
where load_nbr in ('3300122443')
and ((stat_code < '90') or
        (stat_code = '99'))
group by load_nbr,stat_code;
 
select phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,
          ph.plan_bol, ph.plan_master_bol,count(*)
from pkt_hdr ph,
     pkt_hdr_intrnl phi
where ph.pkt_ctrl_nbr in (select distinct ch.pkt_ctrl_nbr
                          from carton_hdr ch
                          where load_nbr in ('3300098942')
                          and ((stat_code < '90') or
                               (stat_code = '99')))
and ph.plan_load_nbr = '3300098942'
and phi.pkt_ctrl_nbr = ph.pkt_ctrl_nbr
group by phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,
          ph.plan_bol, ph.plan_master_bol;
         
          select * from EISPROD33.cl_endpoint_queue
where cl_endpoint_queue.endpoint_id = 4
  and status = 6
  and target_uri is null;
 
select * from EISPROD33.CL_ENDPOINT_QUEUE where cl_endpoint_queue.endpoint_id = 4 and status =5;
select * from item_master where style='GB15831' and style_sfx='AST' and size_desc='2';
select * from inpt_item_master where style='GB15831' and style_sfx='AST' and size_desc='2';
select * from inpt_item_master where proc_stat_code>0;
select * from msg_log where ref_value_1='10466175';
select error_seq_nbr, proc_stat_code, create_date_time from inpt_item_master where proc_stat_code>0 and error_seq_nbr>0 order by create_date_time;
 select style,style_sfx,size_desc,sec_dim from inpt_item_master where proc_stat_code>0 and error_seq_nbr>0 order by create_date_time;



select load_nbr,stat_code from outbd_load where load_nbr in ('3300101711','3300101709','3300101714');
select count(*) from carton_hdr where load_nbr in ('3300101711','3300101709','3300101714') and stat_code < '90';

select count(*)
from carton_hdr ch
where load_nbr in ('3300122154') and stat_code < '90';

select phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,ph.plan_bol, ph.plan_master_bol,count(*) from pkt_hdr ph,pkt_hdr_intrnl phi where ph.pkt_ctrl_nbr in (select distinct ch.pkt_ctrl_nbr
                          from carton_hdr ch
                          where load_nbr in ('3300101711','3300101709','3300101714')
                            and ((stat_code < '90') or (stat_code = '99')))
  and ph.plan_load_nbr in ('3300101711','3300101709','3300101714')
  and phi.pkt_ctrl_nbr = ph.pkt_ctrl_nbr group by phi.pkt_ctrl_nbr,phi.stat_code,ph.plan_load_nbr,ph.plan_shpmt_nbr,ph.plan_bol, ph.plan_master_bol;
  
  
  select * from inpt_asn_hdr;
  select * from inpt_asn_dtl;
 
select load_nbr, stat_code, user_id from outbd_load where load_nbr in ('3300122443');--3300122034

select carton_nbr, stat_code, rte_id, ship_via, pkt_ctrl_nbr from carton_hdr where load_nbr in ('3300122443') and stat_code = '90'; --3362034767

select count(*)
from carton_hdr ch
where load_nbr in ('3300122443') and stat_code < '90';

select pkt_ctrl_nbr from carton_hdr where load_nbr in ('3300122443'); 
