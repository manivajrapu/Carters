alter session set current_schema=wmprod33;

select stat_code,case_nbr
from  CASE_HDR
where case_nbr in ('00006644540474688361', '00006644540474687104', '00006644543322536784', '00006644540474687036');

select *
from  CArton_hdr
where carton_nbr in ('00000197183504435570') and ;

Select carton_nbr, sku_id, alloc_invn_dtl_id, stat_code, cntry_of_orgn from alloc_invn_dtl where carton_nbr in ('00000197183504435570') and sku_id in(�#�);