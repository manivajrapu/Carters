alter session set current_schema=DM;


select * from item_cbo;

select * from lpn where tc_lpn_id = '00123412341234123499';

select * from wm_inventory where tc_lpn_id = '00123412341234123499';

select * from lpn_lock where tc_lpn_id = '00123412341234123499';

select * from locn_hdr where locn_class = 'R';

--------------------------------------------------------------

select WI.ITEM_ID, WI.ON_HAND_QTY, WI.WM_ALLOCATED_QTY, WI.TO_BE_FILLED_QTY, WI.LOCN_CLASS, WI.LOCATION_ID, WI.*, PLD.*
from WM_INVENTORY WI join PICK_LOCN_DTL PLD 
on WI.location_id = PLD.locn_id
where WI.LOCN_CLASS in (select LOCN_CLASS from LOCN_HDR where PICK_DETRM_ZONE = 'UNS')
and WI.ALLOCATABLE = 'Y'
and WI.ON_HAND_QTY> '0'
and WI.TO_BE_FILLED_QTY = '0'
and WI.WM_ALLOCATED_QTY= '0'
and WI.BATCH_NBR = 'EC002'
--and WI.LOCATION_ID in (select locn_id from locn_hdr where work_grp = 'ACT' and work_area = 'OSR')
order by WI.ITEM_ID; 


select * from wm_inventory where batch_nbr = 'EC002' and item_id = '2959794';

select * from item_cbo where item_id = '2959794';

select * from orders;

select do_status, orders.* from orders where tc_order_id = 'TST007855922_2';

select * from TRAN_LOG

select * from PICK_LOCN_HDR where locn_id = '620510658';

select * from pick_locn_dtl where locn_id = '620510658';

select * from LOCN_HDR where locn_id = '0004360';

select * from alloc_invn_dtl where task_genrtn_ref_nbr = '202009170002001';

select * from lpn where tc_lpn_id in ('00000197181978380419', '00000123443211234567'); --lpn_detail
select * from task_dtl where task_genrtn_ref_nbr = '202009170002001';

select * from task_hdr where task_id = '30822660';
select * from task_dtl where task_id = '30822660';
select * from task_hdr where task_id = '30822370';--
select * from WM_INVENTORY where LOCATION_ID = '0004360' and ITEM_ID = '2918471'; 

select * from wm_inventory where location_id = '620549369';

select * from wm_inventory where location_id = '0004359';

select * from locn_hdr where work_grp = 'CONV' and work_area = 'CONV';

select * from TASK_GRP_ELGBLTY where invn_need_type = '50';

select * from TASK_GRP_ELGBLTY where invn_need_type = '50' and work_grp = 'ACT' and work_area = 'UNS';

select * from tran_log where msg_type = 'DistributionOrder';

select * from tran_log_message where tran_log_id = '669832168';

--------------For getting xml
select * from TRAN_LOG where Upper(msg_type) = 'DISTRIBUTIONORDER';
SELECT * FROM TRAN_LOG_MESSAGE where TRAN_LOG_ID = '790991694';