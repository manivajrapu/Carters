alter session set current_schema=wmprod33;

select phi.STAT_CODE, ph.ORD_TYPE, ph.PKT_CTRL_NBR, ph.CUST_PO_NBR, ph.ACCT_RCVBL_ACCT_NBR, ph.CARTON_CUBNG_INDIC from pkt_hdr ph, pkt_hdr_intrnl phi 
 where ph.ACCT_RCVBL_ACCT_NBR = '800012' 
   and ph.ord_type = 'RP' 
   and ph.CARTON_CUBNG_INDIC = '51'
   and ph.PKT_CTRL_NBR = phi.PKT_CTRL_NBR
   and phi.STAT_CODE < 90;
 
 
select load_nbr, stat_code, user_id from outbd_load where load_nbr in ('3300122034');--3300122034

select carton_nbr, stat_code, rte_id, ship_via, pkt_ctrl_nbr from carton_hdr where carton_nbr in ('00000197183501303063'); --null--shpmt_nbr
select * from carton_hdr where carton_nbr in ('00000197183504042662');--3300219548

select * from WMPROD33.CARTON_DTL where pkt_ctrl_nbr in ('3418789846');
select count(*) from carton_hdr where pkt_ctrl_nbr in ('3418789846') and rte_id is null;
 ----------------------------------------------------------------------------------------------------------------
 --Carton has no route-----
   select PKT_CTRL_NBR,rte_id from carton_hdr where PKT_CTRL_NBR in ('3418789846')  and rte_id is null;  
   select count(*) from carton_hdr where pkt_ctrl_nbr in ('3421127647') and rte_id is null;
   --9
   
   selecT DISTINCT(RTE_ID) fRom carton_hdr where pkt_ctrl_nbr in ('3364337399'); 

   select count(*) from carton_hdr where pkt_ctrl_nbr in('3364337399')  and rte_id is null; 
   
   select PKT_CTRL_NBR,rte_id from carton_hdr where pkt_ctrl_nbr in ('3410246202', '3415281378', '3415292822', '3415293513', '3415293993', '3415296422', '3415297056') and rte_id is null;
   select pkt_ctrl_nbr,rte_id from carton_hdr where pkt_ctrl_nbr in ('3415108530','3415109331','3415113411','3415118547','3415119247','3415100340');
   
   select carton_nbr, stat_code from carton_hdr where carton_nbr in ('00000197183490172350', '00000197183502050867', '00000197183502050874', '00000197183502147093', '00000197183502147109', '00000197183502147116', '00000197183502147130', '00000197183502147161', '00000197183502147178', '00000197183502263540', '00000197183502326061');
   
select carton_nbr, stat_code, total_qty, User_id from carton_hdr where carton_nbr in ('00000197184073785097');--15--3364337399
select case_nbr, stat_code,  User_id from case_hdr where case_nbr in ('00006644549817933960');--95
select * from carton_dtl where carton_nbr in ('00000197184073785097');--119032538 --sku
select * from alloc_invn_dtl where cntr_nbr in ('00006644549817933960') and stat_code < 90; 
select * from alloc_invn_dtl where carton_nbr in ('00000197184073785097') and stat_code < 90;
select * from task_dtl where cntr_nbr in ('00006644549817933960') and stat_code < 90; 
select QTY_ALLOC, QTY_PULLD, Stat_code, task_id, cntr_nbr, carton_nbr, INVN_NEED_TYPE, Sku_id from task_dtl where cntr_nbr in ('00006644549817933960') and stat_code < 90;
select * from task_dtl where carton_nbr in ('00000197184073785097') and stat_code < 90;
select carton_nbr, stat_code, total_qty, User_id from carton_hdr where carton_nbr in ('00000197183490172350', '00000197183502050867', '00000197183502050874', '00000197183502147093', '00000197183502147109', '00000197183502147116', '00000197183502147130', '00000197183502147161', '00000197183502147178', '00000197183502263540', '00000197183502326061');

select * from carton_dtl where carton_nbr in ('00000197183490172350', '00000197183502050867', '00000197183502050874', '00000197183502147093', '00000197183502147109', '00000197183502147116', '00000197183502147130', '00000197183502147161', '00000197183502147178', '00000197183502263540', '00000197183502326061');