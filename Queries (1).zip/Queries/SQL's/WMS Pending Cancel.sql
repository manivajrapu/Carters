alter session SET Current_schema=DM;

select tc_order_id, do_status from orders where tc_order_id in ('BCAR33866324_1', 'BCAR33866878_1', 'BCAR33868888_1', 'BCAR33873588_1', 'BCAR33879047_1', 'CAR33864233_1', 'CAR33871069_1', 'CAR33876724_1') and do_status='200';