alter session SET Current_schema=DM;

select /*+rule */
       ses.sql_id,
       ses.process,
       ses.sid as sid,
       ses.serial# as serial_num,
       ses.username as db_username,
       pro.spid     as host_pid,
       ses.machine  as machine,
       substr(ses.program,1,60) as program,
       substr(obj.object_name,1,20) as object_name,
       loc.lock_type as lock_type,
       loc.mode_held as mode_held,
       loc.mode_requested as mode_req,
       loc.last_convert as kal_test,
       loc.blocking_others as is_blocking
  from v$session ses,
       v$process pro,
       dba_lock loc,
       dba_objects obj
where ses.sid      = loc.session_id
   and ses.paddr    = pro.addr
   and loc.lock_id1 = obj.object_id
   and ses.username is not null
  and object_name Not In ('ORA$BASE','PROC_LOCK','LABOR_MSG') 
  and object_name Not like 'TMP%'
  and object_name not like '%$%'
   and loc.last_convert > 50
--ORDER BY ses.process, ses.SID, ses.serial#;
order by kal_test desc;
