alter session set current_schema=DM;

-----------Cannot edit destination address as part of Order/Shipment is manifested---------

select tc_order_id,D_ADDRESS_1,D_CITY,D_STATE_PROV,D_POSTAL_CODE,D_COUNTRY_CODE from orders where tc_order_id = ('1220188069');

select * from orders where tc_order_id = ('1220188069'); --for this update with ccf.

---------------invalid order status-----------

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source,order_id,
INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('00000197181340870791','00000197181340871620','00000197181340871378','00000197181341048304');

select * from lpn where tc_order_id in ('BCAR32041343_1','BCAR32049657_1','BCAR32043511_1','BCAR32041560_1'); 

select do_status from orders where tc_order_id in ('BCAR32041343_1','BCAR32049657_1','BCAR32043511_1','BCAR32041560_1'); -- if olpn is in 20 and orders are in less than 190 
--then bring it back to 150 through ccf and then manifest through UI  