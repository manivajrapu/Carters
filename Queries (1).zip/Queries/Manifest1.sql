alter session set current_schema=DM;

select tc_order_id,D_ADDRESS_1,D_CITY,D_STATE_PROV,D_POSTAL_CODE,D_COUNTRY_CODE  from orders where tc_order_id = ('1224955314');

select * from POSTAL_CODE where postal_code='00717';

select * from POSTAL_CODE where postal_code in ('11413');


select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,last_updated_source,order_id,
INBOUND_OUTBOUND_INDICATOR from lpn where tc_lpn_id in ('0000019718134404485');

select tc_order_id,lpn.TC_REFERENCE_LPN_ID,lpn_facility_status from lpn where tc_order_id in('BCAR32041343_1','BCAR32049657_1','BCAR32043511_1','BCAR32041560_1');

select do_status,order_type from orders where tc_order_id in ('CAR33317213_1');


select * from lpn where tc_lpn_id in ('00000019718134404485');

select item_id,lpn_facility_status,lpn_id,tc_lpn_id,tc_order_id,manifest_nbr,tc_reference_lpn_id,last_updated_source,order_id,tc_shipment_id,
INBOUND_OUTBOUND_INDICATOR,TC_REFERENCE_LPN_ID,SHIP_VIA,LAST_UPDATED_SOURCE from lpn where tc_lpn_id in ('00000197181344023834');  


,'00000197181337592286 ','00000197181599417716');--00000197181594875269--00000197181594874187
select ship_via,description from ship_via where ship_via in('FDEC');
select do_status from orders where tc_order_id in('43935484','43935484','43935484');---43935484,43935484,43935484


select manifest_nbr from  where manifest_nbr='FXGD000008671';